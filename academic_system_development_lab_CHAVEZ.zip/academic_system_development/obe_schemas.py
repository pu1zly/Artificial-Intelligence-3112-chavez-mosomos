"""
obe_schemas.py
Pydantic data contracts for Outcome-Based Education (OBE) Syllabus Generation.
Enforces strict domain compliance, Bloom's taxonomy verbs, and relational structure.
"""

from typing import List, Literal, Optional, Dict, Any
from pydantic import BaseModel, Field, field_validator, model_validator, AliasChoices


# Negative constraints: Explicitly banned non-measurable verbs from OBE guidelines
BANNED_VERBS = {
    "understand", "understands", "understanding",
    "learn", "learns", "learning",
    "know", "knows", "knowing",
    "be exposed to", "expose",
    "study", "studies", "studying",
    "appreciate", "appreciates", "appreciating",
    "become familiar with", "familiarize",
}

# Bloom's Taxonomy recommended action verbs by cognitive domain level
BLOOM_LEVEL_VERBS = {
    "Level 1-2 (Remember/Understand)": [
        "identify", "define", "recall", "describe", "state", "list", "name",
        "label", "match", "recognize", "reproduce", "outline"
    ],
    "Level 3-4 (Apply/Analyze)": [
        "apply", "implement", "configure", "calculate", "analyze", "solve",
        "demonstrate", "execute", "examine", "compare", "contrast", "differentiate",
        "construct", "test", "debug", "utilize", "manipulate"
    ],
    "Level 5-6 (Evaluate/Create)": [
        "design", "develop", "synthesize", "integrate", "defend", "formulate",
        "evaluate", "architect", "engineer", "assess", "optimize", "create", "devise"
    ],
}


class CourseOutcome(BaseModel):
    """Represents a single Course Learning Outcome (CLO/CO) aligned to Bloom's taxonomy and Program Outcomes."""
    clo_number: int = Field(..., ge=1, description="Sequential number of the Course Outcome (1, 2, 3...)")
    bloom_level: Literal[
        "Level 1-2 (Remember/Understand)",
        "Level 3-4 (Apply/Analyze)",
        "Level 5-6 (Evaluate/Create)"
    ] = Field(..., description="Cognitive domain level according to Bloom's Taxonomy")
    co_description: str = Field(..., description="Action outcome starting with an active Bloom's verb")
    mapped_po: List[int] = Field(..., description="Mapped Program Learning Outcome numbers (e.g. [1, 2, 3])")

    @field_validator("co_description")
    @classmethod
    def validate_bloom_compliance(cls, v: str) -> str:
        text = v.strip()
        if not text:
            raise ValueError("Course outcome description cannot be empty.")
        
        words = text.split()
        first_word = words[0].lower().rstrip(",.:;")
        
        # Check negative constraints (banned verbs)
        for banned in BANNED_VERBS:
            if first_word == banned or text.lower().startswith(banned):
                raise ValueError(
                    f"Non-measurable verb '{banned}' violates OBE compliance rules. "
                    f"Use an active Bloom's Taxonomy verb instead (e.g., 'Implement', 'Design', 'Analyze')."
                )
        return text

    @field_validator("mapped_po")
    @classmethod
    def validate_po_range(cls, v: List[int]) -> List[int]:
        if not v:
            raise ValueError("Each Course Outcome must map to at least one Program Learning Outcome (PLO).")
        for po in v:
            if not (1 <= po <= 6):
                raise ValueError(f"Program Learning Outcome index {po} is out of standard range [1-6].")
        return sorted(list(set(v)))


class CourseOutcomePayload(BaseModel):
    """Payload container for Course Outcomes generation in Lab 1.1."""
    course_code: str = Field(..., description="Course code (e.g. CS201, BSCS 3112)")
    course_title: str = Field(..., description="Official title of the course")
    course_description: str = Field(..., description="Brief course overview/description")
    target_pos: List[int] = Field(..., description="List of target Program Learning Outcomes [1-6]")
    course_outcomes: List[CourseOutcome] = Field(
        ...,
        description="List of 4 to 5 measurable Course Learning Outcomes"
    )

    @field_validator("course_outcomes")
    @classmethod
    def validate_outcome_count(cls, outcomes: List[CourseOutcome]) -> List[CourseOutcome]:
        if len(outcomes) < 3 or len(outcomes) > 6:
            raise ValueError(f"Course outcomes must contain between 4 and 5 outcomes. Found {len(outcomes)}.")
        return outcomes


# Alias for explicit match with lab description
CourseOutcomeSchema = CourseOutcomePayload


class LessonLearningOutcome(BaseModel):
    """Granular weekly outcome categorized by Knowledge (K), Skills (S), and Attitude (A)."""
    category: Literal["K", "S", "A"] = Field(
        ...,
        description="Category: K for Knowledge (theoretical), S for Skills (hands-on coding), A for Attitude (professionalism/ethics)"
    )
    outcome_text: str = Field(
        ...,
        description="Action statement starting with an active Bloom's verb or professional disposition"
    )

    @field_validator("outcome_text")
    @classmethod
    def validate_and_remediate_bloom(cls, v: str) -> str:
        text = v.strip()
        if not text:
            return "Explain fundamental concepts."
        words = text.split()
        first_word = words[0].lower().rstrip(",.:;")
        
        # Remediation mapping for non-measurable verbs to strict Bloom's equivalents
        replacements = {
            "understand": "Explain",
            "understands": "Explains",
            "understanding": "Explaining",
            "learn": "Analyze",
            "learns": "Analyzes",
            "learning": "Analyzing",
            "know": "Identify",
            "knows": "Identifies",
            "knowing": "Identifying",
            "study": "Examine",
            "studies": "Examines",
            "studying": "Examining",
            "familiarize": "Identify",
        }
        if first_word in replacements:
            remediated_first = replacements[first_word]
            return remediated_first + " " + " ".join(words[1:])
        return text


class WeeklySchedule(BaseModel):
    """Represents a single week in the course syllabus."""
    week_number: int = Field(..., ge=1, le=18, description="Week number (1 to 14 for 14-week term)")
    period: Literal["PRELIM", "MIDTERM", "FINAL"] = Field(
        default="PRELIM",
        description="Academic grading period"
    )
    topic: str = Field(
        default="Core IT Topics",
        description="Week's lesson topic or examination label"
    )
    llos: List[LessonLearningOutcome] = Field(
        default_factory=list,
        description="Lesson Learning Outcomes (Knowledge, Skills, Attitude)"
    )
    teaching_learning_activity: str = Field(
        default="Hands-on IT laboratory programming and debugging exercise",
        validation_alias=AliasChoices("teaching_learning_activity", "tla_activity", "tla"),
        description="Teaching & Learning Activity (must emphasize IT hands-on labs)"
    )
    assessment_tool: str = Field(
        default="Lab Rubric and Practical Exercise",
        validation_alias=AliasChoices("assessment_tool", "assessment_strategy", "assessment"),
        description="Assessment strategy (e.g., Lab Rubric, Quiz, Exam)"
    )
    evidence: str = Field(
        default="Executable Source Code and Program Output",
        validation_alias=AliasChoices("evidence", "student_artifact", "result"),
        description="Student artifact (e.g., Executable Code, Lab Report)"
    )
    aligned_co: List[int] = Field(
        default_factory=lambda: [1],
        validation_alias=AliasChoices("aligned_co", "aligned_cos", "mapped_co", "mapped_cos"),
        description="List of CLO numbers (e.g. [1, 2]) that this week assesses"
    )

    @model_validator(mode="before")
    @classmethod
    def preprocess_fields(cls, values: Any) -> Any:
        if isinstance(values, dict):
            # Handle topic vs topics
            if "topic" not in values and "topics" in values:
                t = values["topics"]
                values["topic"] = ", ".join(t) if isinstance(t, list) else str(t)
            # Handle aligned_co single integer
            for alias in ["aligned_co", "aligned_cos", "mapped_co", "mapped_cos"]:
                if alias in values and isinstance(values[alias], int):
                    values[alias] = [values[alias]]
            # Ensure evidence fallback if missing
            if not values.get("evidence"):
                values["evidence"] = "Executable Source Code and Program Output"
            if not values.get("assessment_tool"):
                values["assessment_tool"] = "Lab Rubric and Practical Exercise"
            if not values.get("teaching_learning_activity"):
                values["teaching_learning_activity"] = "Hands-on IT laboratory programming and debugging exercise"
        return values

    @field_validator("aligned_co")
    @classmethod
    def validate_aligned_co(cls, v: List[int]) -> List[int]:
        if not v:
            raise ValueError("Each week must align with at least one Course Outcome (aligned_co).")
        return v


class InstitutionalGradingBreakdown(BaseModel):
    """Institutional Grading Formula as specified in Lesson 3 Slide 14:
    Class Standing = (Quizzes * 30%) + (Research * 20%) + (Seatwork/lab * 50%)
    Term Grade = (Class Standing * 70%) + (Major Exam * 30%)
    """
    class_standing_weight_pct: float = Field(default=70.0, description="Class standing weight in term grade")
    quizzes_weight_pct: float = Field(default=30.0, description="Quizzes weight within Class Standing")
    research_weight_pct: float = Field(default=20.0, description="Research weight within Class Standing")
    seatwork_lab_weight_pct: float = Field(default=50.0, description="Seatwork/Lab weight within Class Standing")
    major_exam_weight_pct: float = Field(default=30.0, description="Major Exam weight in term grade")
    formula_description: str = Field(
        default="Term Grade = (Class Standing * 70%) + (Major Exam * 30%), where Class Standing = (Quizzes * 30%) + (Research * 20%) + (Seatwork/lab * 50%)",
        description="Formal description of the institutional grading policy"
    )

    @model_validator(mode="after")
    def verify_weights(self):
        cs_sum = self.quizzes_weight_pct + self.research_weight_pct + self.seatwork_lab_weight_pct
        if round(cs_sum, 1) != 100.0:
            raise ValueError(f"Class standing subcomponents must sum to 100%. Got {cs_sum}%")
        tg_sum = self.class_standing_weight_pct + self.major_exam_weight_pct
        if round(tg_sum, 1) != 100.0:
            raise ValueError(f"Term grade components must sum to 100%. Got {tg_sum}%")
        return self


class OBESyllabusPayload(BaseModel):
    """Complete OBE Syllabus data contract produced in Lab 1.2."""
    course_code: str = Field(..., description="Course code")
    course_title: str = Field(..., description="Course title")
    course_description: str = Field(..., description="Course catalog description")
    target_pos: List[int] = Field(..., description="Program Learning Outcomes mapped")
    course_outcomes: List[CourseOutcome] = Field(..., description="4-5 Course Learning Outcomes")
    grading_breakdown: InstitutionalGradingBreakdown = Field(
        default_factory=InstitutionalGradingBreakdown,
        description="Institutional Grading Matrix Breakdown"
    )
    weekly_schedule: List[WeeklySchedule] = Field(..., description="14-week schedule array")

    @field_validator("weekly_schedule")
    @classmethod
    def validate_14_weeks_and_milestones(cls, schedule: List[WeeklySchedule]) -> List[WeeklySchedule]:
        if len(schedule) != 14:
            raise ValueError(f"Syllabus must contain exactly 14 weeks. Found {len(schedule)} weeks.")
        
        # Verify Week numbers are 1..14
        weeks = [w.week_number for w in schedule]
        if weeks != list(range(1, 15)):
            raise ValueError(f"Weekly schedule week numbers must be sequentially 1 to 14. Got {weeks}")

        # Verify Midterm at Week 7
        week_7 = schedule[6]
        if "midterm" not in week_7.topic.lower() and "midterm" not in week_7.assessment_tool.lower():
            raise ValueError("Week 7 must be designated as the Midterm Examination / Evaluation.")

        # Verify Final at Week 14
        week_14 = schedule[13]
        if "final" not in week_14.topic.lower() and "final" not in week_14.assessment_tool.lower():
            raise ValueError("Week 14 must be designated as the Final Examination / Final Project Defense.")

        return schedule

    @model_validator(mode="after")
    def validate_all_cos_covered(self):
        """CCS Business Rule: verify that every generated CO is referenced at least once in the 14-week schedule."""
        co_numbers = {co.clo_number for co in self.course_outcomes}
        referenced_cos = set()
        for week in self.weekly_schedule:
            for aligned in week.aligned_co:
                referenced_cos.add(aligned)
        
        missing_cos = co_numbers - referenced_cos
        if missing_cos:
            raise ValueError(
                f"Curriculum alignment error: Course Outcome(s) {missing_cos} are never referenced "
                f"in the 14-week schedule. Every CO must be covered at least once."
            )
        return self
