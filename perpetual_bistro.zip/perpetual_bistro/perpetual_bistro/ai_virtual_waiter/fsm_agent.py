"""Backward compatibility alias module for fsm_controller."""
from fsm_controller import *  # noqa: F401, F403
