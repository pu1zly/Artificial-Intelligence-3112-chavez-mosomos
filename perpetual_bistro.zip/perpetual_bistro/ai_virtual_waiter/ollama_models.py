"""Selection helpers for locally installed Ollama Qwen chat models."""
import re


_QWEN_PATTERN = re.compile(
    r"^qwen(?P<version>\d+(?:\.\d+)*)(?P<family>[^:]*)(?::(?P<tag>.+))?$",
    re.IGNORECASE,
)
_SIZE_PATTERN = re.compile(r"(?<!\d)(?P<size>\d+(?:\.\d+)?)\s*(?P<unit>[bB])")


def _qwen_rank(model_name):
    match = _QWEN_PATTERN.match(model_name.strip())
    if not match:
        return None

    version = tuple(int(part) for part in match.group("version").split("."))
    family = match.group("family").casefold()
    tag = (match.group("tag") or "").casefold()
    general_chat = not any(word in family + " " + tag for word in ("coder", "embed"))

    size_match = _SIZE_PATTERN.search(tag)
    size = float(size_match.group("size")) if size_match else 0
    return general_chat, version, size


def select_qwen_model(installed_models, requested_model=None):
    """Return the requested installed model or the strongest installed Qwen chat model."""
    installed = sorted(set(installed_models))
    if requested_model:
        if requested_model in installed:
            return requested_model
        raise RuntimeError(
            f"Configured Ollama model {requested_model} is not installed. "
            f"Installed models: {', '.join(installed) or 'none'}."
        )

    candidates = [
        (rank, name) for name in installed
        if (rank := _qwen_rank(name)) is not None
    ]
    if not candidates:
        raise RuntimeError(
            "No Qwen chat model is installed in Ollama. "
            f"Installed models: {', '.join(installed) or 'none'}."
        )
    return max(candidates, key=lambda candidate: candidate[0])[1]
