@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title Perpetual Bistro - AI Virtual Waiter

echo ======================================================================
echo           PERPETUAL BISTRO - AI VIRTUAL WAITER LAUNCHER
echo ======================================================================

rem Usage:
rem   run.bat          - Launch Web Tablet Dashboard (Default)
rem   run.bat web      - Launch Web Tablet Dashboard
rem   run.bat gui      - Launch Desktop GUI (Tkinter)
rem   run.bat voice    - Launch Hands-Free Voice Assistant Loop
rem   run.bat cli      - Launch Interactive Terminal Console
rem   run.bat verify   - Run Milestone 1 Verification Suite
rem   run.bat reset    - Reset SQLite database with fresh catalog & stock

set MODE=%~1
set EXTRA_FLAGS=

if /i "%MODE%"=="reset" (
    echo [i] Resetting database to fresh catalog and stock...
    python init_db.py --reset
    pause
    exit /b 0
)

if /i "%MODE%"=="verify" (
    set EXTRA_FLAGS=--verify-m1
    goto CHECK_ENV
)

if /i "%MODE%"=="gui" (
    set EXTRA_FLAGS=--gui
    goto CHECK_ENV
)

if /i "%MODE%"=="voice" (
    set EXTRA_FLAGS=--voice
    goto CHECK_ENV
)

if /i "%MODE%"=="cli" (
    set EXTRA_FLAGS=--cli
    goto CHECK_ENV
)

if /i "%MODE%"=="web" (
    set EXTRA_FLAGS=--web
    goto CHECK_ENV
)

rem Default is web interface
set EXTRA_FLAGS=

:CHECK_ENV
where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python was not found on your system PATH.
    echo Please install Python 3.10+ and ensure "Add python.exe to PATH" is checked.
    pause
    exit /b 1
)

rem Check for virtualenv in parent or local folder if available
if exist "..\.venv\Scripts\activate.bat" (
    call "..\.venv\Scripts\activate.bat"
) else if exist ".venv\Scripts\activate.bat" (
    call ".venv\Scripts\activate.bat"
)

where ollama >nul 2>nul
if errorlevel 1 (
    echo [WARNING] Ollama CLI was not found on your system PATH.
    echo Please make sure Ollama is installed and running at http://localhost:11434
) else (
    ollama list >nul 2>nul
    if errorlevel 1 (
        echo [i] Starting local Ollama server in background...
        start "Ollama" /min ollama serve
        timeout /t 3 /nobreak >nul
    )
)

echo [i] Starting Perpetual Bistro AI Virtual Waiter...
python app.py %EXTRA_FLAGS%
if errorlevel 1 (
    echo.
    echo [!] Program exited with an error.
    pause
)
