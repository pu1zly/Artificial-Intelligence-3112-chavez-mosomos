"""Main Application Entry Point for Perpetual Bistro AI Virtual Waiter.
Chains together:
    UI (Web Dashboard / Desktop GUI)
    -> Speech Engine (STT / TTS)
    -> FSM Controller (Greeting / Ordering / Review / Confirmed)
    -> Ollama / Qwen 2.5 (Reasoning & Intent Parsing)
    -> SQLite Tools (Menu, Active Cart, Table Sessions)

Usage:
    python app.py            # Launch Web UI Tablet Dashboard (Default)
    python app.py --gui      # Launch Desktop GUI (CustomTkinter/Tkinter)
    python app.py --cli      # Launch Terminal Interactive Console
    python app.py --voice    # Launch Voice Interaction Loop (Microphone -> TTS)
    python app.py --verify-m1 # Run Milestone 1 Verification Test
    python app.py --reset-db # Reset SQLite database to fresh catalog
"""
import argparse
import os
import sys
import threading
import webbrowser

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import db_tools as db
from fsm_controller import WaiterAgent, GREETING, ORDERING, REVIEW, CONFIRMED
from speech_engine import SpeechEngine, run_milestone1_verification

agent = WaiterAgent()
speech = SpeechEngine(tts_rate=175, tts_volume=0.9)


def run_cli_chat():
    """Terminal chat execution loop."""
    print("=" * 65)
    print("PERPETUAL BISTRO - AI VIRTUAL WAITER (CLI)")
    print("Connected to Local SQLite & Ollama Qwen 2.5")
    print("Commands: 'menu', 'review', 'confirm', 'cancel', 'reset', 'exit'")
    print("=" * 65)

    print("\nWaiter: Welcome to Perpetual Bistro! What table number are you seated at?")
    while True:
        try:
            user_input = input("\nYou: ").strip()
            if not user_input:
                continue
            if user_input.lower() in ("exit", "quit"):
                print("Exiting Perpetual Bistro. Goodbye!")
                break
            if user_input.lower() == "reset":
                agent.reset()
                print("Session reset. What table number are you seated at?")
                continue

            reply = agent.handle_user(user_input)
            print(f"\nWaiter: {reply}")
            print(f"[State: {agent.state} | Table: {agent.table_no}]")
        except (KeyboardInterrupt, EOFError):
            print("\nSession ended.")
            break


def run_voice_loop():
    """Hands-free voice execution loop with STT and TTS vocalization."""
    print("=" * 65)
    print("PERPETUAL BISTRO - HANDS-FREE VOICE ASSISTANT")
    print("Speak into your microphone. Waiter responds via TTS audio.")
    print("=" * 65)

    welcome_msg = "Welcome to Perpetual Bistro! What table number are you seated at today?"
    print(f"\nWaiter: {welcome_msg}")
    speech.speak(welcome_msg)

    while True:
        try:
            print("\n[Microphone active - listening...]")
            user_text = speech.listen(timeout=6, phrase_time_limit=10)
            if not user_text:
                continue
            if user_text.lower() in ("exit", "quit", "goodbye"):
                speech.speak("Thank you for visiting Perpetual Bistro. Goodbye!")
                break

            print(f"Customer Spoke: \"{user_text}\"")
            reply = agent.handle_user(user_text)
            print(f"Waiter: {reply}")
            print(f"[State: {agent.state} | Table: {agent.table_no}]")
            speech.speak(reply)
        except (KeyboardInterrupt, EOFError):
            break


def run_desktop_gui():
    """Launch Desktop ordering GUI."""
    try:
        import tkinter as tk
        from virtual_waiter_prototype import WaiterApp
        root = tk.Tk()
        app = WaiterApp(root, agent)
        root.mainloop()
    except ImportError as e:
        print(f"Could not load Desktop GUI: {e}. Starting Web UI instead.")
        run_web_server()


def create_app():
    """Factory creating Flask Web GUI ordering tablet interface."""
    from flask import Flask, jsonify, render_template, request

    template_dir = os.path.join(HERE, "ui_dashboard", "templates")
    static_dir = os.path.join(HERE, "ui_dashboard", "static")

    server = Flask(__name__, template_folder=template_dir, static_folder=static_dir)

    @server.route("/")
    def index():
        return render_template("index.html")

    @server.route("/api/state", methods=["GET"])
    def get_state():
        cart = db.view_current_order(agent.session_id) if agent.session_id else {"items": [], "subtotal": 0, "service_fee": 0, "total": 0}
        receipt = None
        if agent.state == CONFIRMED and agent.session_id:
            receipt = {"session_id": agent.session_id, "table_no": agent.table_no, **cart}
        return jsonify({
            "table_no": agent.table_no,
            "session_id": agent.session_id,
            "state": str(agent.state),
            "cart": cart,
            "transcript": agent.transcript,
            "receipt": receipt,
            "model": agent.model or "qwen2.5:7b"
        })

    @server.route("/api/chat", methods=["POST"])
    def handle_chat():
        speech.stop()
        data = request.get_json() or {}
        text = data.get("text", "").strip()
        if not text:
            return jsonify({"ok": False, "error": "No message provided."})

        reply = agent.handle_user(text)
        cart = db.view_current_order(agent.session_id) if agent.session_id else {"items": [], "subtotal": 0, "service_fee": 0, "total": 0}
        receipt = None
        if agent.state == CONFIRMED and agent.session_id:
            receipt = {"session_id": agent.session_id, "table_no": agent.table_no, **cart}

        return jsonify({
            "ok": True,
            "response": reply,
            "state": str(agent.state),
            "table_no": agent.table_no,
            "cart": cart,
            "transcript": agent.transcript,
            "receipt": receipt
        })

    @server.route("/api/voice_listen", methods=["POST"])
    def voice_listen():
        speech.stop()
        text = speech.listen(timeout=5, phrase_time_limit=8)
        return jsonify({"ok": True, "text": text})

    @server.route("/api/voice_stop", methods=["POST"])
    def voice_stop():
        speech.stop()
        return jsonify({"ok": True})

    @server.route("/api/cart/adjust", methods=["POST"])
    def adjust_cart():
        data = request.get_json() or {}
        line_id = data.get("line_id")
        delta = data.get("delta", 1)
        res = agent.adjust(line_id, delta)
        cart = db.view_current_order(agent.session_id) if agent.session_id else {"items": [], "subtotal": 0, "service_fee": 0, "total": 0}
        return jsonify({
            "ok": res.get("ok", False),
            "state": str(agent.state),
            "cart": cart,
            "transcript": agent.transcript
        })

    @server.route("/api/cart/delete", methods=["POST"])
    def delete_cart():
        data = request.get_json() or {}
        line_id = data.get("line_id")
        res = agent.delete_line(line_id)
        cart = db.view_current_order(agent.session_id) if agent.session_id else {"items": [], "subtotal": 0, "service_fee": 0, "total": 0}
        return jsonify({
            "ok": res.get("ok", False),
            "state": str(agent.state),
            "cart": cart,
            "transcript": agent.transcript
        })

    @server.route("/api/cart/review", methods=["POST"])
    def review_cart():
        reply = agent.go_review()
        cart = db.view_current_order(agent.session_id) if agent.session_id else {"items": [], "subtotal": 0, "service_fee": 0, "total": 0}
        return jsonify({
            "ok": True,
            "response": reply,
            "state": str(agent.state),
            "cart": cart,
            "transcript": agent.transcript
        })

    @server.route("/api/cart/confirm", methods=["POST"])
    def confirm_cart():
        reply = agent.confirm()
        cart = db.view_current_order(agent.session_id) if agent.session_id else {"items": [], "subtotal": 0, "service_fee": 0, "total": 0}
        receipt = None
        if agent.state == CONFIRMED and agent.session_id:
            receipt = {"session_id": agent.session_id, "table_no": agent.table_no, **cart}
        return jsonify({
            "ok": agent.state == CONFIRMED,
            "response": reply,
            "state": str(agent.state),
            "cart": cart,
            "transcript": agent.transcript,
            "receipt": receipt
        })

    @server.route("/api/reset", methods=["POST"])
    def reset_state():
        agent.reset()
        cart = {"items": [], "subtotal": 0, "service_fee": 0, "total": 0}
        return jsonify({
            "ok": True,
            "state": str(agent.state),
            "table_no": None,
            "cart": cart,
            "transcript": []
        })

    @server.route("/api/menu", methods=["GET"])
    def get_menu():
        cat = request.args.get("category", "all")
        return jsonify(db.get_menu_items(cat))

    @server.route("/api/menu/filter", methods=["GET"])
    def get_menu_filtered():
        diet = request.args.get("diet", "all")
        return jsonify(db.get_menu_by_dietary_filter(diet))

    return server


app = create_app()


def run_web_server(port: int = 5000, open_browser: bool = True):
    """Launch Flask Web GUI ordering tablet interface."""
    url = f"http://127.0.0.1:{port}"
    print("=" * 65)
    print("PERPETUAL BISTRO - TABLET ORDERING INTERFACE")
    print(f"Dashboard URL: {url}")
    print("FSM Engine: Greeting -> Ordering -> Review -> Confirmed")
    print("Zero Cloud Dependencies: 100% Local Execution")
    print("=" * 65)

    if open_browser:
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()

    app.run(host="127.0.0.1", port=port, debug=False)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Perpetual Bistro AI Virtual Waiter Application Entry Point.")
    parser.add_argument("--web", action="store_true", default=False, help="Launch Flask Web ordering dashboard")
    parser.add_argument("--gui", action="store_true", help="Launch Desktop ordering GUI")
    parser.add_argument("--cli", action="store_true", help="Run interactive terminal chat")
    parser.add_argument("--voice", action="store_true", help="Run voice assistant loop (Mic STT + Speaker TTS)")
    parser.add_argument("--verify-m1", action="store_true", help="Run Milestone 1 verification test script")
    parser.add_argument("--reset-db", action="store_true", help="Reset restaurant.db with fresh menu and stock")
    parser.add_argument("--port", type=int, default=5000, help="Web server port (default 5000)")
    parser.add_argument("--no-browser", action="store_true", help="Do not automatically launch web browser")

    args = parser.parse_args()

    if args.reset_db:
        db.init_db(reset=True)
        print("Database restaurant.db reset with fresh stock and catalog.")
        sys.exit(0)

    if args.verify_m1:
        run_milestone1_verification()
        sys.exit(0)

    if args.cli:
        run_cli_chat()
    elif args.voice:
        run_voice_loop()
    elif args.gui:
        run_desktop_gui()
    else:
        # Default entry point: Web Tablet Dashboard
        run_web_server(port=args.port, open_browser=not args.no_browser)
