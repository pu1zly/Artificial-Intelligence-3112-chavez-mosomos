import io
import os
import sys
import types
import unittest
from unittest.mock import patch

import ensure_models
from ollama_models import select_qwen_model


class EnsureModelsTests(unittest.TestCase):
    def test_installed_ollama_model_passes_check_without_pull(self):
        with patch.object(ensure_models, "_ollama_model_names", return_value={"qwen2.5:7b"}):
            with patch.object(ensure_models.subprocess, "Popen") as popen:
                selected = ensure_models.ensure_ollama_model()

        self.assertEqual(selected, "qwen2.5:7b")
        popen.assert_not_called()

    def test_checker_selects_best_available_qwen_without_pulling(self):
        installed = {"qwen2.5:7b", "qwen3:8b", "llama3.1:8b"}
        with patch.object(ensure_models, "_ollama_model_names", return_value=installed):
            with patch.object(ensure_models.subprocess, "Popen") as popen:
                selected = ensure_models.ensure_ollama_model()

        self.assertEqual(selected, "qwen3:8b")
        popen.assert_not_called()

    def test_selector_prefers_newer_qwen_family_then_larger_model(self):
        self.assertEqual(
            select_qwen_model({
                "qwen2.5:14b",
                "qwen3:8b",
                "qwen3:14b",
                "qwen3-coder:30b",
                "llama3.1:70b",
            }),
            "qwen3:14b",
        )

    def test_selector_honors_installed_model_override(self):
        self.assertEqual(
            select_qwen_model({"qwen2.5:7b", "qwen3:8b"}, requested_model="qwen2.5:7b"),
            "qwen2.5:7b",
        )

    def test_selector_errors_when_override_is_missing(self):
        with self.assertRaisesRegex(RuntimeError, "Configured Ollama model"):
            select_qwen_model({"qwen3:8b"}, requested_model="qwen2.5:7b")

    def test_running_ollama_app_is_checked_through_local_api_without_cli(self):
        response = io.BytesIO(b'{"models":[{"name":"qwen2.5:7b"}]}')
        with patch.object(ensure_models.shutil, "which", return_value=None):
            with patch.dict(os.environ, {"OLLAMA_HOST": "http://127.0.0.1:11434"}):
                with patch.object(ensure_models.urllib.request, "urlopen", return_value=response) as urlopen:
                    ensure_models.ensure_ollama_model()

        urlopen.assert_called_once_with("http://127.0.0.1:11434/api/tags", timeout=5)

    def test_missing_faster_whisper_package_is_reported_without_installing(self):
        with patch.object(ensure_models.importlib.util, "find_spec", return_value=None):
            with patch.object(ensure_models, "_whisper_model_is_cached", return_value=True):
                with patch.object(ensure_models.subprocess, "run") as run:
                    with self.assertRaisesRegex(RuntimeError, "don't have faster-whisper installed"):
                        ensure_models.ensure_faster_whisper_model()

        run.assert_not_called()

    def test_missing_faster_whisper_model_is_reported_without_downloading(self):
        with patch.object(ensure_models.importlib.util, "find_spec", return_value=object()):
            with patch.object(ensure_models, "_whisper_model_is_cached", return_value=False):
                with patch.dict(sys.modules, {"faster_whisper": types.ModuleType("faster_whisper")}):
                    with patch.object(ensure_models.subprocess, "run") as run:
                        with self.assertRaisesRegex(RuntimeError, "don't have the faster-whisper model"):
                            ensure_models.ensure_faster_whisper_model()

        run.assert_not_called()

    def test_cached_faster_whisper_model_is_accepted_without_loading_it(self):
        with patch.object(ensure_models.importlib.util, "find_spec", return_value=object()):
            with patch.object(ensure_models, "_whisper_model_is_cached", return_value=True):
                with patch.dict(sys.modules, {"faster_whisper": types.ModuleType("faster_whisper")}):
                    with patch.object(ensure_models.subprocess, "run") as run:
                        ensure_models.ensure_faster_whisper_model()

        run.assert_not_called()


if __name__ == "__main__":
    unittest.main()
