"""Tkinter interface for the OBE course outcome and syllabus generators."""

import json
import os
import queue
import subprocess
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText
from typing import Any, Callable, Optional

from lab1_1_generator import generate_course_outcomes
from lab1_2_pipeline import build_complete_syllabus
from obe_schemas import CourseOutcomePayload


DEFAULT_TITLE = "Data Structures and Algorithms"
DEFAULT_CODE = "CS201"
DEFAULT_DESCRIPTION = "Fundamental data structures and algorithm analysis techniques."
DEFAULT_MODEL = "qwen2.5:1.5b"


class OBEGeneratorApp(tk.Tk):
    """Desktop front end for the existing OBE generation pipeline."""

    def __init__(self) -> None:
        super().__init__()
        self.title("OBE Academic System")
        self.geometry("1100x760")
        self.minsize(820, 600)

        self._events: queue.Queue[tuple[str, Any]] = queue.Queue()
        self._worker_active = False
        self._course_payload: Optional[CourseOutcomePayload] = None

        self.title_var = tk.StringVar(value=DEFAULT_TITLE)
        self.code_var = tk.StringVar(value=DEFAULT_CODE)
        self.description_var = tk.StringVar(value=DEFAULT_DESCRIPTION)
        self.pos_var = tk.StringVar(value="1,2,3,4")
        self.model_var = tk.StringVar(value=DEFAULT_MODEL)
        self.retries_var = tk.IntVar(value=3)
        self.co_output_var = tk.StringVar(value="lab1_1_output.json")
        self.syllabus_output_var = tk.StringVar(value="sample_output_syllabus.json")
        self.status_var = tk.StringVar(value="Ready")

        self._build_style()
        self._build_layout()
        self.after(100, self._process_events)

    def _build_style(self) -> None:
        style = ttk.Style(self)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("Title.TLabel", font=("Segoe UI", 22, "bold"))
        style.configure("Section.TLabel", font=("Segoe UI", 11, "bold"))
        style.configure("Action.TButton", padding=(12, 8))

    def _build_layout(self) -> None:
        outer = ttk.Frame(self, padding=20)
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(1, weight=1)
        outer.rowconfigure(2, weight=1)

        ttk.Label(outer, text="OBE Academic System", style="Title.TLabel").grid(
            row=0, column=0, columnspan=3, sticky="w", pady=(0, 4)
        )
        ttk.Label(
            outer,
            text="Generate validated course outcomes and a complete 14-week syllabus with Ollama.",
        ).grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 16))

        settings = ttk.LabelFrame(outer, text="Course and model settings", padding=12)
        settings.grid(row=2, column=0, sticky="ns", padx=(0, 16))
        settings.columnconfigure(1, weight=1)
        self._add_entry(settings, 0, "Course title", self.title_var)
        self._add_entry(settings, 1, "Course code", self.code_var)
        self._add_entry(settings, 2, "Target POs", self.pos_var)
        self._add_entry(settings, 3, "Ollama model", self.model_var)
        self._add_entry(settings, 4, "Max retries", self.retries_var, width=8)

        ttk.Label(settings, text="Description").grid(row=5, column=0, sticky="nw", pady=(10, 4))
        description = tk.Text(settings, height=5, width=30, wrap="word")
        description.grid(row=5, column=1, sticky="ew", pady=(10, 4))
        description.insert("1.0", self.description_var.get())
        self.description_text = description

        ttk.Separator(settings).grid(row=6, column=0, columnspan=2, sticky="ew", pady=12)
        ttk.Label(settings, text="Output files", style="Section.TLabel").grid(
            row=7, column=0, columnspan=2, sticky="w", pady=(0, 6)
        )
        self._add_path_row(settings, 8, "CO JSON", self.co_output_var, "Save Course Outcomes")
        self._add_path_row(settings, 9, "Syllabus JSON", self.syllabus_output_var, "Save Syllabus")

        actions = ttk.Frame(settings)
        actions.grid(row=10, column=0, columnspan=2, sticky="ew", pady=(18, 0))
        actions.columnconfigure(0, weight=1)
        actions.columnconfigure(1, weight=1)
        self.generate_button = ttk.Button(
            actions, text="Generate Course Outcomes", style="Action.TButton", command=self.generate_outcomes
        )
        self.generate_button.grid(row=0, column=0, sticky="ew", padx=(0, 4), pady=3)
        self.build_button = ttk.Button(
            actions, text="Build 14-Week Syllabus", style="Action.TButton", command=self.build_syllabus
        )
        self.build_button.grid(row=0, column=1, sticky="ew", padx=(4, 0), pady=3)
        ttk.Button(actions, text="Load CO JSON", command=self.load_course_outcomes).grid(
            row=1, column=0, columnspan=2, sticky="ew", pady=3
        )

        results = ttk.Frame(outer)
        results.grid(row=2, column=1, columnspan=2, sticky="nsew")
        results.columnconfigure(0, weight=1)
        results.rowconfigure(1, weight=1)
        ttk.Label(results, text="Output preview", style="Section.TLabel").grid(
            row=0, column=0, sticky="w", pady=(0, 6)
        )
        self.preview = ScrolledText(results, wrap="none", undo=False, font=("Cascadia Mono", 10))
        self.preview.grid(row=1, column=0, sticky="nsew")
        self.preview.configure(state="disabled")

        ttk.Label(outer, textvariable=self.status_var, relief="sunken", anchor="w").grid(
            row=3, column=0, columnspan=3, sticky="ew", pady=(14, 0)
        )

    def _add_entry(
        self, parent: ttk.Widget, row: int, label: str, variable: tk.Variable, width: int = 30
    ) -> None:
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=4, padx=(0, 8))
        ttk.Entry(parent, textvariable=variable, width=width).grid(row=row, column=1, sticky="ew", pady=4)

    def _add_path_row(
        self, parent: ttk.Widget, row: int, label: str, variable: tk.StringVar, dialog_title: str
    ) -> None:
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=4, padx=(0, 8))
        path_frame = ttk.Frame(parent)
        path_frame.grid(row=row, column=1, sticky="ew", pady=4)
        path_frame.columnconfigure(0, weight=1)
        ttk.Entry(path_frame, textvariable=variable).grid(row=0, column=0, sticky="ew")
        ttk.Button(
            path_frame,
            text="Browse",
            command=lambda: self._choose_output(variable, dialog_title),
        ).grid(row=0, column=1, padx=(6, 0))
        ttk.Button(
            path_frame,
            text="View in File Explorer",
            command=lambda: self._view_in_file_explorer(variable),
        ).grid(row=0, column=2, padx=(6, 0))

    def _choose_output(self, variable: tk.StringVar, title: str) -> None:
        path = filedialog.asksaveasfilename(
            title=title,
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
        )
        if path:
            variable.set(path)

    def _view_in_file_explorer(self, variable: tk.StringVar) -> None:
        path = Path(variable.get().strip()).expanduser()
        if not path.name:
            messagebox.showinfo("No output path", "Choose an output file path first.")
            return

        path = path.resolve()
        try:
            if path.exists():
                subprocess.Popen(["explorer.exe", f"/select,{path}"])
            else:
                path.parent.mkdir(parents=True, exist_ok=True)
                os.startfile(path.parent)
        except OSError as error:
            messagebox.showerror("Could not open File Explorer", str(error))

    def _parse_settings(self) -> dict[str, Any]:
        title = self.title_var.get().strip()
        code = self.code_var.get().strip()
        description = self.description_text.get("1.0", "end").strip()
        if not title or not code or not description:
            raise ValueError("Course title, code, and description are required.")

        try:
            target_pos = [int(value.strip()) for value in self.pos_var.get().split(",") if value.strip()]
            retries = int(self.retries_var.get())
        except ValueError as error:
            raise ValueError("Target POs must be comma-separated numbers and retries must be an integer.") from error
        if not target_pos or any(po < 1 or po > 6 for po in target_pos):
            raise ValueError("Target POs must contain numbers from 1 through 6.")
        if retries < 0:
            raise ValueError("Max retries cannot be negative.")

        return {
            "course_title": title,
            "course_code": code,
            "course_description": description,
            "target_pos": target_pos,
            "model_name": self.model_var.get().strip() or DEFAULT_MODEL,
            "max_retries": retries,
        }

    def generate_outcomes(self) -> None:
        try:
            settings = self._parse_settings()
        except ValueError as error:
            messagebox.showerror("Invalid settings", str(error))
            return

        output_path = self.co_output_var.get().strip()
        self.status_var.set("Generating course outcomes and saving the JSON file...")
        self._run_in_background(
            "Generating course outcomes...",
            lambda: self._generate_outcomes_job(settings, output_path),
        )

    def _generate_outcomes_job(
        self, settings: dict[str, Any], output_path: str
    ) -> tuple[str, CourseOutcomePayload, str]:
        payload = generate_course_outcomes(**settings)
        json_output = payload.model_dump_json(indent=2)
        self._write_json(output_path, json_output)
        return json_output, payload, output_path

    def build_syllabus(self) -> None:
        try:
            settings = self._parse_settings()
        except ValueError as error:
            messagebox.showerror("Invalid settings", str(error))
            return

        output_path = self.syllabus_output_var.get().strip()
        self.status_var.set("Building the syllabus and saving the JSON file...")
        self._run_in_background(
            "Building the 14-week syllabus...",
            lambda: self._build_syllabus_job(settings, output_path),
        )

    def _build_syllabus_job(
        self, settings: dict[str, Any], output_path: str
    ) -> tuple[str, None, str]:
        payload = self._course_payload
        if payload is None:
            co_path = Path(self.co_output_var.get().strip())
            if not co_path.exists():
                raise FileNotFoundError("Generate or load Course Outcomes before building the syllabus.")
            with co_path.open("r", encoding="utf-8") as file:
                payload = CourseOutcomePayload.model_validate(json.load(file))

        syllabus = build_complete_syllabus(
            course_metadata=payload,
            model_name=settings["model_name"],
            max_retries=settings["max_retries"],
        )
        json_output = syllabus.model_dump_json(indent=2)
        self._write_json(output_path, json_output)
        return json_output, None, output_path

    def load_course_outcomes(self) -> None:
        path = filedialog.askopenfilename(
            title="Open Course Outcomes JSON",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as file:
                payload = CourseOutcomePayload.model_validate(json.load(file))
        except (OSError, json.JSONDecodeError, ValueError) as error:
            messagebox.showerror("Could not load Course Outcomes", str(error))
            return

        self._course_payload = payload
        self.co_output_var.set(path)
        self._show_preview(payload.model_dump_json(indent=2))
        self.status_var.set(f"Loaded Course Outcomes from {path}")

    def _run_in_background(self, status: str, job: Callable[[], tuple[str, Any]]) -> None:
        if self._worker_active:
            messagebox.showinfo("Generation in progress", "Please wait for the current operation to finish.")
            return
        self._worker_active = True
        self._set_buttons_enabled(False)
        self.status_var.set(status)

        def worker() -> None:
            try:
                result = job()
                self._events.put(("success", result))
            except Exception as error:
                self._events.put(("error", error))

        threading.Thread(target=worker, daemon=True).start()

    def _process_events(self) -> None:
        try:
            event, payload = self._events.get_nowait()
        except queue.Empty:
            self.after(100, self._process_events)
            return

        self._worker_active = False
        self._set_buttons_enabled(True)
        if event == "success":
            json_output, course_payload, output_path = payload
            if course_payload is not None:
                self._course_payload = course_payload
            try:
                saved_output = Path(output_path).read_text(encoding="utf-8")
            except OSError as error:
                self.status_var.set("Completed, but preview could not be refreshed")
                messagebox.showerror("Preview refresh failed", str(error))
            else:
                self._show_preview(saved_output)
                self.status_var.set(f"Saved and preview refreshed: {output_path}")
        else:
            self.status_var.set("Operation failed")
            messagebox.showerror("Generation failed", str(payload))
        self.after(100, self._process_events)

    def _set_buttons_enabled(self, enabled: bool) -> None:
        state = "normal" if enabled else "disabled"
        self.generate_button.configure(state=state)
        self.build_button.configure(state=state)

    def _show_preview(self, text: str) -> None:
        self.preview.configure(state="normal")
        self.preview.delete("1.0", "end")
        self.preview.insert("1.0", text)
        self.preview.configure(state="disabled")

    @staticmethod
    def _write_json(path: str, content: str) -> None:
        if not path:
            raise ValueError("An output JSON path is required.")
        output = Path(path)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(content, encoding="utf-8")


if __name__ == "__main__":
    app = OBEGeneratorApp()
    app.mainloop()