"""Check that the local Ollama and faster-whisper models are already available."""
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request

from ollama_models import select_qwen_model

OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "").strip() or None
WHISPER_MODEL = os.environ.get("WHISPER_MODEL", "").strip() or "medium.en"
OLLAMA_WAIT_SECONDS = 60


def _ollama_tags_url():
    host = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434").strip()
    if "://" not in host:
        host = f"http://{host}"
    return f"{host.rstrip('/')}/api/tags"


def _fetch_ollama_model_names():
    with urllib.request.urlopen(_ollama_tags_url(), timeout=5) as response:
        payload = json.loads(response.read().decode("utf-8"))
    return {
        model["name"]
        for model in payload.get("models", [])
        if isinstance(model, dict) and isinstance(model.get("name"), str)
    }


def _ollama_model_names():
    try:
        return _fetch_ollama_model_names()
    except (OSError, urllib.error.URLError, TimeoutError, ValueError) as initial_error:
        if not shutil.which("ollama"):
            raise RuntimeError(
                "The Ollama service is not responding. Open the Ollama app and make "
                "sure its local service is running."
            ) from initial_error

    print("[i] Ollama is not responding yet; starting its local service...")
    options = {"stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
    if os.name == "nt":
        options["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    subprocess.Popen(["ollama", "serve"], **options)

    deadline = time.monotonic() + OLLAMA_WAIT_SECONDS
    while time.monotonic() < deadline:
        try:
            return _fetch_ollama_model_names()
        except (OSError, urllib.error.URLError, TimeoutError, ValueError):
            time.sleep(2)
    raise RuntimeError(
        f"The Ollama service did not become ready within {OLLAMA_WAIT_SECONDS} seconds."
    )


def ensure_ollama_model():
    installed_models = _ollama_model_names()
    selected_model = select_qwen_model(installed_models, requested_model=OLLAMA_MODEL)
    print(f"[i] Using installed Qwen model: {selected_model}")
    return selected_model


def _whisper_model_is_cached():
    if os.path.isdir(WHISPER_MODEL):
        return True

    cache_dir = (
        os.environ.get("HUGGINGFACE_HUB_CACHE")
        or os.path.join(
            os.environ.get("HF_HOME", os.path.expanduser("~/.cache/huggingface")),
            "hub",
        )
    )
    model_repo = WHISPER_MODEL.replace("/", "--")
    repo_cache = os.path.join(cache_dir, f"models--Systran--faster-whisper-{model_repo}")
    snapshots = os.path.join(repo_cache, "snapshots")
    if not os.path.isdir(snapshots):
        return False

    return any(
        os.path.isfile(os.path.join(snapshots, snapshot, "model.bin"))
        and os.path.isfile(os.path.join(snapshots, snapshot, "config.json"))
        for snapshot in os.listdir(snapshots)
    )


def ensure_faster_whisper_model():
    missing = []
    if importlib.util.find_spec("faster_whisper") is None:
        missing.append(
            "You don't have faster-whisper installed. Install project dependencies "
            "with 'pip install -r requirements.txt'."
        )
    else:
        print("[i] faster-whisper is installed.")

    if _whisper_model_is_cached():
        print(f"[i] faster-whisper model {WHISPER_MODEL} is downloaded.")
    else:
        missing.append(
            f"You don't have the faster-whisper model {WHISPER_MODEL} downloaded. "
            "Download it while online before launching."
        )

    if missing:
        raise RuntimeError(" ".join(missing))


def main():
    failures = []
    for check in (ensure_ollama_model, ensure_faster_whisper_model):
        try:
            check()
        except (OSError, RuntimeError, subprocess.CalledProcessError, subprocess.TimeoutExpired) as error:
            failures.append(str(error))

    if failures:
        for error in failures:
            print(f"[ERROR] {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
