// Perpetual Bistro AI Virtual Waiter - Tablet UI Controller
document.addEventListener("DOMContentLoaded", () => {
    // Elements
    const chatTranscript = document.getElementById("chat-transcript");
    const chatForm = document.getElementById("chat-form");
    const chatInput = document.getElementById("chat-input");
    const btnMic = document.getElementById("btn-mic");
    const ttsToggle = document.getElementById("tts-toggle");
    const currentTableBadge = document.getElementById("current-table-badge");
    const fsmStatusBadge = document.getElementById("fsm-status-badge");
    const tabSubtitle = document.getElementById("tab-subtitle");
    const cartTableBody = document.getElementById("cart-table-body");
    const emptyCartRow = document.getElementById("empty-cart-row");
    const cartSubtotal = document.getElementById("cart-subtotal");
    const cartServiceFee = document.getElementById("cart-service-fee");
    const cartGrandTotal = document.getElementById("cart-grand-total");
    const btnReviewOrder = document.getElementById("btn-review-order");
    const btnConfirmOrder = document.getElementById("btn-confirm-order");
    const btnCancelOrder = document.getElementById("btn-cancel-order");
    const btnResetSession = document.getElementById("btn-reset-session");
    const menuCardsContainer = document.getElementById("menu-cards-container");
    const dietaryFilterSelect = document.getElementById("dietary-filter-select");
    const receiptModal = document.getElementById("receipt-modal");
    const btnCloseReceipt = document.getElementById("btn-close-receipt");

    // Stepper Elements
    const stepGreeting = document.getElementById("step-greeting");
    const stepOrdering = document.getElementById("step-ordering");
    const stepReview = document.getElementById("step-review");
    const stepConfirmed = document.getElementById("step-confirmed");

    // Switcher & Menu Status Elements
    const tabBtnMenu = document.getElementById("tab-btn-menu");
    const tabBtnWaiter = document.getElementById("tab-btn-waiter");
    const viewMenu = document.getElementById("view-menu");
    const viewWaiter = document.getElementById("view-waiter");
    const waiterBadge = document.getElementById("waiter-badge");
    const menuOrderStatus = document.getElementById("menu-order-status");
    const menuStatusText = document.getElementById("menu-status-text");
    const menuStatusIcon = document.getElementById("menu-status-icon");
    const btnStatusViewChat = document.getElementById("btn-status-view-chat");

    let isRecording = false;
    let recognition = null;
    let activeTab = "menu"; // "menu" or "waiter"
    let currentCategory = "all";
    let currentDiet = "all";

    // Tab Switcher Controller
    function switchTab(tab) {
        activeTab = tab;
        if (tab === "menu") {
            if (viewMenu) viewMenu.classList.remove("hidden");
            if (viewWaiter) viewWaiter.classList.add("hidden");
            if (tabBtnMenu) {
                tabBtnMenu.className = "px-4 py-2 font-bold text-xs rounded-t-lg transition flex items-center gap-2 bg-[#fbf7ef] text-[#4a0020] shadow";
            }
            if (tabBtnWaiter) {
                tabBtnWaiter.className = "px-4 py-2 font-semibold text-xs rounded-t-lg transition flex items-center gap-2 text-neutral-300 hover:text-white hover:bg-[#5f0029]/60";
            }
        } else {
            if (viewMenu) viewMenu.classList.add("hidden");
            if (viewWaiter) viewWaiter.classList.remove("hidden");
            if (tabBtnWaiter) {
                tabBtnWaiter.className = "px-4 py-2 font-bold text-xs rounded-t-lg transition flex items-center gap-2 bg-[#4a0020] text-[#fccc0c] shadow border-t-2 border-[#fccc0c]";
            }
            if (tabBtnMenu) {
                tabBtnMenu.className = "px-4 py-2 font-semibold text-xs rounded-t-lg transition flex items-center gap-2 text-neutral-300 hover:text-white hover:bg-[#5f0029]/60";
            }
            if (waiterBadge) waiterBadge.classList.add("hidden");
            if (chatTranscript) chatTranscript.scrollTop = chatTranscript.scrollHeight;
        }
    }

    if (tabBtnMenu) tabBtnMenu.addEventListener("click", () => switchTab("menu"));
    if (tabBtnWaiter) tabBtnWaiter.addEventListener("click", () => switchTab("waiter"));
    if (btnStatusViewChat) btnStatusViewChat.addEventListener("click", () => switchTab("waiter"));

    // Web Speech API check for direct browser STT
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
        recognition = new SpeechRec();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';

        recognition.onstart = () => {
            isRecording = true;
            if (btnMic) btnMic.classList.add("mic-recording");
            stopSpeech();
        };

        recognition.onresult = (e) => {
            const transcript = e.results[0][0].transcript;
            if (chatInput) chatInput.value = transcript;
            submitMessage(transcript);
        };

        recognition.onerror = () => {
            stopMic();
        };

        recognition.onend = () => {
            stopMic();
        };
    }

    function stopMic() {
        isRecording = false;
        if (btnMic) btnMic.classList.remove("mic-recording");
    }

    // Instantly skip & silence any ongoing speech
    function stopSpeech() {
        if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel();
        }
        fetch("/api/voice_stop", { method: "POST" }).catch(() => {});
    }

    // Mic Click Handler
    if (btnMic) {
        btnMic.addEventListener("click", () => {
            stopSpeech();
            if (isRecording) {
                if (recognition) recognition.stop();
                stopMic();
            } else {
                if (recognition) {
                    try {
                        recognition.start();
                    } catch (e) {
                        serverVoiceListen();
                    }
                } else {
                    serverVoiceListen();
                }
            }
        });
    }

    async function serverVoiceListen() {
        stopSpeech();
        if (btnMic) btnMic.classList.add("mic-recording");
        try {
            const res = await fetch("/api/voice_listen", { method: "POST" });
            const data = await res.json();
            if (data.text) {
                if (chatInput) chatInput.value = data.text;
                submitMessage(data.text);
            }
        } catch (e) {
            console.error("Server voice listen error:", e);
        } finally {
            if (btnMic) btnMic.classList.remove("mic-recording");
        }
    }

    // TTS speech vocalization using browser SpeechSynthesis with instant skip
    function speakText(text) {
        if (!ttsToggle || !ttsToggle.checked || !('speechSynthesis' in window) || !text) return;
        
        stopSpeech();

        const clean = text
            .replace(/[*#_`~]/g, '')
            .replace(/PHP\s*/gi, 'pesos ')
            .replace(/\s+/g, ' ')
            .trim();

        if (!clean) return;

        const utterance = new SpeechSynthesisUtterance(clean);
        utterance.rate = 1.15;
        utterance.pitch = 1.0;

        if (window.speechSynthesis.paused) {
            window.speechSynthesis.resume();
        }

        window.speechSynthesis.speak(utterance);
    }

    // Fetch and sync active state
    async function syncState() {
        try {
            const res = await fetch("/api/state");
            const data = await res.json();
            renderState(data);
        } catch (e) {
            console.error("Failed to sync state:", e);
        }
    }

    // Render Full System State
    function renderState(data) {
        const { state, table_no, cart, transcript, receipt } = data;

        // Update Table Badge
        const tableNum = table_no || 1;
        if (currentTableBadge) {
            currentTableBadge.textContent = `Table: ${tableNum}`;
        }
        if (tabSubtitle) {
            const itemCount = (cart && cart.items) ? cart.items.length : 0;
            tabSubtitle.textContent = `Table: ${tableNum} • ${itemCount} items`;
        }

        // Update FSM Status Badge
        const normalizedState = (state || "GREETING").replace("STATE_", "").replace("TAKING_ORDER", "ORDERING");
        if (fsmStatusBadge) {
            fsmStatusBadge.textContent = normalizedState;
        }

        // Update Stepper
        if (stepGreeting && stepOrdering && stepReview && stepConfirmed) {
            [stepGreeting, stepOrdering, stepReview, stepConfirmed].forEach(el => {
                el.className = "px-2.5 py-0.5 rounded-full transition-all text-neutral-400";
            });

            if (normalizedState === "GREETING") {
                stepGreeting.className = "px-2.5 py-0.5 rounded-full transition-all fsm-step-active";
            } else if (normalizedState === "ORDERING") {
                stepGreeting.className = "px-2.5 py-0.5 rounded-full transition-all fsm-step-passed";
                stepOrdering.className = "px-2.5 py-0.5 rounded-full transition-all fsm-step-active";
            } else if (normalizedState === "REVIEW") {
                stepGreeting.className = "px-2.5 py-0.5 rounded-full transition-all fsm-step-passed";
                stepOrdering.className = "px-2.5 py-0.5 rounded-full transition-all fsm-step-passed";
                stepReview.className = "px-2.5 py-0.5 rounded-full transition-all fsm-step-active";
            } else if (normalizedState === "CONFIRMED") {
                [stepGreeting, stepOrdering, stepReview].forEach(el => el.className = "px-2.5 py-0.5 rounded-full transition-all fsm-step-passed");
                stepConfirmed.className = "px-2.5 py-0.5 rounded-full transition-all fsm-step-active";
            }
        }

        // Render Cart Table (Virtual Receipt)
        renderCart(cart, normalizedState);

        // Render Transcript
        renderTranscript(transcript);

        // Show receipt if confirmed
        if (receipt && normalizedState === "CONFIRMED") {
            showReceipt(receipt);
        }
    }

    // Render Active Cart Rows & Totals (Virtual Receipt)
    function renderCart(cart, currentState) {
        if (!cartTableBody) return;
        const items = (cart && cart.items) ? cart.items : [];
        cartTableBody.innerHTML = "";

        if (items.length === 0) {
            cartTableBody.appendChild(emptyCartRow);
            if (cartSubtotal) cartSubtotal.textContent = "PHP 0.00";
            if (cartServiceFee) cartServiceFee.textContent = "PHP 0.00";
            if (cartGrandTotal) cartGrandTotal.textContent = "PHP 0.00";
            return;
        }

        const isLocked = currentState === "CONFIRMED";

        items.forEach(item => {
            const tr = document.createElement("tr");
            tr.className = "hover:bg-[#f6eee0] transition";

            const comboDetails = item.side_name ? `<div class="text-[10px] text-neutral-500"><i class="fa-solid fa-angles-right text-[8px]"></i> ${item.side_name}, ${item.drink_name}</div>` : '';
            const instructions = item.instructions ? `<div class="text-[10px] text-amber-800 italic font-mono"><i class="fa-solid fa-note-sticky text-[8px]"></i> ${item.instructions}</div>` : '';

            tr.innerHTML = `
                <td class="py-2.5 pl-1 pr-2">
                    <span class="font-bold text-[#4a0020] text-xs">${item.name}</span>
                    ${comboDetails}
                    ${instructions}
                </td>
                <td class="py-2.5 px-1 text-center whitespace-nowrap">
                    <div class="inline-flex items-center gap-1 bg-[#ede2cb] rounded px-1.5 py-0.5">
                        <button class="cart-btn-dec text-neutral-600 hover:text-rose-700 font-bold px-1 ${isLocked ? 'opacity-40 cursor-not-allowed' : ''}" data-id="${item.line_id}" ${isLocked ? 'disabled' : ''}>-</button>
                        <span class="font-semibold text-xs min-w-[14px]">${item.quantity}</span>
                        <button class="cart-btn-inc text-neutral-600 hover:text-emerald-700 font-bold px-1 ${isLocked ? 'opacity-40 cursor-not-allowed' : ''}" data-id="${item.line_id}" ${isLocked ? 'disabled' : ''}>+</button>
                    </div>
                </td>
                <td class="py-2.5 px-2 text-right font-mono font-semibold text-neutral-700 whitespace-nowrap text-xs">
                    PHP ${Number(item.line_total).toFixed(2)}
                </td>
                <td class="py-2.5 pr-1 text-center whitespace-nowrap">
                    <button class="cart-btn-del bg-rose-100 hover:bg-rose-600 hover:text-white text-rose-700 font-extrabold w-6 h-6 rounded flex items-center justify-center transition text-xs shadow-sm mx-auto ${isLocked ? 'opacity-40 cursor-not-allowed' : ''}" data-id="${item.line_id}" data-name="${item.name}" title="Remove ${item.name} from receipt" ${isLocked ? 'disabled' : ''}>
                        ✕
                    </button>
                </td>
            `;
            cartTableBody.appendChild(tr);
        });

        // Totals
        if (cartSubtotal) cartSubtotal.textContent = `PHP ${Number(cart.subtotal || 0).toFixed(2)}`;
        if (cartServiceFee) cartServiceFee.textContent = `PHP ${Number(cart.service_fee || 0).toFixed(2)}`;
        if (cartGrandTotal) cartGrandTotal.textContent = `PHP ${Number(cart.total || 0).toFixed(2)}`;

        // Attach Manual Override Listeners
        document.querySelectorAll(".cart-btn-inc").forEach(btn => {
            btn.addEventListener("click", () => adjustCart(btn.dataset.id, 1));
        });
        document.querySelectorAll(".cart-btn-dec").forEach(btn => {
            btn.addEventListener("click", () => adjustCart(btn.dataset.id, -1));
        });
        document.querySelectorAll(".cart-btn-del").forEach(btn => {
            btn.addEventListener("click", () => deleteCart(btn.dataset.id, btn.dataset.name));
        });
    }

    // Render Chat Transcript
    function renderTranscript(messages) {
        if (!chatTranscript || !messages || messages.length === 0) return;
        chatTranscript.innerHTML = "";

        messages.forEach(msg => {
            const isUser = msg.role === "user";
            const div = document.createElement("div");
            div.className = `flex items-start gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`;

            if (!isUser) {
                div.innerHTML = `
                    <div class="w-8 h-8 rounded-full bg-[#fccc0c] text-[#4a0020] flex items-center justify-center text-sm font-bold flex-shrink-0 shadow">
                        <i class="fa-solid fa-robot"></i>
                    </div>
                    <div class="chat-bubble-waiter p-3 rounded-2xl max-w-[85%] text-sm shadow whitespace-pre-line">
                        <p class="font-semibold text-xs text-[#e5c785] mb-1">Perpetual Bistro Waiter</p>
                        <p>${escapeHtml(msg.text)}</p>
                    </div>
                `;
            } else {
                div.innerHTML = `
                    <div class="chat-bubble-user p-3 rounded-2xl max-w-[85%] text-sm font-medium shadow whitespace-pre-line">
                        <p class="font-semibold text-xs text-[#5f0029] mb-1 text-right">You (Customer)</p>
                        <p>${escapeHtml(msg.text)}</p>
                    </div>
                    <div class="w-8 h-8 rounded-full bg-neutral-700 text-[#fbf7ef] flex items-center justify-center text-sm font-bold flex-shrink-0 shadow">
                        <i class="fa-solid fa-user"></i>
                    </div>
                `;
            }
            chatTranscript.appendChild(div);
        });

        chatTranscript.scrollTop = chatTranscript.scrollHeight;
    }

    function escapeHtml(text) {
        const div = document.createElement("div");
        div.textContent = text;
        return div.innerHTML;
    }

    // Submit Message via Chat or Menu Action
    async function submitMessage(text, isMenuOrder = false, itemName = "") {
        if (!text || !text.trim()) return;
        
        stopSpeech();
        if (chatInput) chatInput.value = "";

        // Status banner when picking an item from the menu
        if (isMenuOrder && menuOrderStatus) {
            menuOrderStatus.classList.remove("hidden");
            if (menuStatusIcon) menuStatusIcon.className = "fa-solid fa-spinner fa-spin text-amber-600";
            if (menuStatusText) menuStatusText.textContent = `Reading your order... Adding 1 ${itemName} to your virtual receipt.`;
        }

        // Temporary optimistic display in transcript
        if (chatTranscript) {
            const tempDiv = document.createElement("div");
            tempDiv.className = "flex items-start gap-2.5 justify-end";
            tempDiv.innerHTML = `
                <div class="chat-bubble-user p-3 rounded-2xl max-w-[85%] text-sm font-medium shadow">
                    <p class="font-semibold text-xs text-[#5f0029] mb-1 text-right">You (Customer)</p>
                    <p>${escapeHtml(text)}</p>
                </div>
                <div class="w-8 h-8 rounded-full bg-neutral-700 text-[#fbf7ef] flex items-center justify-center text-sm font-bold flex-shrink-0">
                    <i class="fa-solid fa-user"></i>
                </div>
            `;
            chatTranscript.appendChild(tempDiv);
            chatTranscript.scrollTop = chatTranscript.scrollHeight;
        }

        try {
            const res = await fetch("/api/chat", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ text })
            });
            const data = await res.json();
            renderState(data);

            if (isMenuOrder && menuOrderStatus) {
                if (menuStatusIcon) menuStatusIcon.className = "fa-solid fa-circle-check text-emerald-600";
                if (menuStatusText) menuStatusText.textContent = `I've added ${itemName} to your order, is that all?`;
            }

            if (activeTab === "menu" && waiterBadge) {
                waiterBadge.classList.remove("hidden");
            }

            if (data.response) {
                speakText(data.response);
            }
        } catch (e) {
            console.error("Chat error:", e);
            if (isMenuOrder && menuOrderStatus) {
                if (menuStatusIcon) menuStatusIcon.className = "fa-solid fa-triangle-exclamation text-rose-600";
                if (menuStatusText) menuStatusText.textContent = `Could not add ${itemName}. Please try again.`;
            }
        }
    }

    if (chatInput) {
        chatInput.addEventListener("input", () => {
            stopSpeech();
        });
    }

    if (chatForm) {
        chatForm.addEventListener("submit", (e) => {
            e.preventDefault();
            if (chatInput) submitMessage(chatInput.value.trim());
        });
    }

    // Quick Action Chips
    document.querySelectorAll(".chip-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            stopSpeech();
            submitMessage(btn.dataset.msg);
        });
    });

    // Cart Adjustments
    async function adjustCart(lineId, delta) {
        stopSpeech();
        try {
            const res = await fetch("/api/cart/adjust", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ line_id: lineId, delta })
            });
            const data = await res.json();
            renderState(data);
            loadMenuCards(currentCategory, currentDiet);
        } catch (e) {
            console.error("Adjust error:", e);
        }
    }

    // Delete item via prominent "X" button
    async function deleteCart(lineId, itemName = "") {
        stopSpeech();
        try {
            const res = await fetch("/api/cart/delete", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ line_id: lineId })
            });
            const data = await res.json();
            renderState(data);
            loadMenuCards(currentCategory, currentDiet);

            const msg = itemName ? `Removed ${itemName} from your virtual receipt.` : "Item removed from your receipt.";
            if (menuOrderStatus) {
                menuOrderStatus.classList.remove("hidden");
                if (menuStatusIcon) menuStatusIcon.className = "fa-solid fa-trash-can text-rose-600";
                if (menuStatusText) menuStatusText.textContent = msg;
            }

            // Assistant speech confirmation
            speakText(msg);
        } catch (e) {
            console.error("Delete error:", e);
        }
    }

    // Review Button
    if (btnReviewOrder) {
        btnReviewOrder.addEventListener("click", async () => {
            stopSpeech();
            try {
                const res = await fetch("/api/cart/review", { method: "POST" });
                const data = await res.json();
                renderState(data);
                switchTab("waiter");
                if (data.response) speakText(data.response);
            } catch (e) {
                console.error("Review error:", e);
            }
        });
    }

    // Confirm Button
    if (btnConfirmOrder) {
        btnConfirmOrder.addEventListener("click", async () => {
            stopSpeech();
            try {
                const res = await fetch("/api/cart/confirm", { method: "POST" });
                const data = await res.json();
                renderState(data);
                if (data.receipt) {
                    showReceipt(data.receipt);
                }
                if (data.response) speakText(data.response);
            } catch (e) {
                console.error("Confirm error:", e);
            }
        });
    }

    // Cancel Button
    if (btnCancelOrder) {
        btnCancelOrder.addEventListener("click", () => {
            stopSpeech();
            submitMessage("cancel my whole order");
        });
    }

    // Reset Button
    if (btnResetSession) {
        btnResetSession.addEventListener("click", async () => {
            if (!confirm("Start fresh with a new table session?")) return;
            stopSpeech();
            try {
                const res = await fetch("/api/reset", { method: "POST" });
                const data = await res.json();
                renderState(data);
                loadMenuCards("all", "all");
                if (menuOrderStatus) menuOrderStatus.classList.add("hidden");
            } catch (e) {
                console.error("Reset error:", e);
            }
        });
    }

    // Show Confirmed Receipt Modal
    function showReceipt(receipt) {
        if (!receiptModal) return;
        const tableEl = document.getElementById("receipt-table");
        const sessEl = document.getElementById("receipt-session");
        const totalEl = document.getElementById("receipt-total");
        const list = document.getElementById("receipt-items-list");

        if (tableEl) tableEl.textContent = receipt.table_no || "--";
        if (sessEl) sessEl.textContent = receipt.session_id || "--";
        if (totalEl) totalEl.textContent = `PHP ${Number(receipt.total || 0).toFixed(2)}`;

        if (list) {
            list.innerHTML = "";
            (receipt.items || []).forEach(item => {
                const d = document.createElement("div");
                d.className = "flex justify-between";
                d.innerHTML = `<span>${item.quantity}x ${item.name}</span><span class="font-bold">PHP ${Number(item.line_total).toFixed(2)}</span>`;
                list.appendChild(d);
            });
        }

        receiptModal.classList.remove("hidden");
    }

    if (btnCloseReceipt) {
        btnCloseReceipt.addEventListener("click", async () => {
            if (receiptModal) receiptModal.classList.add("hidden");
            await fetch("/api/reset", { method: "POST" });
            syncState();
            loadMenuCards("all", "all");
        });
    }

    // Load Menu Cards
    async function loadMenuCards(cat = currentCategory, diet = currentDiet) {
        currentCategory = cat;
        currentDiet = diet;
        if (!menuCardsContainer) return;

        try {
            let url = `/api/menu?category=${encodeURIComponent(cat)}`;
            if (diet && diet !== "all") {
                url = `/api/menu/filter?diet=${encodeURIComponent(diet)}`;
            }
            const res = await fetch(url);
            const data = await res.json();
            renderMenuCards(data.items || []);
        } catch (e) {
            menuCardsContainer.innerHTML = `<div class="col-span-full py-12 text-center text-rose-600 text-xs">Failed to load menu items.</div>`;
        }
    }

    function renderMenuCards(items) {
        if (!menuCardsContainer) return;
        menuCardsContainer.innerHTML = "";

        if (!items || items.length === 0) {
            menuCardsContainer.innerHTML = `<div class="col-span-full py-12 text-center text-neutral-500 text-xs italic">No menu items match this filter.</div>`;
            return;
        }

        items.forEach(item => {
            const card = document.createElement("div");
            card.className = "bg-white p-3.5 rounded-xl border border-[#d6c4a8] shadow-sm hover:shadow transition flex flex-col justify-between";

            const isOutOfStock = item.available_qty <= 0;
            const stockBadge = !isOutOfStock
                ? `<span class="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full"><i class="fa-solid fa-check"></i> ${item.available_qty} in stock</span>`
                : `<span class="bg-rose-100 text-rose-800 text-[10px] font-bold px-2 py-0.5 rounded-full"><i class="fa-solid fa-triangle-exclamation"></i> Out of stock</span>`;

            const dietaryBadge = item.dietary_tags ? `<span class="bg-amber-100 text-amber-800 text-[10px] px-1.5 py-0.5 rounded uppercase font-semibold">${item.dietary_tags}</span>` : '';
            const allergens = item.allergens ? `<p class="text-[10px] text-neutral-500 mt-1 truncate" title="${item.allergens}"><span class="font-semibold text-neutral-600">Allergens:</span> ${item.allergens}</p>` : '';

            card.innerHTML = `
                <div>
                    <div class="flex items-start justify-between gap-1.5 mb-1">
                        <h4 class="font-bold text-sm text-[#4a0020]">${item.name}</h4>
                        <span class="font-mono font-bold text-sm text-[#4a0020] whitespace-nowrap">PHP ${Number(item.price).toFixed(2)}</span>
                    </div>
                    <div class="flex flex-wrap items-center gap-1.5 my-1.5">
                        ${stockBadge}
                        ${dietaryBadge}
                    </div>
                    ${allergens}
                </div>
                <div class="mt-3 pt-2.5 border-t border-neutral-100 flex items-center justify-end">
                    <button class="menu-add-btn bg-[#4a0020] hover:bg-[#5f0029] text-[#fccc0c] px-3 py-1.5 rounded-lg text-xs font-semibold shadow transition flex items-center gap-1.5 ${isOutOfStock ? 'opacity-40 cursor-not-allowed' : ''}" data-name="${item.name}" ${isOutOfStock ? 'disabled' : ''}>
                        <i class="fa-solid fa-plus text-[10px]"></i> Add to Receipt
                    </button>
                </div>
            `;
            menuCardsContainer.appendChild(card);
        });

        // Attach click listeners to "+ Add to Receipt" buttons
        document.querySelectorAll(".menu-add-btn").forEach(btn => {
            btn.addEventListener("click", async () => {
                const name = btn.dataset.name;
                stopSpeech();

                const origHtml = btn.innerHTML;
                btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin text-[10px]"></i> Reading order...`;
                btn.disabled = true;

                await submitMessage(`Add 1 ${name}`, true, name);

                btn.innerHTML = `<i class="fa-solid fa-check text-[10px]"></i> Added!`;
                btn.classList.add("bg-emerald-700");
                btn.disabled = false;

                setTimeout(() => {
                    btn.innerHTML = origHtml;
                    btn.classList.remove("bg-emerald-700");
                }, 1200);
            });
        });
    }

    // Category Tabs Filter
    document.querySelectorAll(".menu-cat-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            document.querySelectorAll(".menu-cat-btn").forEach(b => {
                b.className = "menu-cat-btn px-3 py-1 rounded-full font-semibold bg-white text-neutral-700 hover:bg-neutral-100 border border-[#d6c4a8] flex-shrink-0";
            });
            btn.className = "menu-cat-btn px-3 py-1 rounded-full font-semibold bg-[#4a0020] text-[#fccc0c] shadow-sm flex-shrink-0";
            if (dietaryFilterSelect) dietaryFilterSelect.value = "all";
            loadMenuCards(btn.dataset.cat, "all");
        });
    });

    if (dietaryFilterSelect) {
        dietaryFilterSelect.addEventListener("change", () => {
            loadMenuCards(currentCategory, dietaryFilterSelect.value);
        });
    }

    // Initial state load
    syncState();
    loadMenuCards("all", "all");
});
