-- Perpetual Bistro schema + seed data (safe to re-run)
CREATE TABLE IF NOT EXISTS menu_items (
    id INTEGER PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    category TEXT NOT NULL,
    price REAL NOT NULL,
    stock_qty INTEGER NOT NULL DEFAULT 0,
    allergens TEXT NOT NULL DEFAULT '',
    dietary_tags TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS table_sessions (
    session_id INTEGER PRIMARY KEY AUTOINCREMENT,
    table_no INTEGER,
    status TEXT NOT NULL DEFAULT 'open'   -- open | confirmed | cancelled
);

CREATE TABLE IF NOT EXISTS order_line_items (
    line_id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL REFERENCES table_sessions(session_id),
    item_id INTEGER NOT NULL REFERENCES menu_items(id),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    special_instructions TEXT NOT NULL DEFAULT ''
);

-- Support for cart_items view/table as referenced in rubric
CREATE VIEW IF NOT EXISTS cart_items AS
SELECT line_id, session_id, item_id, quantity, special_instructions
FROM order_line_items;

CREATE TABLE IF NOT EXISTS combo_components (
    combo_item_id INTEGER NOT NULL REFERENCES menu_items(id),
    component_item_id INTEGER NOT NULL REFERENCES menu_items(id),
    quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
    PRIMARY KEY (combo_item_id, component_item_id),
    CHECK (combo_item_id != component_item_id)
);

CREATE TABLE IF NOT EXISTS order_line_combo_choices (
    line_id PRIMARY KEY REFERENCES order_line_items(line_id) ON DELETE CASCADE,
    side_item_id INTEGER NOT NULL REFERENCES menu_items(id),
    drink_item_id INTEGER NOT NULL REFERENCES menu_items(id)
);

CREATE TABLE IF NOT EXISTS kiosk_state (   -- single row: lets the kiosk resume after refresh/restart
    id INTEGER PRIMARY KEY CHECK (id = 1),
    data TEXT NOT NULL
);

INSERT OR IGNORE INTO menu_items (id,name,category,price,stock_qty,allergens,dietary_tags) VALUES
 (1,'Espresso','Coffee',80,40,'','vegan'),
 (2,'Americano','Coffee',95,40,'','vegan'),
 (3,'Cappuccino','Coffee',130,30,'dairy','vegetarian'),
 (4,'Café Latte','Coffee',140,30,'dairy','vegetarian'),
 (5,'Caramel Macchiato','Coffee',160,24,'dairy','vegetarian'),
 (6,'Spanish Latte','Coffee',165,24,'dairy','vegetarian'),
 (7,'Mocha','Coffee',170,20,'dairy,soy','vegetarian'),
 (8,'Matcha Latte','Coffee',155,20,'dairy','vegetarian'),
 (9,'Vanilla Bean Frappe','Frappes',175,20,'dairy','vegetarian'),
 (10,'Java Chip Frappe','Frappes',185,18,'dairy,soy','vegetarian'),
 (11,'Caramel Frappe','Frappes',180,18,'dairy','vegetarian'),
 (12,'Strawberry Cream Frappe','Frappes',175,18,'dairy','vegetarian'),
 (13,'Classic Chocolate Milkshake','Milkshakes',165,20,'dairy,soy','vegetarian'),
 (14,'Vanilla Milkshake','Milkshakes',160,20,'dairy','vegetarian'),
 (15,'Strawberry Milkshake','Milkshakes',165,20,'dairy','vegetarian'),
 (16,'Mango Milkshake','Milkshakes',165,18,'dairy','vegetarian'),
 (17,'Iced Peach Tea','Tea & Refreshers',115,30,'','vegan'),
 (18,'Strawberry Lemonade','Tea & Refreshers',120,30,'','vegan'),
 (19,'Butter Croissant','Pastries',95,24,'gluten,dairy','vegetarian'),
 (20,'Chocolate Croissant','Pastries',120,20,'gluten,dairy,egg','vegetarian'),
 (21,'Blueberry Muffin','Pastries',110,18,'gluten,dairy,egg','vegetarian'),
 (22,'Cinnamon Roll','Pastries',125,18,'gluten,dairy,egg','vegetarian'),
 (23,'Matcha Cookie','Pastries',85,24,'gluten,dairy,egg','vegetarian'),
 (24,'New York Cheesecake Slice','Pastries',145,14,'gluten,dairy,egg','vegetarian');
