@echo off
cd /d "%~dp0"
echo This erases the saved order and restores menu stock.
choice /m "Continue"
if errorlevel 2 exit /b
call run_waiter.bat reset
