"""Database initialization script for Perpetual Bistro AI Virtual Waiter.
Run:
    python init_db.py
or:
    python init_db.py --reset
"""
import argparse
import os
import sqlite3

HERE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(HERE, "restaurant.db")
SQL_PATH = os.path.join(HERE, "init_restaurant_db.sql")


def _migrate_nullable_table_number(conn: sqlite3.Connection) -> None:
    columns = {row["name"]: row for row in conn.execute("PRAGMA table_info(table_sessions)")}
    table_no = columns.get("table_no")
    if not table_no or not table_no["notnull"]:
        return

    conn.execute("PRAGMA foreign_keys = OFF")
    try:
        with conn:
            conn.execute(
                "CREATE TABLE table_sessions_new ("
                "session_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                "table_no INTEGER, "
                "status TEXT NOT NULL DEFAULT 'open')"
            )
            conn.execute(
                "INSERT INTO table_sessions_new(session_id,table_no,status) "
                "SELECT session_id,table_no,status FROM table_sessions"
            )
            conn.execute("DROP TABLE table_sessions")
            conn.execute("ALTER TABLE table_sessions_new RENAME TO table_sessions")
    finally:
        conn.execute("PRAGMA foreign_keys = ON")


def init_database(reset: bool = False, db_path: str = DB_PATH) -> None:
    if reset and os.path.exists(db_path):
        os.remove(db_path)
        print(f"Removed existing database at {db_path}")

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    _migrate_nullable_table_number(conn)
    columns = {row["name"] for row in conn.execute("PRAGMA table_info(menu_items)")}
    if columns and "dietary_tags" not in columns:
        conn.execute("ALTER TABLE menu_items ADD COLUMN dietary_tags TEXT NOT NULL DEFAULT ''")

    with open(SQL_PATH, "r", encoding="utf-8") as f:
        sql_script = f.read()

    with conn:
        conn.executescript(sql_script)

        item_count = conn.execute("SELECT COUNT(*) FROM menu_items").fetchone()[0]
        tables = [row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type IN ('table', 'view')")]

    conn.close()
    print("=" * 65)
    print("Perpetual Bistro Database Initialized Successfully!")
    print(f"Database File: {db_path}")
    print(f"Tables/Views Created: {', '.join(tables)}")
    print(f"Total Café Menu Items: {item_count}")
    print("=" * 65)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Initialize restaurant.db for Perpetual Bistro.")
    parser.add_argument("--reset", action="store_true", help="Delete existing restaurant.db and recreate fresh")
    args = parser.parse_args()
    init_database(reset=args.reset)
