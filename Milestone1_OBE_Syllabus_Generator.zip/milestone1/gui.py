"""
gui.py
================================================================================
AI-Powered OBE Syllabus Generator Microservice
Milestone 1 — Desktop GUI

A lightweight Tkinter front end (standard library only — no extra installs)
for the two-pass Ollama Course Outcomes engine in `llm_engine.py`.

- Auto-detects whichever Ollama model you already have installed (you never
  have to type a model name), with an optional dropdown override.
- Runs the batch in a background thread so the window never freezes.
- Streams the SAME live progress `llm_engine.py --debug` prints on the CLI
  straight into the window, in real time, so you can watch the raw model
  output and the auto-repair diffs as they happen.
- Shows a results table (course, K/S/A count, retries, status) that fills
  in course by course as the batch runs.
- Click a course row to inspect its full validated Course Outcomes JSON.
- One-click "Open output file" / "Open output folder" once the run finishes.

Run:
    python gui.py
================================================================================
"""

from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import font as tkfont
from tkinter import messagebox, scrolledtext, ttk
from typing import Optional

from obe_schemas import BatchGenerationResult
from llm_engine import (
    COURSE_CATALOG,
    EngineConfig,
    LLMProvider,
    MockProvider,
    OllamaProvider,
    _build_mock_provider,
    auto_detect_model,
    run_batch,
)

OUTPUT_FILENAME = "sample_validated_output.json"

# ==============================================================================
# THEME — pulled from the "arctic sunset" reference palette
# ==============================================================================
NAVY = "#1B2A4C"     # deep mountain-shadow navy — header, log background
STEEL = "#3D6690"    # mid mountain blue — primary buttons, headings
PERIWINKLE = "#A6AFCE"  # hazy blue-violet — secondary accents, selection
SKY = "#BFD8EC"      # pale glacier blue — panel backgrounds, log text
PEACH = "#F3CFC0"    # sunrise peach — highlight accent (Run button, success)
PEACH_DARK = "#E7B3A0"  # pressed/hover state for peach
WHITE = "#FFFFFF"
OFFWHITE = "#F6F8FB"
TEXT_ON_LIGHT = "#1B2A4C"
TEXT_ON_DARK = "#EAF1F8"
FAIL_RED = "#D96C6C"
OK_GREEN = "#4E8C6E"


class OBEGeneratorGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("CCS OBE Syllabus Generator — Milestone 1")
        self.root.geometry("1200x760")
        self.root.minsize(1000, 620)
        self.root.configure(bg=OFFWHITE)

        self.msg_queue: "queue.Queue[tuple]" = queue.Queue()
        self.worker_thread: Optional[threading.Thread] = None
        self.last_result: Optional[BatchGenerationResult] = None
        self.course_payloads: dict = {}  # course_code -> payload dict, for the detail view

        self._setup_style()
        self._build_widgets()
        self._detect_model_async()
        self.root.after(100, self._poll_queue)

    # ----------------------------------------------------------- styling ----

    def _setup_style(self):
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")  # 'clam' allows full color customization
        except tk.TclError:
            pass

        self.font_body = tkfont.Font(family="Segoe UI", size=10)
        self.font_heading = tkfont.Font(family="Segoe UI", size=11, weight="bold")
        self.font_title = tkfont.Font(family="Segoe UI", size=15, weight="bold")
        self.font_subtitle = tkfont.Font(family="Segoe UI", size=9)
        self.font_mono = tkfont.Font(family="Consolas", size=9)

        style.configure(".", background=OFFWHITE, foreground=TEXT_ON_LIGHT, font=self.font_body)
        style.configure("TFrame", background=OFFWHITE)
        style.configure("Header.TFrame", background=NAVY)
        style.configure("Controls.TFrame", background=WHITE)
        style.configure("TLabel", background=OFFWHITE, foreground=TEXT_ON_LIGHT)
        style.configure("Header.TLabel", background=NAVY, foreground=TEXT_ON_DARK)
        style.configure("HeaderSub.TLabel", background=NAVY, foreground=PERIWINKLE)
        style.configure("Controls.TLabel", background=WHITE, foreground=TEXT_ON_LIGHT)
        style.configure("Status.TLabel", background=OFFWHITE, foreground=STEEL, font=self.font_subtitle)
        style.configure("SectionHeading.TLabel", background=OFFWHITE, foreground=NAVY, font=self.font_heading)

        # Buttons
        style.configure(
            "Accent.TButton", background=PEACH, foreground=NAVY,
            font=("Segoe UI", 10, "bold"), padding=(14, 8), borderwidth=0,
        )
        style.map("Accent.TButton", background=[("active", PEACH_DARK), ("disabled", SKY)])

        style.configure(
            "Steel.TButton", background=STEEL, foreground=WHITE,
            font=("Segoe UI", 9), padding=(10, 6), borderwidth=0,
        )
        style.map("Steel.TButton", background=[("active", NAVY), ("disabled", PERIWINKLE)])

        # Checkbuttons / Combobox / Spinbox on the white controls bar
        style.configure("Controls.TCheckbutton", background=WHITE, foreground=TEXT_ON_LIGHT)
        style.map("Controls.TCheckbutton", background=[("active", WHITE)])
        style.configure("TCombobox", fieldbackground=WHITE, background=WHITE)
        style.configure("TSpinbox", fieldbackground=WHITE, background=WHITE)

        # Progress bar
        style.configure("Sky.Horizontal.TProgressbar", troughcolor=SKY, background=STEEL, bordercolor=SKY, lightcolor=STEEL, darkcolor=STEEL)

        # Treeview
        style.configure(
            "Treeview", background=WHITE, fieldbackground=WHITE, foreground=TEXT_ON_LIGHT,
            rowheight=26, borderwidth=0, font=self.font_body,
        )
        style.configure(
            "Treeview.Heading", background=STEEL, foreground=WHITE,
            font=("Segoe UI", 9, "bold"), relief="flat",
        )
        style.map("Treeview.Heading", background=[("active", NAVY)])
        style.map("Treeview", background=[("selected", PERIWINKLE)], foreground=[("selected", NAVY)])

        # Paned window sash
        style.configure("TPanedwindow", background=OFFWHITE)

    # -------------------------------------------------------------- UI ----

    def _build_widgets(self):
        # ---- Header banner -----------------------------------------------
        header = ttk.Frame(self.root, style="Header.TFrame")
        header.pack(fill="x")
        inner = ttk.Frame(header, style="Header.TFrame")
        inner.pack(fill="x", padx=18, pady=(14, 12))
        ttk.Label(inner, text="CCS OBE Syllabus Generator", style="Header.TLabel", font=self.font_title).pack(anchor="w")
        ttk.Label(
            inner,
            text="Milestone 1 · Structured LLM Engine & Schema Validation · 3rd Year, 1st Semester CS/IT",
            style="HeaderSub.TLabel", font=self.font_subtitle,
        ).pack(anchor="w", pady=(2, 0))

        # ---- Control bar ---------------------------------------------------
        controls_outer = tk.Frame(self.root, bg=WHITE, highlightbackground=SKY, highlightthickness=1)
        controls_outer.pack(fill="x")
        top = ttk.Frame(controls_outer, style="Controls.TFrame")
        top.pack(fill="x", padx=14, pady=10)

        row1 = ttk.Frame(top, style="Controls.TFrame")
        row1.pack(fill="x")
        ttk.Label(row1, text="Model:", style="Controls.TLabel").pack(side="left")
        self.model_var = tk.StringVar(value="Detecting…")
        self.model_combo = ttk.Combobox(row1, textvariable=self.model_var, width=26, state="readonly")
        self.model_combo.pack(side="left", padx=(6, 10))

        self.redetect_btn = ttk.Button(row1, text="Re-detect", style="Steel.TButton", command=self._detect_model_async)
        self.redetect_btn.pack(side="left")

        ttk.Label(row1, text="Retries:", style="Controls.TLabel").pack(side="left", padx=(18, 0))
        self.retries_var = tk.IntVar(value=3)
        ttk.Spinbox(row1, from_=0, to=10, textvariable=self.retries_var, width=4).pack(side="left", padx=(6, 0))

        self.run_btn = ttk.Button(row1, text="▶   Run Batch", style="Accent.TButton", command=self._on_run_clicked)
        self.run_btn.pack(side="right")

        row2 = ttk.Frame(top, style="Controls.TFrame")
        row2.pack(fill="x", pady=(10, 0))
        self.debug_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(row2, text="Show raw model output (debug)", variable=self.debug_var, style="Controls.TCheckbutton").pack(
            side="left", padx=(0, 18)
        )
        self.mock_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row2, text="Offline mock mode — no Ollama needed", variable=self.mock_var, style="Controls.TCheckbutton").pack(
            side="left"
        )

        # ---- Status + progress ---------------------------------------------
        status_frame = ttk.Frame(self.root)
        status_frame.pack(fill="x", padx=16, pady=(10, 4))
        self.status_var = tk.StringVar(value="Batch queued: 3rd Year, 1st Semester CS/IT — 4 subjects.")
        ttk.Label(status_frame, textvariable=self.status_var, style="Status.TLabel").pack(anchor="w")

        self.progress = ttk.Progressbar(
            self.root, mode="determinate", maximum=len(COURSE_CATALOG), style="Sky.Horizontal.TProgressbar"
        )
        self.progress.pack(fill="x", padx=16, pady=(4, 10))

        # ---- Main split: results table (left) / log (right) --------------
        main = ttk.PanedWindow(self.root, orient="horizontal")
        main.pack(fill="both", expand=True, padx=16, pady=(0, 6))

        left = ttk.Frame(main)
        right = ttk.Frame(main)
        main.add(left, weight=4)
        main.add(right, weight=5)

        ttk.Label(left, text="Results", style="SectionHeading.TLabel").pack(anchor="w", pady=(0, 4))
        tree_frame = tk.Frame(left, bg=SKY, highlightbackground=SKY, highlightthickness=1)
        tree_frame.pack(fill="both", expand=False, pady=(0, 10))
        columns = ("course", "status", "ksa", "retries")
        self.tree = ttk.Treeview(tree_frame, columns=columns, show="headings", height=6)
        self.tree.heading("course", text="Course")
        self.tree.heading("status", text="Status")
        self.tree.heading("ksa", text="K / S / A")
        self.tree.heading("retries", text="Retries")
        self.tree.column("course", width=250)
        self.tree.column("status", width=90, anchor="center")
        self.tree.column("ksa", width=80, anchor="center")
        self.tree.column("retries", width=60, anchor="center")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._on_row_selected)
        self.tree.tag_configure("ok", foreground=OK_GREEN)
        self.tree.tag_configure("fail", foreground=FAIL_RED)

        detail_frame = ttk.Frame(left)
        detail_frame.pack(fill="both", expand=True)
        ttk.Label(detail_frame, text="Selected course — validated Course Outcomes", style="SectionHeading.TLabel").pack(anchor="w", pady=(0, 4))
        detail_wrap = tk.Frame(detail_frame, bg=SKY, highlightbackground=SKY, highlightthickness=1)
        detail_wrap.pack(fill="both", expand=True)
        self.detail_text = scrolledtext.ScrolledText(
            detail_wrap, wrap="word", font=self.font_mono, bg=WHITE, fg=TEXT_ON_LIGHT,
            insertbackground=TEXT_ON_LIGHT, borderwidth=0, padx=8, pady=8,
        )
        self.detail_text.pack(fill="both", expand=True)
        self.detail_text.configure(state="disabled")

        ttk.Label(right, text="Live log — raw model output, validation, auto-repair", style="SectionHeading.TLabel").pack(anchor="w", pady=(0, 4))
        log_wrap = tk.Frame(right, bg=NAVY, highlightbackground=NAVY, highlightthickness=1)
        log_wrap.pack(fill="both", expand=True)
        self.log_text = scrolledtext.ScrolledText(
            log_wrap, wrap="word", font=self.font_mono, bg=NAVY, fg=SKY,
            insertbackground=SKY, borderwidth=0, padx=10, pady=8,
        )
        self.log_text.pack(fill="both", expand=True)
        self.log_text.configure(state="disabled")
        self.log_text.tag_configure("ok", foreground=PEACH)
        self.log_text.tag_configure("fail", foreground=FAIL_RED)
        self.log_text.tag_configure("raw", foreground=PERIWINKLE)

        # ---- Bottom bar ----------------------------------------------------
        bottom = tk.Frame(self.root, bg=WHITE, highlightbackground=SKY, highlightthickness=1)
        bottom.pack(fill="x")
        bottom_inner = ttk.Frame(bottom, style="Controls.TFrame")
        bottom_inner.pack(fill="x", padx=14, pady=8)
        self.open_file_btn = ttk.Button(bottom_inner, text="Open output JSON", style="Steel.TButton", command=self._open_output_file, state="disabled")
        self.open_file_btn.pack(side="left")
        self.open_folder_btn = ttk.Button(bottom_inner, text="Open output folder", style="Steel.TButton", command=self._open_output_folder, state="disabled")
        self.open_folder_btn.pack(side="left", padx=(8, 0))
        self.summary_var = tk.StringVar(value="")
        ttk.Label(bottom_inner, textvariable=self.summary_var, style="Controls.TLabel", font=self.font_heading).pack(side="right")

    # ----------------------------------------------------- model detection

    def _detect_model_async(self):
        self.model_combo["values"] = []
        self.model_var.set("Detecting…")
        self.redetect_btn.configure(state="disabled")
        threading.Thread(target=self._detect_model_worker, daemon=True).start()

    def _detect_model_worker(self):
        try:
            model = auto_detect_model()
            self.msg_queue.put(("model_detected", model))
        except Exception as exc:
            self.msg_queue.put(("model_detect_failed", str(exc)))

    # ------------------------------------------------------------ run flow

    def _on_run_clicked(self):
        if self.worker_thread and self.worker_thread.is_alive():
            return

        if not self.mock_var.get() and (not self.model_var.get() or self.model_var.get() in ("Detecting…", "(none found)")):
            messagebox.showwarning(
                "No model selected",
                "No local Ollama model was detected. Install Ollama and run "
                "`ollama pull qwen2.5:7b` (or similar), then click Re-detect — "
                "or tick 'Offline mock mode' to try the tool without Ollama.",
            )
            return

        self._clear_for_new_run()
        self.run_btn.configure(state="disabled", text="Running…")
        self.status_var.set("Running batch — this can take a while on the first pass per course…")
        self.worker_thread = threading.Thread(target=self._run_worker, daemon=True)
        self.worker_thread.start()

    def _clear_for_new_run(self):
        self.tree.delete(*self.tree.get_children())
        self.course_payloads.clear()
        self.progress["value"] = 0
        self.summary_var.set("")
        self.open_file_btn.configure(state="disabled")
        self.open_folder_btn.configure(state="disabled")
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")
        self.detail_text.configure(state="normal")
        self.detail_text.delete("1.0", "end")
        self.detail_text.configure(state="disabled")

    def _run_worker(self):
        emit = lambda line: self.msg_queue.put(("log", line))
        on_course_done = lambda meta, outcome: self.msg_queue.put(("course_done", meta, outcome))

        try:
            debug = self.debug_var.get()
            if self.mock_var.get():
                emit("[*] Running in OFFLINE MOCK mode (no Ollama daemon required).")
                provider: LLMProvider = _build_mock_provider()
                cfg = EngineConfig(model_name="mock-scripted", max_retries=self.retries_var.get())
            else:
                model_name = self.model_var.get()
                emit(f"[*] Connecting to local Ollama daemon, model='{model_name}'...")
                provider = OllamaProvider(model_name)
                cfg = EngineConfig(model_name=provider.model_name, max_retries=self.retries_var.get())

            result = run_batch(provider, cfg, debug=debug, emit=emit, on_course_done=on_course_done)

            out_path = os.path.join(os.getcwd(), OUTPUT_FILENAME)
            with open(out_path, "w", encoding="utf-8") as f:
                f.write(result.model_dump_json(indent=2))

            self.msg_queue.put(("batch_done", result, out_path))
        except Exception as exc:
            self.msg_queue.put(("batch_error", str(exc)))

    # --------------------------------------------------------- queue poll

    def _poll_queue(self):
        try:
            while True:
                item = self.msg_queue.get_nowait()
                kind = item[0]

                if kind == "model_detected":
                    model = item[1]
                    self.model_combo["values"] = [model]
                    self.model_var.set(model)
                    self.redetect_btn.configure(state="normal")

                elif kind == "model_detect_failed":
                    self.model_combo["values"] = []
                    self.model_var.set("(none found)")
                    self.redetect_btn.configure(state="normal")
                    self._append_log(f"[!] Could not auto-detect an Ollama model: {item[1]}", tag="fail")

                elif kind == "log":
                    self._append_log(item[1])

                elif kind == "course_done":
                    meta, outcome = item[1], item[2]
                    self._add_result_row(meta, outcome)
                    self.progress["value"] = self.progress["value"] + 1
                    self.status_var.set(f"Finished {int(self.progress['value'])}/{len(COURSE_CATALOG)}: {meta.course_code} {meta.course_title}")

                elif kind == "batch_done":
                    result: BatchGenerationResult = item[1]
                    out_path = item[2]
                    self.last_result = result
                    self.summary_var.set(
                        f"{result.total_courses_validated}/{result.total_courses_attempted} courses validated"
                    )
                    self.status_var.set("Batch complete.")
                    self.open_file_btn.configure(state="normal")
                    self.open_folder_btn.configure(state="normal")
                    self.run_btn.configure(state="normal", text="▶   Run Batch")
                    self._append_log(f"\n[+] Batch complete. Output saved to: {out_path}", tag="ok")

                elif kind == "batch_error":
                    self.run_btn.configure(state="normal", text="▶   Run Batch")
                    self.status_var.set("Batch failed — see log.")
                    self._append_log(f"[!] Batch error: {item[1]}", tag="fail")
                    messagebox.showerror("Batch failed", item[1])

        except queue.Empty:
            pass
        finally:
            self.root.after(100, self._poll_queue)

    # ------------------------------------------------------------- helpers

    def _append_log(self, text: str, tag: Optional[str] = None):
        self.log_text.configure(state="normal")
        if tag:
            self.log_text.insert("end", text + "\n", tag)
        elif text.startswith("-----"):
            self.log_text.insert("end", text + "\n", "raw")
        else:
            self.log_text.insert("end", text + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _add_result_row(self, meta, outcome):
        if outcome.success and outcome.payload is not None:
            ksa = outcome.payload.ksa_summary()
            ksa_str = f"K{ksa['K']}  S{ksa['S']}  A{ksa['A']}"
            status = "✓ OK"
            tag = "ok"
            self.course_payloads[meta.course_code] = outcome.payload.model_dump()
        else:
            ksa_str = "—"
            status = "✕ FAILED"
            tag = "fail"

        self.tree.insert(
            "", "end", iid=meta.course_code,
            values=(f"{meta.course_code}  {meta.course_title}", status, ksa_str, outcome.audit.retries_used),
            tags=(tag,),
        )

    def _on_row_selected(self, _event=None):
        selection = self.tree.selection()
        if not selection:
            return
        course_code = selection[0]
        payload = self.course_payloads.get(course_code)
        self.detail_text.configure(state="normal")
        self.detail_text.delete("1.0", "end")
        if payload:
            self.detail_text.insert("1.0", json.dumps(payload, indent=2))
        else:
            self.detail_text.insert("1.0", "(This course failed validation — see the log for the error.)")
        self.detail_text.configure(state="disabled")

    def _open_output_file(self):
        path = os.path.join(os.getcwd(), OUTPUT_FILENAME)
        self._open_path(path)

    def _open_output_folder(self):
        self._open_path(os.getcwd())

    @staticmethod
    def _open_path(path: str):
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception as exc:
            messagebox.showerror("Could not open", str(exc))


def main():
    root = tk.Tk()
    OBEGeneratorGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
