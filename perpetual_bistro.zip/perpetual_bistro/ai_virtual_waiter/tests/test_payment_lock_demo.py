import importlib
import os
import tempfile
import unittest

import db_tools as db
from fsm_controller import WaiterAgent


class PaymentLockDemoTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        db.DB_PATH = os.path.join(self.temp.name, "restaurant.db")
        db.init_db()

        self.app_module = importlib.import_module("app")
        self.agent = WaiterAgent()
        self.agent.reset()
        self.app_module.agent = self.agent
        self.client = self.app_module.create_app().test_client()

    def tearDown(self):
        self.temp.cleanup()

    def test_paid_receipt_can_verify_lock_after_new_customer_reset(self):
        self.agent.add_menu_item("Café Latte")
        self.agent.go_review()
        confirmation = self.client.post("/api/cart/confirm")
        self.assertEqual(confirmation.status_code, 200)
        receipt = confirmation.get_json()["receipt"]
        confirmed_session_id = receipt["session_id"]
        original_items = receipt["items"]

        self.client.post("/api/reset")
        new_session_id = self.agent.session_id
        self.assertNotEqual(new_session_id, confirmed_session_id)

        result = self.client.post("/api/defense/verify-order-lock")
        payload = result.get_json()

        self.assertEqual(result.status_code, 200)
        self.assertTrue(payload["verified"])
        self.assertTrue(payload["unchanged"])
        self.assertEqual(
            [attempt["action"] for attempt in payload["attempts"]],
            ["Add item", "Adjust quantity", "Delete item", "Cancel order"],
        )
        self.assertTrue(all(attempt["blocked"] for attempt in payload["attempts"]))
        self.assertEqual(db.view_current_order(confirmed_session_id)["items"], original_items)
        self.assertEqual(db.view_current_order(new_session_id)["items"], [])
        with db.conn() as connection:
            statuses = {
                row["session_id"]: row["status"]
                for row in connection.execute(
                    "SELECT session_id,status FROM table_sessions "
                    "WHERE session_id IN (?,?)",
                    (confirmed_session_id, new_session_id),
                )
            }
        self.assertEqual(statuses[confirmed_session_id], "confirmed")
        self.assertEqual(statuses[new_session_id], "open")

    def test_lock_verification_requires_a_recent_confirmed_receipt(self):
        result = self.client.post("/api/defense/verify-order-lock")
        self.assertEqual(result.status_code, 404)
        self.assertFalse(result.get_json()["ok"])


if __name__ == "__main__":
    unittest.main()
