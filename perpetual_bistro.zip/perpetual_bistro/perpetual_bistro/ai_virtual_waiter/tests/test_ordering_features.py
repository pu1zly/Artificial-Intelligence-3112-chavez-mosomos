import os
import sqlite3
import tempfile
import unittest

import db_tools as db
import fsm_agent


class OrderingFeatureTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        db.DB_PATH = os.path.join(self.temp.name, "restaurant.db")
        fsm_agent.LOG_PATH = os.path.join(self.temp.name, "conversation.json")
        db.init_db()
        self.agent = fsm_agent.WaiterAgent()
        self.agent.handle_user("Table 7")
        self.session_id = self.agent.session_id

    def tearDown(self):
        self.temp.cleanup()

    def test_dietary_filter_only_returns_explicit_tags(self):
        result = db.get_menu_by_dietary_filter("vegetarian")
        names = {item["name"] for item in result["items"]}
        self.assertIn("Avocado Toast", names)
        self.assertIn("Avocado Toast Combo", names)
        self.assertNotIn("Chicken Pesto Panini", names)
        self.assertEqual(db.get_menu_by_dietary_filter("vegan")["items"], [])

    def test_allergen_filter_options_match_cafe_menu(self):
        self.assertEqual(
            fsm_agent.allergen_filter_options(),
            (
                "No dairy (listed allergens)",
                "No egg (listed allergens)",
                "No gluten (listed allergens)",
                "No soy (listed allergens)",
            ),
        )

    def test_allergen_filter_stays_with_selected_menu_category(self):
        pastries = db.get_menu_by_dietary_filter(
            "allergen-free:dairy", category="Pastries"
        )
        self.assertTrue(pastries["ok"])
        self.assertTrue(all(item["category"] == "Pastries" for item in pastries["items"]))
        self.assertEqual(pastries["items"], [])

        drinks = db.get_menu_by_dietary_filter(
            "allergen-free:dairy", category="Tea & Refreshers"
        )
        self.assertTrue(drinks["ok"])
        self.assertEqual(
            {item["name"] for item in drinks["items"]},
            {"Iced Peach Tea", "Strawberry Lemonade"},
        )

    def test_dairy_free_filter_excludes_listed_dairy_and_updates_chat_menu(self):
        result = db.get_menu_by_dietary_filter("dairy-free")
        names = {item["name"] for item in result["items"]}
        self.assertIn("Panini Coffee Meal", names)
        self.assertIn("Avocado Toast Combo", names)
        self.assertNotIn("Cafe Brunch Combo", names)
        self.assertNotIn("Matcha Latte", names)
        self.assertTrue(all("dairy" not in item["allergens"].split(",") for item in result["items"]))

        reply = self.agent.handle_user("Can I see the meals without dairy?")
        self.assertIn("Panini Coffee Meal", reply)
        self.assertIn("Avocado Toast Combo", reply)
        self.assertNotIn("Cafe Brunch Combo", reply)
        self.assertIn("not a guarantee", reply)

        all_matches = self.agent.handle_user("Show me dairy-free options")
        self.assertIn("\n\nMains:\n", all_matches)
        self.assertIn("\n\nMeal combos:\n", all_matches)
        self.assertIn("\n  - Chicken Pesto Panini (PHP 210.00)", all_matches)
        self.assertLess(all_matches.index("Meal combos:"), all_matches.index("Mains:"))

    def test_menu_filter_supports_any_listed_allergen(self):
        cases = {
            "Can I see meals without gluten?": "gluten",
            "Show me egg-free meals": "egg",
            "Which meals have no soy?": "soy",
            "List meals without peanuts": "nuts",
            "Can I see meals free of milk?": "dairy",
        }
        for request, allergen in cases.items():
            with self.subTest(request=request):
                self.assertEqual(
                    fsm_agent.detect_menu_diet_filter(request), f"allergen-free:{allergen}"
                )
        result = db.get_menu_by_dietary_filter("allergen-free:gluten")
        names = {item["name"] for item in result["items"]}
        self.assertIn("Panini Coffee Meal", names)
        self.assertNotIn("Cafe Brunch Combo", names)
        self.assertTrue(all(
            "gluten" not in {value.strip().casefold() for value in item["allergens"].split(",")}
            for item in result["items"] if not item["is_combo"]
        ))
        reply = self.agent.handle_user("Can I see meals without gluten?")
        self.assertIn("no gluten listed", reply.lower())
        self.assertIn("Panini Coffee Meal", reply)

    def test_filter_label_round_trips_allergen_choice(self):
        label = fsm_agent.menu_filter_label("allergen-free:sesame")
        self.assertEqual(label, "No sesame (listed allergens)")
        self.assertEqual(fsm_agent.menu_filter_key(label), "allergen-free:sesame")

    def test_menu_filter_detection_does_not_change_item_allergen_questions(self):
        self.assertEqual(fsm_agent.detect_menu_diet_filter("show me dairy-free meals"), "allergen-free:dairy")
        self.assertEqual(fsm_agent.detect_menu_diet_filter("meals without dairy"), "allergen-free:dairy")
        self.assertIsNone(fsm_agent.detect_menu_diet_filter("I want a dairy-free cheeseburger"))
        self.assertIsNone(fsm_agent.detect_menu_diet_filter("does the cheeseburger have dairy?"))

    def test_full_menu_browse_request_detection(self):
        for text in (
            "Can I see the menu?",
            "Could I please view the full menu",
            "Show me the menu",
            "Open menu",
            "Let me browse the menu",
        ):
            with self.subTest(text=text):
                self.assertTrue(fsm_agent.is_menu_browse_request(text))
        self.assertFalse(fsm_agent.is_menu_browse_request("What drinks do you have?"))
        self.assertFalse(fsm_agent.is_menu_browse_request("Does the cheeseburger have dairy?"))

    def test_database_startup_migrates_existing_menu_schema(self):
        legacy_path = os.path.join(self.temp.name, "legacy.db")
        connection = sqlite3.connect(legacy_path)
        connection.execute(
            "CREATE TABLE menu_items(id INTEGER PRIMARY KEY,name TEXT,category TEXT,price REAL,"
            "stock_qty INTEGER,allergens TEXT)"
        )
        connection.execute(
            "INSERT INTO menu_items VALUES (1,'Legacy dish','Mains',100,3,'')"
        )
        connection.commit()
        connection.close()
        db.DB_PATH = legacy_path
        db.init_db()
        with db.conn() as connection:
            columns = {row["name"] for row in connection.execute("PRAGMA table_info(menu_items)")}
            tags = connection.execute("SELECT dietary_tags FROM menu_items WHERE id=1").fetchone()[0]
        self.assertIn("dietary_tags", columns)
        self.assertEqual(tags, "")

    def test_database_startup_makes_existing_table_number_optional(self):
        legacy_path = os.path.join(self.temp.name, "legacy_sessions.db")
        connection = sqlite3.connect(legacy_path)
        connection.execute(
            "CREATE TABLE menu_items (id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, "
            "category TEXT NOT NULL, price REAL NOT NULL, stock_qty INTEGER NOT NULL DEFAULT 0, "
            "allergens TEXT NOT NULL DEFAULT '')"
        )
        connection.execute(
            "CREATE TABLE table_sessions (session_id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "table_no INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'open')"
        )
        connection.execute(
            "CREATE TABLE order_line_items (line_id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "session_id INTEGER NOT NULL REFERENCES table_sessions(session_id), "
            "item_id INTEGER NOT NULL REFERENCES menu_items(id), quantity INTEGER NOT NULL, "
            "special_instructions TEXT NOT NULL DEFAULT '')"
        )
        connection.execute(
            "INSERT INTO menu_items VALUES (1, 'Legacy item', 'Coffee', 10, 2, '')"
        )
        connection.execute("INSERT INTO table_sessions(table_no) VALUES (7)")
        connection.execute("INSERT INTO order_line_items(session_id,item_id,quantity) VALUES (1,1,1)")
        connection.commit()
        connection.close()

        db.DB_PATH = legacy_path
        db.init_db()

        with db.conn() as connection:
            session = connection.execute(
                "SELECT table_no FROM table_sessions WHERE session_id=1"
            ).fetchone()
            line_count = connection.execute(
                "SELECT COUNT(*) FROM order_line_items WHERE session_id=1"
            ).fetchone()[0]
            new_session_id = db.create_session(None)
            new_session = connection.execute(
                "SELECT table_no FROM table_sessions WHERE session_id=?",
                (new_session_id,),
            ).fetchone()
            violations = connection.execute("PRAGMA foreign_key_check").fetchall()
            table_no = next(
                row for row in connection.execute("PRAGMA table_info(table_sessions)")
                if row["name"] == "table_no"
            )
        self.assertEqual(session["table_no"], 7)
        self.assertEqual(line_count, 1)
        self.assertIsNone(new_session["table_no"])
        self.assertEqual(table_no["notnull"], 0)
        self.assertEqual(violations, [])

    def test_out_of_stock_add_returns_available_same_category_options(self):
        result = self.agent._run_tool("add_item_to_order", {"item_name": "Smoked Salmon Bagel", "qty": 3})
        self.assertFalse(result["ok"])
        self.assertTrue("out of stock" in result["error"].lower() or "only 2" in result["error"].lower())
        alternatives = {item["name"] for item in result["alternatives"]}
        self.assertTrue(alternatives)
        self.assertNotIn("Smoked Salmon Bagel", alternatives)

    def test_menu_and_allergen_answers_are_database_grounded(self):
        drinks = self.agent.handle_user("What drinks do you have?")
        self.assertIn("Matcha Latte", drinks)
        self.assertNotIn("Soft Drinks", drinks)
        allergen = self.agent.handle_user("Does the pesto penne contain nuts?")
        self.assertIn("nuts is listed", allergen.lower())
        self.assertNotIn("not listed", allergen.lower())

    def test_combo_side_and_drink_selection_affects_price_and_inventory(self):
        result = db.add_combo_to_order(
            self.session_id, "Cafe Brunch Combo", side_name="Garden Salad", drink_name="Matcha Latte"
        )
        self.assertTrue(result["ok"], result)
        item = result["order"]["items"][0]
        self.assertEqual((item["side_name"], item["drink_name"]), ("Garden Salad", "Matcha Latte"))
        self.assertEqual(item["unit_price"], 350)
        with db.conn() as connection:
            reserved = db._reserved_components(connection)
        self.assertEqual(reserved[9], 1)
        self.assertEqual(reserved[11], 1)
        self.assertNotIn(8, reserved)
        receipt = db.confirm_order(self.session_id)["receipt"]
        self.assertEqual(receipt["items"][0]["line_total"], 350)
        with db.conn() as connection:
            stock = {row["name"]: row["stock_qty"] for row in
                     connection.execute("SELECT name,stock_qty FROM menu_items")}
        self.assertEqual(stock["Garden Salad"], 15)
        self.assertEqual(stock["Matcha Latte"], 19)
        self.assertEqual(stock["French Fries"], 30)
        self.assertEqual(stock["Cold Brew Coffee"], 40)

    def test_combo_choices_create_separate_lines_and_reject_wrong_categories(self):
        first = db.add_combo_to_order(self.session_id, "Cafe Brunch Combo",
                                      side_name="Garden Salad", drink_name="Matcha Latte")
        second = db.add_combo_to_order(self.session_id, "Cafe Brunch Combo",
                                       side_name="French Fries", drink_name="Cold Brew Coffee")
        self.assertTrue(first["ok"])
        self.assertTrue(second["ok"])
        self.assertEqual(len(second["order"]["items"]), 2)
        invalid = db.add_combo_to_order(self.session_id, "Cafe Brunch Combo",
                                        side_name="Matcha Latte", drink_name="Cold Brew Coffee")
        self.assertFalse(invalid["ok"])
        self.assertIn("not a sides option", invalid["error"])

    def test_combo_selection_allergens_include_selected_drink(self):
        result = db.add_combo_to_order(self.session_id, "Avocado Toast Combo",
                                       side_name="Garden Salad", drink_name="Matcha Latte")
        self.assertTrue(result["ok"], result)
        line = result["order"]["items"][0]
        allergens = db.get_order_item_allergens(line["line_id"])
        self.assertIn("dairy", allergens["allergens"].split(","))
        self.assertIn("gluten", allergens["allergens"].split(","))

    def test_combo_upgrade_keeps_customization_and_selected_meal_options(self):
        added = db.add_item_to_order(self.session_id, "Club Sandwich", 1, "no onions")
        line_id = added["order"]["items"][0]["line_id"]
        result = db.upgrade_to_combo(
            self.session_id, line_id, "Cafe Brunch Combo",
            side_name="Garden Salad", drink_name="Matcha Latte",
        )
        self.assertTrue(result["ok"], result)
        item = result["order"]["items"][0]
        self.assertEqual(item["instructions"], "no onions")
        self.assertEqual((item["side_name"], item["drink_name"]), ("Garden Salad", "Matcha Latte"))
        self.assertEqual(item["unit_price"], 350)

    def test_accepting_chat_combo_offer_prompts_for_and_applies_choices(self):
        added = db.add_item_to_order(self.session_id, "Club Sandwich", 1, "no onions")
        line_id = added["order"]["items"][0]["line_id"]
        recommendation = next(
            item for item in db.get_combo_recommendations(self.session_id)["recommendations"]
            if item["line_id"] == line_id
        )
        self.agent.pending_combo_offer = {
            "line_id": line_id, "combo_name": recommendation["combo_name"],
            "combo_id": recommendation["combo_id"],
        }

        prompt = self.agent.handle_user("Yes, upgrade it")
        self.assertIn("Which side and drink", prompt)
        self.assertEqual(db.view_current_order(self.session_id)["items"][0]["name"], "Club Sandwich")

        drink_prompt = self.agent.handle_user("Garden Salad")
        self.assertIn("drink", drink_prompt.lower())
        unchanged = db.view_current_order(self.session_id)["items"][0]
        self.assertEqual(unchanged["name"], "Club Sandwich")
        self.assertIsNone(unchanged.get("side_name"))

        upgraded = self.agent.handle_user("Matcha Latte")
        self.assertIn("tab has been updated", upgraded)
        item = db.view_current_order(self.session_id)["items"][0]
        self.assertEqual(item["name"], "Cafe Brunch Combo")
        self.assertEqual((item["side_name"], item["drink_name"]), ("Garden Salad", "Matcha Latte"))
        self.assertEqual(item["instructions"], "no onions")
        self.assertIsNone(self.agent.pending_combo_upgrade)

    def test_acceptance_with_both_meal_choices_upgrades_immediately(self):
        added = db.add_item_to_order(self.session_id, "Chicken Pesto Panini", 1)
        line_id = added["order"]["items"][0]["line_id"]
        recommendation = next(
            item for item in db.get_combo_recommendations(self.session_id)["recommendations"]
            if item["line_id"] == line_id
        )
        self.agent.pending_combo_offer = {
            "line_id": line_id, "combo_name": recommendation["combo_name"],
            "combo_id": recommendation["combo_id"],
        }
        reply = self.agent.handle_user("Yes, Garden Salad and Matcha Latte")
        self.assertIn("tab has been updated", reply)
        item = db.view_current_order(self.session_id)["items"][0]
        self.assertEqual(item["name"], "Panini Coffee Meal")
        self.assertEqual((item["side_name"], item["drink_name"]), ("Garden Salad", "Matcha Latte"))

    def test_quantity_edit_and_ambiguous_customized_removal(self):
        first = db.add_item_to_order(self.session_id, "Club Sandwich", 1, "no onions")
        second = db.add_item_to_order(self.session_id, "Club Sandwich", 1, "extra cheese")
        lines = db.view_current_order(self.session_id)["items"]
        ambiguous = db.remove_item_from_order(self.session_id, "Club Sandwich", 1)
        self.assertTrue(ambiguous["clarification_required"])
        updated = db.set_line_quantity(self.session_id, lines[0]["line_id"], 2)
        self.assertTrue(updated["ok"])
        items = db.view_current_order(self.session_id)["items"]
        self.assertEqual(items[0]["quantity"], 2)
        self.assertEqual(items[1]["instructions"], "extra cheese")

    def test_cancellation_requires_confirmation_and_releases_stock(self):
        self.agent._run_tool("add_item_to_order", {"item_name": "Smoked Salmon Bagel", "qty": 1})
        reply = self.agent.handle_user("Cancel my whole order")
        self.assertIn("Reply yes", reply)
        waiting = fsm_agent.WaiterAgent()
        self.assertEqual(waiting.pending_confirmation, "cancel_order")
        self.assertEqual(len(db.view_current_order(self.session_id)["items"]), 1)
        cancelled = waiting.handle_user("yes")
        self.assertIn("order has been cancelled", cancelled)
        self.assertIsNone(waiting.session_id)
        with db.conn() as connection:
            status = connection.execute("SELECT status FROM table_sessions WHERE session_id=?",
                                        (self.session_id,)).fetchone()[0]
        self.assertEqual(status, "cancelled")
        self.assertEqual(db.get_menu_by_category("Mains")["items"][-1]["available_qty"], 2)

    def test_non_yes_no_interrupt_does_not_cancel_order(self):
        self.agent._run_tool("add_item_to_order", {"item_name": "Club Sandwich", "qty": 1})
        self.agent.handle_user("cancel my order")
        response = self.agent.handle_user("What drinks do you have?")
        self.assertIn("Cold Brew Coffee", response)
        self.assertNotIn("Soft Drinks", response)
        self.assertEqual(len(db.view_current_order(self.session_id)["items"]), 1)

    def test_db_mutating_functions_require_active_open_session(self):
        res1 = db.add_item_to_order(None, "Club Sandwich", 1)
        self.assertFalse(res1["ok"])
        self.assertIn("No active table session", res1["error"])

        res2 = db.add_combo_to_order(None, "Cafe Brunch Combo", "French Fries", "Cold Brew Coffee", 1)
        self.assertFalse(res2["ok"])
        self.assertIn("No active table session", res2["error"])

        res3 = db.remove_item_from_order(None, "Club Sandwich")
        self.assertFalse(res3["ok"])
        self.assertIn("No active table session", res3["error"])

        res4 = db.confirm_order(None)
        self.assertFalse(res4["ok"])
        self.assertIn("No active table session", res4["error"])

    def test_db_confirm_twice_rejected(self):
        db.add_item_to_order(self.session_id, "Club Sandwich", 1)
        first = db.confirm_order(self.session_id)
        self.assertTrue(first["ok"])
        with db.conn() as c:
            stock_after_first = c.execute("SELECT stock_qty FROM menu_items WHERE name='Club Sandwich'").fetchone()[0]
        second = db.confirm_order(self.session_id)
        self.assertFalse(second["ok"])
        with db.conn() as c:
            stock_after_second = c.execute("SELECT stock_qty FROM menu_items WHERE name='Club Sandwich'").fetchone()[0]
        self.assertEqual(stock_after_first, stock_after_second)

    def test_order_session_starts_without_table_number(self):
        agent = fsm_agent.WaiterAgent()
        agent.reset()
        self.assertEqual(agent.state, fsm_agent.ORDERING)
        self.assertIsNone(agent.table_no)
        self.assertIsNotNone(agent.session_id)
        with db.conn() as connection:
            session = connection.execute(
                "SELECT table_no FROM table_sessions WHERE session_id=?",
                (agent.session_id,),
            ).fetchone()
        self.assertIsNone(session["table_no"])

        res = agent._run_tool("add_item_to_order", {"item_name": "Espresso", "qty": 1})
        self.assertTrue(res["ok"], res)

    def test_customer_session_reset_succeeds_after_cancellation_and_repeatedly(self):
        agent = fsm_agent.WaiterAgent()
        original_session_id = agent.session_id
        cancelled = db.cancel_order(original_session_id)
        self.assertTrue(cancelled["ok"], cancelled)

        agent.reset()
        first_reset_session_id = agent.session_id
        self.assertNotEqual(first_reset_session_id, original_session_id)
        self.assertEqual(agent.transcript[-1]["role"], "waiter")

        agent.reset()
        self.assertNotEqual(agent.session_id, first_reset_session_id)
        self.assertEqual(agent.state, fsm_agent.ORDERING)

    def test_catalog_query_needs_no_table_number(self):
        agent = fsm_agent.WaiterAgent()
        agent.reset()
        reply = agent.handle_user("What drinks do you have?")
        self.assertIn("Matcha Latte", reply)
        self.assertNotIn("table number", reply.lower())
        self.assertEqual(agent.state, fsm_agent.ORDERING)

    def test_table_number_is_not_requested_or_saved(self):
        agent = fsm_agent.WaiterAgent()
        agent.reset()
        reply = agent.handle_user("Table 7")
        self.assertIn("No table number is needed", reply)
        self.assertIsNone(agent.table_no)

    def test_order_can_be_confirmed_without_table_number(self):
        self.agent.reset()
        add_result = self.agent._run_tool(
            "add_item_to_order", {"item_name": "Espresso", "qty": 1}
        )
        self.assertTrue(add_result["ok"], add_result)

        self.agent.go_review()
        confirmation = self.agent.confirm()

        self.assertEqual(self.agent.state, fsm_agent.CONFIRMED)
        self.assertIsNone(self.agent.snapshot()["receipt"]["table_no"])
        self.assertIn("order has been confirmed", confirmation.lower())
        self.assertNotIn("Table", confirmation)

    def test_is_menu_browse_request_standalone_menu(self):
        for phrase in ("menu", "Menu", "MENU", "menu please", "menu!"):
            with self.subTest(phrase=phrase):
                self.assertTrue(fsm_agent.is_menu_browse_request(phrase))

    def test_adjust_line_during_review_transitions_and_notifies(self):
        self.agent._run_tool("add_item_to_order", {"item_name": "Club Sandwich", "qty": 1})
        self.agent.go_review()
        self.assertEqual(self.agent.state, fsm_agent.REVIEW)
        line_id = db.view_current_order(self.session_id)["items"][0]["line_id"]
        res = self.agent.adjust(line_id, 1)
        self.assertTrue(res["ok"])
        self.assertEqual(self.agent.state, fsm_agent.TAKING_ORDER)
        self.assertIn("Your order was adjusted", self.agent.transcript[-1]["text"])


if __name__ == "__main__":
    unittest.main()
