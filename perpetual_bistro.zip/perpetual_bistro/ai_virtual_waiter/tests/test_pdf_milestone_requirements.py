"""Unit tests verifying all specific PDF rubric requirements, FSM guardrails, and edge cases.
"""
import os
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

import numpy as np
import db_tools as db
import fsm_controller
from speech_engine import SpeechEngine


class PdfMilestoneRequirementsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        db.DB_PATH = os.path.join(self.temp.name, "restaurant.db")
        fsm_controller.LOG_PATH = os.path.join(self.temp.name, "conversation.json")
        db.init_db()
        self.agent = fsm_controller.WaiterAgent()
        self.agent.reset()

    def tearDown(self):
        self.temp.cleanup()

    def test_database_builds_and_contains_required_tables_and_views(self):
        with db.conn() as c:
            tables = [r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type IN ('table', 'view')")]
        self.assertIn("menu_items", tables)
        self.assertIn("table_sessions", tables)
        self.assertIn("order_line_items", tables)
        self.assertIn("cart_items", tables)

    def test_ordering_starts_without_a_table_number(self):
        self.assertEqual(self.agent.state, fsm_controller.ORDERING)
        self.assertIsNone(self.agent.table_no)
        self.assertIsNotNone(self.agent.session_id)

    def test_excess_blueberry_muffin_quantity_is_blocked(self):
        # Ordering is available immediately, without a table number.
        self.assertIsNone(self.agent.table_no)
        self.assertEqual(self.agent.state, fsm_controller.ORDERING)

        result = db.add_item_to_order_tool(self.agent.session_id, "Blueberry Muffin", 19)
        self.assertFalse(result["ok"])
        self.assertIn("Only 18 x Blueberry Muffin available", result["error"])
        self.assertTrue(result.get("out_of_stock"))
        self.assertGreater(len(result.get("alternatives", [])), 0)

    def test_excess_blueberry_muffin_quantity_returns_alternatives(self):
        self.assertIsNone(self.agent.table_no)
        # Blueberry Muffin starts with 18 portions; attempt to order more.
        result = db.add_item_to_order_tool(self.agent.session_id, "Blueberry Muffin", 20)
        self.assertFalse(result["ok"])
        self.assertIn("Only 18 x Blueberry Muffin available", result["error"])
        self.assertTrue(result.get("out_of_stock"))
        self.assertGreater(len(result.get("alternatives", [])), 0)

    def test_cannot_modify_or_cancel_order_after_confirmed(self):
        self.agent.handle_user("Table 8")
        self.agent._run_tool("add_item_to_order_tool", {"item_name": "Café Latte", "qty": 1})
        self.agent.go_review()
        self.assertEqual(self.agent.state, fsm_controller.REVIEW)

        # Confirm the order
        confirm_reply = self.agent.handle_user("Confirm order")
        self.assertEqual(self.agent.state, fsm_controller.CONFIRMED)
        self.assertIn("OFFICIAL RECEIPT", confirm_reply)

        # Attempt edge case 1: Add item in CONFIRMED state
        add_attempt = db.add_item_to_order_tool(self.agent.session_id, "French Fries", 1)
        self.assertFalse(add_attempt["ok"])
        self.assertIn("already confirmed", add_attempt["error"])

        # Attempt edge case 2: Cancel order in CONFIRMED state
        cancel_attempt = db.cancel_order(self.agent.session_id)
        self.assertFalse(cancel_attempt["ok"])
        self.assertIn("already confirmed", cancel_attempt["error"])

        # Agent chat rejection in CONFIRMED state
        chat_reply = self.agent.handle_user("Please cancel my order")
        self.assertIn("Cannot cancel order: order is already confirmed", chat_reply)
        self.assertEqual(self.agent.state, fsm_controller.CONFIRMED)

    def test_off_topic_questions_are_rejected(self):
        self.agent.handle_user("Table 2")
        reply = self.agent.handle_user("What's the weather like today?")
        self.assertIn("Perpetual Bistro", reply)
        self.assertIn("food order and our menu", reply)

    def test_crud_wrapper_and_cart_totals(self):
        session_id = db.create_session(4)
        db.add_item_to_order_tool(session_id, "Café Latte", 2, "extra hot")
        db.add_item_to_order_tool(session_id, "Blueberry Muffin", 1)

        summary = db.get_cart_summary(session_id)
        self.assertEqual(len(summary["items"]), 2)
        # Café Latte: 2 * 140 = 280, Blueberry Muffin: 110 => Subtotal: 390
        self.assertEqual(summary["subtotal"], 390.0)
        # Service fee: 39.0 => Total: 429.0
        self.assertEqual(summary["service_fee"], 39.0)
        self.assertEqual(summary["total"], 429.0)

    def test_speech_engine_instantiation_and_tuning(self):
        engine = SpeechEngine(tts_rate=175, tts_volume=0.9)
        self.assertEqual(engine.tts_rate, 175)
        self.assertEqual(engine.tts_volume, 0.9)

    def test_speech_engine_uses_local_whisper_with_voice_activity_filtering(self):
        model_options = {}
        transcription_options = {}
        waveform = np.sin(np.arange(16000, dtype=np.float32) * (2 * np.pi * 440 / 16000)) * 0.005

        class FakeWhisperModel:
            def __init__(self, model_name, **options):
                model_options["model_name"] = model_name
                model_options.update(options)

            def transcribe(self, audio_path, **options):
                transcription_options["audio"] = audio_path
                transcription_options.update(options)
                return iter((types.SimpleNamespace(text=" Add two "),)), None

        whisper_module = types.ModuleType("faster_whisper")
        whisper_module.__path__ = []
        whisper_module.WhisperModel = FakeWhisperModel
        audio_module = types.ModuleType("faster_whisper.audio")
        audio_module.decode_audio = lambda path, sampling_rate: waveform
        with patch.dict(sys.modules, {
            "faster_whisper": whisper_module,
            "faster_whisper.audio": audio_module,
        }):
            engine = SpeechEngine(tts_rate=175, tts_volume=0.9)
            transcript = engine.transcribe_audio_file("recording.webm")

        self.assertEqual(transcript, "Add two")
        self.assertEqual(model_options["model_name"], "medium.en")
        self.assertEqual(model_options["device"], "cpu")
        self.assertEqual(model_options["compute_type"], "int8")
        self.assertTrue(transcription_options["vad_filter"])
        self.assertEqual(transcription_options["language"], "en")
        self.assertEqual(transcription_options["beam_size"], 5)
        enhanced_audio = transcription_options["audio"]
        self.assertIsInstance(enhanced_audio, np.ndarray)
        self.assertGreater(float(np.sqrt(np.mean(np.square(enhanced_audio)))), 0.005)
        self.assertLessEqual(float(np.max(np.abs(enhanced_audio))), 0.95)

    def test_whisper_status_reports_installation_without_loading_model(self):
        engine = SpeechEngine(tts_rate=175, tts_volume=0.9)
        with patch.dict(os.environ, {"WHISPER_MODEL": "  "}):
            with patch("speech_engine.importlib.util.find_spec", return_value=object()):
                with patch("speech_engine.importlib.metadata.version", return_value="1.2.1"):
                    status = engine.whisper_status()

        self.assertTrue(status["available"])
        self.assertEqual(status["model"], "medium.en")
        self.assertEqual(status["version"], "1.2.1")
        self.assertFalse(status["loaded"])

    def test_microphone_listener_sends_recording_to_local_transcriber(self):
        class FakeMicrophone:
            def __enter__(self):
                return object()

            def __exit__(self, exc_type, exc_value, traceback):
                return False

        class FakeAudio:
            def get_wav_data(self):
                return b"local microphone audio"

        class FakeRecognizer:
            def adjust_for_ambient_noise(self, source, duration):
                self.calibration_duration = duration

            def listen(self, source, timeout, phrase_time_limit):
                return FakeAudio()

        engine = SpeechEngine(tts_rate=175, tts_volume=0.9)
        engine.recognizer = FakeRecognizer()

        def transcribe_recording(path):
            with open(path, "rb") as audio_file:
                self.assertEqual(audio_file.read(), b"local microphone audio")
            return "One cappuccino"

        with patch("speech_engine.sr.Microphone", return_value=FakeMicrophone()):
            with patch.object(engine, "transcribe_audio_file", side_effect=transcribe_recording):
                self.assertEqual(engine.listen(), "One cappuccino")


if __name__ == "__main__":
    unittest.main()
