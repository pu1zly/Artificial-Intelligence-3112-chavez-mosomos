"""Finite-State Controller + Ollama Qwen 2.5 Tool-Calling Loop with Session Memory.
Implements strict FSM states:
    GREETING -> ORDERING starts a table-free order session.
    ORDERING -> Processes tool calls for cart modifications & guardrails.
    REVIEW -> Presents itemized cart and subtotal for customer verification.
    CONFIRMED -> Commits transaction and locks cart modifications.
"""
import datetime
import json
import os
import re
import unicodedata

import ollama

try:
    import db_tools as db
    from ollama_models import select_qwen_model
except ImportError:
    from ai_virtual_waiter import db_tools as db
    from ai_virtual_waiter.ollama_models import select_qwen_model

MODEL = os.environ.get("OLLAMA_MODEL", "").strip()
OLLAMA_CLIENT = ollama.Client(timeout=120)
LOG_PATH = os.path.join(db.HERE, "sample_conversation_log.json")


class FSMState(str):
    """String subclass that matches both plain and STATE_ prefixed names."""
    def __eq__(self, other):
        if super().__eq__(other):
            return True
        s = str(self).replace("STATE_", "")
        o = str(other).replace("STATE_", "")
        if s == "TAKING_ORDER":
            s = "ORDERING"
        if o == "TAKING_ORDER":
            o = "ORDERING"
        return s == o

    def __hash__(self):
        s = str(self).replace("STATE_", "")
        if s == "TAKING_ORDER":
            s = "ORDERING"
        return hash(s)


GREETING = FSMState("STATE_GREETING")
ORDERING = FSMState("STATE_TAKING_ORDER")
TAKING_ORDER = ORDERING
REVIEW = FSMState("STATE_REVIEW")
CONFIRMED = FSMState("STATE_CONFIRMED")

STATE_GREETING = GREETING
STATE_TAKING_ORDER = ORDERING
STATE_ORDERING = ORDERING
STATE_REVIEW = REVIEW
STATE_CONFIRMED = CONFIRMED

CONFIRM_RE = re.compile(
    r"^\s*(?:(?:yes|yep|yeah)(?:[,.]?\s*(?:please|confirm(?: it|(?: the)? order)?|go ahead|"
    r"let'?s confirm|let'?s do it))?|confirm(?: it|(?: the)? order)?|confirmed|ok(?:ay)?|correct|"
    r"looks good|send it|that'?s right|please confirm(?: it|(?: the)? order)?)[.! ]*$", re.I
)
DECLINE_RE = re.compile(
    r"^\s*(?:no|no thanks|keep it|keep my order|don't cancel|do not cancel)[.! ]*$", re.I
)
UPGRADE_ACCEPT_RE = re.compile(
    r"^\s*(?:yes|yep|yeah|sure|okay|ok|please do|do it|upgrade(?: it)?(?: please)?|"
    r"make it a meal|let's do it|sounds good|i(?:'d| would) like that)(?:\b|[,!.])",
    re.I,
)
CANCEL_ORDER_RE = re.compile(
    r"^\s*(?:(?:(?:i want to|i would like to|i'd like to|please)\s+)?"
    r"(?:cancel|clear)\s+(?:(?:my|the|whole|entire)\s+)*(?:order|tab|everything)"
    r"|start over|start a new order)[.! ]*$", re.I
)
REVIEW_RE = re.compile(
    r"^\s*(?:that'?s all|that is all|i'?m done(?: ordering)?|im done(?: ordering)?|i am done(?: ordering)?|"
    r"done|i'?m finished(?: ordering)?|"
    r"finish(?: ordering)?|review(?: my order)?|show(?: me)? (?:my )?(?:bill|tab|order)|"
    r"(?:the )?bill|check ?out|nothing else|no thanks|that'?s everything|that is everything)"
    r"[.! ]*$", re.I
)
OFF_TOPIC_RE = re.compile(
    r"\b(?:weather|temperature|forecast|rain|snow|football|basketball|soccer|"
    r"nba|who is the president|election|politics|write a python script|write code|"
    r"solve this math|capital of)\b",
    re.I
)
ADD_ORDER_ACTION_RE = re.compile(
    r"^\s*(?:(?:please\s+)?(?:add|order|get|have)\b|"
    r"(?:can|could|would)\s+you\s+(?:please\s+)?(?:add|order|get|have)\b|"
    r"(?:can|could|may)\s+i\s+(?:please\s+)?(?:get|have|order)\b|"
    r"i\s+(?:want|need|would like)\s+to\s+(?:add|order|get|have)\b|"
    r"i['’]d\s+(?:(?:like|want)\s+to\s+(?:add|order|get|have)|(?:like|want))\b|"
    r"i\s+(?:want|need|would like|will have)\b|i['’]d\s+(?:like|want)\b)",
    re.I,
)
REMOVE_ORDER_ACTION_RE = re.compile(
    r"^\s*(?:(?:please\s+)?(?:remove|take off|take out|delete|drop|subtract)\b|"
    r"(?:can|could|would)\s+you\s+(?:please\s+)?(?:remove|take off|take out|delete|drop)\b|"
    r"i\s+(?:want|need|would like)\s+to\s+(?:remove|take off|take out|delete|drop)\b)",
    re.I,
)
ORDER_QUANTITY_RE = re.compile(
    r"(?:^|\s)(all|every|another|a|an|"
    r"zero|one|two|three|four|five|six|seven|eight|nine|ten|"
    r"eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|"
    r"eighteen|nineteen|twenty|couple|pair|few|several|\d+)"
    r"(?:\s+more)?(?:\s+of)?(?:\s+(?:cup|cups|item|items))?\s*$",
    re.I,
)
ORDER_QUANTITY_VALUES = {
    "zero": 0, "one": 1, "a": 1, "an": 1, "another": 1,
    "two": 2, "couple": 2, "pair": 2, "three": 3, "few": 3, "several": 4,
    "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8,
    "nine": 9, "ten": 10, "eleven": 11, "twelve": 12,
    "thirteen": 13, "fourteen": 14, "fifteen": 15, "sixteen": 16,
    "seventeen": 17, "eighteen": 18, "nineteen": 19, "twenty": 20,
}


def _tool(name, desc, props=None, req=()):
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": desc,
            "parameters": {
                "type": "object",
                "properties": props or {},
                "required": list(req)
            }
        }
    }


TOOLS = [
    _tool("get_menu_items", "Query the Perpetual Bistro Café menu by category. Ground truth for names, prices, allergens, stock.",
          {"category": {"type": "string", "description": "Category name: Coffee, Frappes, Milkshakes, Tea & Refreshers, Pastries, or all."}}),
    _tool("add_item_to_order_tool", "Add a café menu item to the active tab. Put customizations in instructions.",
          {"item_name": {"type": "string", "description": "Exact menu item name"},
           "qty": {"type": "integer", "description": "Quantity (default 1)"},
           "instructions": {"type": "string", "description": "Special preparation instructions or customizations"}},
          req=("item_name",)),
    _tool("get_cart_summary", "View the current order items, quantities, special instructions, subtotal, service fee, and total.", {}),
    _tool("find_available_alternatives", "Find in-stock alternatives in the same category when an item is out of stock.",
          {"item_name": {"type": "string", "description": "The item that is low or out of stock"},
           "qty": {"type": "integer", "description": "Required quantity"}},
          req=("item_name",)),
    _tool("check_item_allergen", "Check whether a menu item lists a specific allergen.",
          {"item_name": {"type": "string", "description": "Menu item name"},
           "allergen": {"type": "string", "description": "Allergen: dairy, gluten, egg, soy, fish, nuts, sesame, shellfish"}},
          req=("item_name", "allergen")),
    _tool("remove_item_from_order", "Remove an item from the customer's tab.",
          {"item_name": {"type": "string", "description": "Name of item to remove"},
           "qty": {"type": "integer", "description": "Quantity to remove"},
           "instructions": {"type": "string", "description": "Instructions of specific line to remove"}},
          req=("item_name",)),
    _tool("set_line_quantity", "Set the exact quantity of a specific cart line by line_id. Set to 0 to remove.",
          {"line_id": {"type": "integer", "description": "Line ID from cart"},
           "quantity": {"type": "integer", "description": "New quantity"}},
          req=("line_id", "quantity")),
]


def detect_menu_diet_filter(text):
    normalized = (text or "").casefold()
    menu_request = re.search(
        r"\b(?:what|which|show|list|menu|available|can i see|could i see|options?|meals?|combos?)\b",
        normalized,
    )
    if not menu_request:
        return None
    aliases = (
        ("tree nuts", "nuts"), ("peanuts", "nuts"), ("peanut", "nuts"),
        ("shellfish", "shellfish"), ("gluten", "gluten"), ("wheat", "gluten"),
        ("dairy", "dairy"), ("milk", "dairy"), ("eggs", "egg"), ("egg", "egg"),
        ("soy", "soy"), ("fish", "fish"), ("sesame", "sesame"), ("nuts", "nuts"), ("nut", "nuts"),
    )
    alias_pattern = "|".join(re.escape(label) for label, _ in aliases)
    exclusion = re.search(
        rf"\b(?:without(?:\s+any)?|no|free\s+of)\s+({alias_pattern})\b", normalized
    )
    if not exclusion:
        exclusion = re.search(rf"\b({alias_pattern})[\s-]*free\b", normalized)
    if exclusion:
        requested = exclusion.group(1).casefold()
        allergen = next(value for label, value in aliases if label == requested)
        return f"allergen-free:{allergen}"
    return next((diet for diet in ("vegetarian", "vegan") if diet in normalized), None)


def menu_filter_label(filter_key):
    if filter_key.startswith("allergen-free:"):
        allergen = filter_key.split(":", 1)[1]
        return f"No {allergen} (listed allergens)"
    return filter_key.title() if filter_key in ("vegetarian", "vegan") else "All items"


def allergen_filter_options():
    return tuple(menu_filter_label(f"allergen-free:{allergen}") for allergen in (
        "dairy", "egg", "gluten", "soy",
    ))


def menu_filter_key(filter_label):
    normalized = (filter_label or "").strip().casefold()
    if normalized.startswith("no ") and " (listed allergens)" in normalized:
        allergen = normalized[3:].split(" (listed allergens)", 1)[0]
        return f"allergen-free:{allergen}"
    if normalized in ("vegetarian", "vegan"):
        return normalized
    return "all"


def is_menu_browse_request(text):
    normalized = (text or "").casefold().strip()
    if re.match(r"^menu\s*[.!?]*$", normalized):
        return True
    return bool(re.search(
        r"\b(?:"
        r"(?:can|could|may)\s+i\s+(?:please\s+)?(?:see|view|browse|open)\s+"
        r"(?:the\s+)?(?:full\s+)?menu\b|"
        r"(?:show|open|display|browse)\s+(?:me\s+)?(?:the\s+)?(?:full\s+)?menu\b|"
        r"(?:let\s+me\s+)?(?:see|view|browse)\s+(?:the\s+)?menu\b|"
        r"menu\s+(?:please|screen)"
        r")\b",
        normalized,
    ))


def _format_menu_items(items, include_stock=False):
    category_order = (
        ("Coffee", "Coffee"), ("Frappes", "Frappes"), ("Milkshakes", "Milkshakes"),
        ("Tea & Refreshers", "Tea & Refreshers"), ("Pastries", "Pastries"),
    )
    groups = []
    for category, heading in category_order:
        category_items = [item for item in items if item["category"] == category]
        if not category_items:
            continue
        lines = [heading + ":"]
        for item in category_items:
            stock = f" ({item['available_qty']} available)" if include_stock and item.get("available_qty") is not None else ""
            lines.append(f"  - {item['name']} (PHP {item['price']:.2f}){stock}")
        groups.append("\n".join(lines))
    return "\n\n".join(groups)


def _normalize_order_text(text):
    normalized = unicodedata.normalize("NFKD", text.casefold())
    return " ".join(
        "".join(char for char in normalized if not unicodedata.combining(char))
        .replace("’", "'")
        .split()
    )


def _parse_order_quantity(text, default):
    normalized = text.casefold().strip()
    normalized = re.sub(r"\b(?:the|my|order|tab|please)\b", " ", normalized)
    if re.search(r"\b(?:a\s+)?number\s+of\b", normalized):
        return "unspecified"
    if re.search(r"\b(?:all|every)\b", normalized):
        return None
    normalized = re.sub(r"\bof\s*$", "", normalized).strip()
    match = ORDER_QUANTITY_RE.search(normalized)
    if not match:
        return default
    value = match.group(1).casefold()
    if value.isdigit():
        return int(value)
    return ORDER_QUANTITY_VALUES.get(value, default)


def _parse_quantity_followup(text):
    normalized = _normalize_order_text(text).strip(" \t.,!?")
    normalized = re.sub(r"^please\s+|\s+please$", "", normalized)
    normalized = re.sub(r"^a\s+(?=(?:couple|pair|few|several)\b)", "", normalized)
    match = ORDER_QUANTITY_RE.fullmatch(normalized)
    if not match:
        return None
    quantity = match.group(1).casefold()
    if quantity.isdigit():
        return int(quantity)
    if quantity in ("all", "every"):
        return None
    return ORDER_QUANTITY_VALUES.get(quantity, 1)


def _parse_cart_quantity_request(text, menu_items):
    normalized = _normalize_order_text(text)
    matches = []
    for item in sorted(menu_items, key=lambda entry: len(entry["name"]), reverse=True):
        item_name = _normalize_order_text(item["name"])
        name_parts = item_name.rsplit(" ", 1)
        if name_parts[-1].endswith("y"):
            last_word = re.escape(name_parts[-1][:-1]) + r"(?:y|ies)"
        elif name_parts[-1].endswith("ies"):
            last_word = re.escape(name_parts[-1][:-3]) + r"(?:ies|y)"
        elif name_parts[-1].endswith("s"):
            last_word = re.escape(name_parts[-1][:-1]) + r"s?"
        else:
            last_word = re.escape(name_parts[-1]) + "s?"
        item_pattern = (
            re.escape(name_parts[0]).replace(r"\ ", r"\s+") + r"\s+"
            if len(name_parts) > 1 else ""
        ) + last_word
        match = re.search(rf"(?<!\w){item_pattern}(?!\w)", normalized)
        if match:
            matches.append((match.start(), match.end(), item, match))
    if not matches:
        return None

    distinct_matches = []
    for candidate in sorted(matches, key=lambda match: (match[0], -match[1])):
        if not any(
            candidate[0] >= existing[0] and candidate[1] <= existing[1]
            for existing in distinct_matches
        ):
            distinct_matches.append(candidate)
    if len(distinct_matches) > 1:
        return None

    earliest = min(match[0] for match in matches)
    candidates = [match for match in matches if match[0] == earliest]
    start, end, item, _ = max(candidates, key=lambda match: match[1] - match[0])
    suffix = normalized[end:].strip(" \t.,!?")
    if suffix and suffix not in (
        "please", "to my order", "to the order", "to my tab", "to the tab",
        "from my order", "from the order", "from my tab", "from the tab",
    ):
        return None
    prefix = normalized[:start].strip()

    action_match = ADD_ORDER_ACTION_RE.match(prefix)
    action = "add"
    if not action_match:
        action_match = REMOVE_ORDER_ACTION_RE.match(prefix)
        action = "remove"
    if not action_match:
        return None

    quantity = _parse_order_quantity(prefix[action_match.end():], 1)
    return {"action": action, "item_name": item["name"], "quantity": quantity}


def _tool_reply(name, args, res):
    if name in ("get_menu_by_category", "get_menu_items"):
        if not res.get("ok"):
            return res.get("error", "Could not load menu.")
        items = res.get("items", [])
        if not items:
            return "No items currently match that category."
        return "Here is what we have on the menu:\n\n" + _format_menu_items(items)

    if name == "get_menu_by_dietary_filter":
        if not res.get("ok"):
            return res.get("error", "Could not apply dietary filter.")
        items = res.get("items", [])
        if not items:
            return res.get("message", "No items matched that filter.")
        allergen = res.get("allergen")
        if allergen:
            notice = (
                f"Here are items with no {allergen} listed in recorded ingredients. "
                "This is based on catalog data and is not a guarantee against cross-contact. "
                "Please verify with restaurant staff.\n\n"
            )
        else:
            notice = f"Here are the {res.get('diet')} items from our menu:\n\n"
        return notice + _format_menu_items(items)

    if name == "check_item_allergen":
        if not res.get("ok"):
            return res.get("error", "Could not check allergens.")
        contains = res.get("contains")
        item = res.get("item")
        allergen = res.get("allergen")
        all_allergens = res.get("all_allergens", "none listed")
        if contains:
            return (f"{allergen.title()} is listed for {item} (recorded allergens: {all_allergens}). "
                    "Please note that unlisted allergens are not guaranteed safe; verify with restaurant staff.")
        else:
            return (f"{allergen.title()} is not listed for {item} (recorded allergens: {all_allergens}). "
                    "Please note that not listed does not guarantee allergen-free; verify with restaurant staff.")

    if name in ("add_item_to_order", "add_item_to_order_tool"):
        if not res.get("ok"):
            err = res.get("error", "Could not add item.")
            alts = res.get("alternatives", [])
            if alts:
                alt_names = ", ".join(f"{a['name']} (PHP {a['price']:.2f})" for a in alts[:3])
                return f"{err} Would you like one of these in-stock alternatives: {alt_names}?"
            return err
        return res.get("message", "Item added to your order.")

    if name in ("view_current_order", "get_cart_summary"):
        items = res.get("items", [])
        if not items:
            return "Your cart is currently empty."
        lines = [f"{i['quantity']}x {i['name']} - PHP {i['line_total']:.2f}" for i in items]
        return f"Current Order:\n" + "\n".join(lines) + f"\nTotal: PHP {res.get('total', 0):.2f}"

    if name == "confirm_order":
        if not res.get("ok"):
            return res.get("error", "Could not confirm order.")
        receipt = res.get("receipt", {})
        return f"Order confirmed! Total: PHP {receipt.get('total', 0):.2f}. Sent to the kitchen."

    if name == "cancel_order":
        return res.get("message", res.get("error", "Could not cancel order."))

    return str(res)


class WaiterAgent:
    def __init__(self, table_no=None, session_id=None):
        self.table_no = None
        self.session_id = session_id
        self.state = GREETING
        self.history = []
        self.transcript = []
        self.activity_log = []
        self.model = ""
        self.pending_confirmation = None
        self.pending_combo_offer = None
        self.pending_combo_upgrade = None
        self.pending_cart_quantity = None
        self.last_followups = []
        self._load()
        self.table_no = None
        needs_order_prompt = self.state == GREETING
        if not self.session_id or not db.session_exists(self.session_id):
            self.session_id = db.create_session(None)
        if needs_order_prompt:
            self._go(ORDERING, "ready to take order without table selection")
        if needs_order_prompt or not self.transcript:
            self.transcript.append({
                "role": "waiter",
                "text": "Welcome to Perpetual Bistro! What can I get started for you today?",
            })
            self._persist()

    @property
    def log(self):
        return self.activity_log

    @log.setter
    def log(self, val):
        self.activity_log = val

    def reset(self):
        if self.session_id and self.state != CONFIRMED and db.session_exists(self.session_id):
            result = db.cancel_order(self.session_id)
            if not result["ok"]:
                self._log("session_reset_cancel_failed", error=result["error"])
                raise RuntimeError(result["error"])
        self.table_no = None
        self.session_id = db.create_session(None)
        self.state = ORDERING
        self.history = []
        self.transcript = []
        self.activity_log = []
        self.pending_confirmation = None
        self.pending_combo_offer = None
        self.pending_combo_upgrade = None
        self.pending_cart_quantity = None
        self.last_followups = []
        self.transcript.append({
            "role": "waiter",
            "text": "Welcome to Perpetual Bistro! What can I get started for you today?",
        })
        self._log("state_transition", prev="reset", new=str(ORDERING),
                  reason="ready to take order without table selection")
        self._persist()

    def connect(self):
        """Connect to Ollama and select the best installed Qwen chat model."""
        if self.model:
            return self.model
        try:
            installed = [m.model for m in OLLAMA_CLIENT.list().models]
            self.model = select_qwen_model(installed, requested_model=MODEL or None)
            self._log("connected", model=self.model)
            return self.model
        except Exception as e:
            self._log("ollama_connection_error", error=str(e))
            raise RuntimeError(f"Could not select an installed Qwen model: {e}") from e

    def _go(self, new_state, reason=""):
        prev = self.state
        self.state = new_state
        self._log("state_transition", prev=str(prev), new=str(new_state), reason=reason)
        self._persist()

    def _log(self, event, **kwargs):
        entry = {"time": datetime.datetime.now().isoformat(), "event": event, **kwargs}
        self.activity_log.append(entry)

    def say(self, text):
        self.transcript.append({"role": "waiter", "text": text})
        self._log("waiter_message", text=text)
        self._persist()
        return text

    def _persist(self):
        def _clean(x):
            if hasattr(x, "model_dump") and callable(x.model_dump):
                return x.model_dump()
            if hasattr(x, "__dict__"):
                return {k: str(v) if not isinstance(v, (int, float, bool, dict, list, str, type(None))) else v for k, v in x.__dict__.items()}
            return x

        clean_history = [_clean(h) for h in self.history] if self.history else []
        db.save_kiosk_state({
            "table_no": self.table_no,
            "session_id": self.session_id,
            "state": str(self.state),
            "transcript": self.transcript,
            "history": clean_history,
            "pending_confirmation": self.pending_confirmation,
            "pending_combo_offer": self.pending_combo_offer,
            "pending_combo_upgrade": self.pending_combo_upgrade,
            "pending_cart_quantity": self.pending_cart_quantity,
        })

    def _load(self):
        state = db.load_kiosk_state()
        if not state:
            return
        self.table_no = state.get("table_no")
        self.session_id = state.get("session_id")
        saved_state = state.get("state", "GREETING")
        self.state = FSMState(saved_state)
        self.transcript = state.get("transcript", [])
        self.history = state.get("history", [])
        self.pending_confirmation = state.get("pending_confirmation")
        self.pending_combo_offer = state.get("pending_combo_offer")
        self.pending_combo_upgrade = state.get("pending_combo_upgrade")
        self.pending_cart_quantity = state.get("pending_cart_quantity")

    def snapshot(self):
        order = db.view_current_order(self.session_id) if self.session_id else None
        receipt = None
        if self.state == CONFIRMED and self.session_id:
            receipt = {"session_id": self.session_id, "table_no": self.table_no, **order}
        return {
            "table_no": self.table_no,
            "session_id": self.session_id,
            "state": str(self.state),
            "transcript": list(self.transcript),
            "order": order,
            "receipt": receipt,
            "pending_confirmation": self.pending_confirmation,
            "pending_combo_offer": self.pending_combo_offer,
            "pending_combo_upgrade": self.pending_combo_upgrade,
        }

    def _run_tool(self, name, args):
        self._log("tool_call", tool=name, args=args)
        if name in ("add_item_to_order", "add_item_to_order_tool"):
            if not self.session_id:
                return {"ok": False, "error": "No active order session."}
            res = db.add_item_to_order_tool(self.session_id, args.get("item_name"),
                                            args.get("qty", 1), args.get("instructions", ""))
        elif name in ("get_menu_items", "get_menu_by_category"):
            res = db.get_menu_items(args.get("category", "all"))
        elif name == "get_menu_by_dietary_filter":
            res = db.get_menu_by_dietary_filter(args.get("diet", "all"))
        elif name in ("get_cart_summary", "view_current_order"):
            res = db.get_cart_summary(self.session_id)
        elif name == "find_available_alternatives":
            res = db.find_available_alternatives(args.get("item_name"), args.get("qty", 1))
        elif name == "check_item_allergen":
            res = db.check_item_allergen(item_name=args.get("item_name"), allergen=args.get("allergen", ""))
        elif name == "add_combo_to_order":
            res = db.add_combo_to_order(
                self.session_id, args.get("combo_name"), args.get("side_name"),
                args.get("drink_name"), args.get("qty", 1),
            )
        elif name == "remove_item_from_order":
            res = db.remove_item_from_order(self.session_id, args.get("item_name"),
                                            args.get("qty"), args.get("instructions", ""))
        elif name == "set_line_quantity":
            res = db.set_line_quantity(self.session_id, args.get("line_id"), args.get("quantity"))
        elif name == "upgrade_to_combo":
            res = db.upgrade_to_combo(
                self.session_id, args.get("line_id"), args.get("combo_name"),
                args.get("side_name"), args.get("drink_name"),
            )
        elif name == "confirm_order":
            res = db.confirm_order(self.session_id)
        elif name == "cancel_order":
            res = db.cancel_order(self.session_id)
        else:
            res = {"ok": False, "error": f"Unknown tool: {name}"}

        self._log("tool_result", tool=name, result=res)
        return res

    def begin_combo_upgrade(self, line_id, combo_name, combo_id=None):
        """Start the guided side/drink choice for an available combo recommendation."""
        recommendations = db.get_combo_recommendations(self.session_id).get("recommendations", [])
        offer = next(
            (
                recommendation for recommendation in recommendations
                if recommendation["line_id"] == int(line_id)
                and recommendation["combo_name"] == combo_name
                and (combo_id is None or recommendation["combo_id"] == int(combo_id))
            ),
            None,
        )
        if not offer or not offer["available"]:
            return self.say("That meal upgrade is no longer available. Your order is unchanged.")

        self.pending_combo_offer = None
        self.pending_combo_upgrade = {
            "line_id": offer["line_id"],
            "combo_name": offer["combo_name"],
            "combo_id": offer["combo_id"],
            "side_name": None,
            "drink_name": None,
        }
        self._persist()
        return self._handle_combo_choice("")

    def add_menu_item(self, item_name, qty=1):
        """Add a selected menu-card item directly, without relying on model tool selection."""
        text = f"Add {qty} {item_name}"
        self.transcript.append({"role": "user", "text": text})
        self._log("user_message", text=text)

        if self.state == CONFIRMED:
            result = {"ok": False, "error": "This order is already confirmed and locked."}
            reply = result["error"]
        else:
            if self.state == REVIEW:
                self._go(ORDERING, "modifying order during review")

            self.history.append({"role": "user", "content": text})
            result = self._run_tool("add_item_to_order_tool", {
                "item_name": item_name,
                "qty": qty,
            })
            reply = _tool_reply("add_item_to_order_tool", {}, result)
            self.history.append({"role": "assistant", "content": reply})

        self.say(reply)
        return result, reply

    def go_review(self):
        if self.state == GREETING:
            return self.say("Cannot review an empty order. What would you like to order?")
        if self.state == CONFIRMED:
            return self.say("Your order is already confirmed.")
        order = db.view_current_order(self.session_id)
        if not order["items"]:
            return self.say("Your order is currently empty. What would you like to order?")
        self._go(REVIEW, "customer ready to review")
        summary = self._summary()
        return self.say(f"Here is your final order review:\n{summary}\n\nWould you like me to confirm and send this to the kitchen?")

    def confirm(self):
        # Confirming is only valid after the customer has explicitly reviewed
        # the current cart.  Keep this guard on the server side as well as in
        # the dashboard so the workflow cannot be bypassed with a direct API call.
        if self.state == GREETING:
            msg = "Cannot confirm an empty order. What would you like to order?"
            self._log("illegal_transition_blocked", from_state=str(self.state), to_state="CONFIRMED")
            return self.say(msg)
        if self.state == CONFIRMED:
            return self.say("This order is already confirmed.")
        if self.state != REVIEW:
            msg = "Please review your order before confirming and paying."
            self._log("illegal_transition_blocked", from_state=str(self.state), to_state="CONFIRMED")
            return self.say(msg)
        order = db.view_current_order(self.session_id)
        if not order["items"]:
            return self.say("Cannot confirm an empty order.")

        result = db.confirm_order(self.session_id)
        self._log("confirm_order", result=result)
        if result["ok"]:
            self._go(CONFIRMED, "customer confirmed order")
            receipt = result["receipt"]
            lines = "\n".join(
                f"  - {i['quantity']}x {i['name']} (PHP {i['line_total']:.2f})"
                + (f" [{i['instructions']}]" if i['instructions'] else "")
                + (f" <Side: {i.get('side_name')}, Drink: {i.get('drink_name')}>" if i.get('side_name') else "")
                for i in receipt["items"]
            )
            msg = (
                f"Thank you! Your order has been confirmed and sent to the kitchen.\n\n"
                f"--- OFFICIAL RECEIPT ---\n"
                f"{lines}\n"
                f"Subtotal: PHP {receipt['subtotal']:.2f}\n"
                f"Service Fee (10%): PHP {receipt['service_fee']:.2f}\n"
                f"Grand Total: PHP {receipt['total']:.2f}\n"
                f"-----------------------------------------\n"
                f"Modifications are now locked."
            )
            # Auto-save sample conversation log on confirm
            try:
                with open(LOG_PATH, "w", encoding="utf-8") as f:
                    json.dump({"transcript": self.transcript, "receipt": receipt, "activity": self.activity_log}, f, indent=2)
            except Exception:
                pass
            return self.say(msg)
        else:
            return self.say(f"Could not confirm order: {result.get('error')}")

    def adjust(self, line_id, delta):
        if self.state == CONFIRMED:
            return {"ok": False, "error": "This order is already confirmed."}
        res = db.adjust_line(int(line_id), int(delta))
        if res["ok"] and self.state == REVIEW:
            self._go(ORDERING, "order edited during review")
            self.say("Your order was adjusted. Let me know when you're ready to review again.")
        self._log("manual_adjust", line_id=line_id, delta=delta, result=res)
        return res

    def delete_line(self, line_id):
        if self.state == CONFIRMED:
            return {"ok": False, "error": "Cannot delete item: order is already confirmed."}
        res = db.delete_cart_line(int(line_id))
        if res["ok"] and self.state == REVIEW:
            self._go(ORDERING, "item deleted during review")
            self.say("Item removed from your cart. Let me know when you are ready to review again.")
        self._log("manual_delete", line_id=line_id, result=res)
        return res

    def _summary(self):
        o = db.view_current_order(self.session_id)
        lines = ", ".join(
            f"{i['quantity']}x {i['name']}"
            + (f" with {i['side_name']} and {i['drink_name']}" if i.get("side_name") else "")
            + (f" ({i['instructions']})" if i["instructions"] else "")
            for i in o["items"]
        )
        return f"Your tab: {lines}. Subtotal PHP {o['subtotal']:.2f}, Service Fee PHP {o['service_fee']:.2f}, Total PHP {o['total']:.2f}."

    def _catalog_query(self, text):
        normalized = text.casefold()
        if re.search(r"\b(?:add|order|remove|cancel|change|update|make it|set quantity)\b", normalized):
            return None

        if re.search(r"\b(?:allerg(?:y|ies|en|ens)|contain(?:s)?|have|free of)\b", normalized):
            items = self._run_tool("get_menu_items", {"category": "all"})["items"]
            item = next((item for item in sorted(items, key=lambda entry: len(entry["name"]), reverse=True)
                         if item["name"].casefold() in normalized), None)
            if item:
                allergen_aliases = (
                    ("tree nuts", "nuts"), ("peanuts", "nuts"), ("peanut", "nuts"),
                    ("shellfish", "shellfish"), ("gluten", "gluten"), ("wheat", "gluten"),
                    ("dairy", "dairy"), ("milk", "dairy"), ("egg", "egg"),
                    ("soy", "soy"), ("fish", "fish"), ("sesame", "sesame"), ("nuts", "nuts"),
                )
                requested = next((value for label, value in allergen_aliases
                                  if re.search(rf"\b{re.escape(label)}\b", normalized)), None)
                if requested:
                    result = self._run_tool("check_item_allergen", {
                        "item_name": item["name"], "allergen": requested,
                    })
                    return _tool_reply("check_item_allergen", {}, result)
                return (f"{item['name']} lists these allergens: {item['allergens'] or 'none listed'}. "
                        "An unlisted allergen is not a safety guarantee; please check with restaurant staff.")

        menu_question = re.search(
            r"\b(?:what|which|show|list|menu|do you have|what do you|what is available|"
            r"any .+ options|tell me about|can i see|could i see|meals?|options?)\b", normalized
        )
        if not menu_question:
            return None
        diet = detect_menu_diet_filter(normalized)
        if diet:
            result = self._run_tool("get_menu_by_dietary_filter", {"diet": diet})
            if re.search(r"\b(?:meal|meals|combo|combos)\b", normalized):
                result["items"] = [item for item in result["items"] if item["is_combo"]]
                if not result["items"] and result.get("allergen"):
                    return (f"No available meal combos match the {result['allergen']}-free filter based on "
                            "recorded allergen data. "
                            "Please check ingredients and cross-contact with restaurant staff.")
            return _tool_reply("get_menu_by_dietary_filter", {}, result)

        category_aliases = (
            ("pastry", "Pastries"), ("pastries", "Pastries"), ("croissant", "Pastries"),
            ("muffin", "Pastries"), ("cookie", "Pastries"), ("cake", "Pastries"),
            ("cheesecake", "Pastries"), ("cinnamon", "Pastries"),
            ("coffee", "Coffee"), ("espresso", "Coffee"), ("americano", "Coffee"),
            ("latte", "Coffee"), ("cappuccino", "Coffee"), ("macchiato", "Coffee"),
            ("frappe", "Frappes"), ("milkshake", "Milkshakes"),
            ("tea", "Tea & Refreshers"), ("lemonade", "Tea & Refreshers"), ("refresher", "Tea & Refreshers"),
        )
        category = next((value for alias, value in category_aliases if alias in normalized), "all")
        result = self._run_tool("get_menu_items", {"category": category})
        return _tool_reply("get_menu_items", {}, result)

    def _cart_quantity_request(self, text):
        normalized = _normalize_order_text(text)
        if not (ADD_ORDER_ACTION_RE.match(normalized) or REMOVE_ORDER_ACTION_RE.match(normalized)):
            return None
        menu_result = self._run_tool("get_menu_items", {"category": "all"})
        if not menu_result.get("ok"):
            return self.say(menu_result.get("error", "Could not load the menu."))
        request = _parse_cart_quantity_request(text, menu_result.get("items", []))
        if not request:
            return None

        return self._apply_cart_quantity_request(request, text)

    def _apply_cart_quantity_request(self, request, text):
        self.history.append({"role": "user", "content": text})
        self.history = self.history[-30:]

        def reply(message):
            self.history.append({"role": "assistant", "content": message})
            self.history = self.history[-30:]
            return self.say(message)

        if self.state == REVIEW:
            self._go(ORDERING, "modifying order during review")

        item_name = request["item_name"]
        quantity = request["quantity"]
        if quantity == "unspecified" or (request["action"] == "add" and quantity is None):
            self.pending_cart_quantity = {
                "action": request["action"],
                "item_name": item_name,
            }
            self._persist()
            action = "add" if request["action"] == "add" else "remove"
            return reply(f"How many {item_name} would you like to {action}?")

        if request["action"] == "add":
            result = self._run_tool("add_item_to_order_tool", {
                "item_name": item_name,
                "qty": quantity,
            })
            if not result.get("ok"):
                return reply(_tool_reply("add_item_to_order_tool", {}, result))
            matching = [
                item for item in result["order"]["items"]
                if item["name"].casefold() == item_name.casefold()
            ]
            total = sum(item["quantity"] for item in matching)
            return reply(
                f"Added {quantity} {item_name} to your order. You now have {total}."
            )

        before = db.view_current_order(self.session_id)
        result = self._run_tool("remove_item_from_order", {
            "item_name": item_name,
            "qty": quantity,
        })
        if not result.get("ok"):
            if result.get("clarification_required"):
                versions = ", ".join(
                    f"{choice['quantity']} with {choice['instructions']}"
                    for choice in result.get("choices", [])
                )
                return reply(
                    f"Which {item_name} should I remove? Your order has {versions}."
                )
            return reply(result.get("error", "Could not remove that item."))

        before_total = sum(
            item["quantity"] for item in before["items"]
            if item["name"].casefold() == item_name.casefold()
        )
        after_total = sum(
            item["quantity"] for item in result["order"]["items"]
            if item["name"].casefold() == item_name.casefold()
        )
        removed = before_total - after_total
        if after_total:
            return reply(
                f"Removed {removed} {item_name}. You now have {after_total}."
            )
        return reply(f"Removed {item_name} from your order.")

    def _respond_to_user(self, text):
        reply = self._llm_turn(text)
        self.say(reply)
        for followup in self.last_followups:
            self.say(followup)
        return reply

    def handle_user(self, text):
        self.transcript.append({"role": "user", "text": text})
        self._log("user_message", text=text)

        if self.state == GREETING:
            if not self.session_id or not db.session_exists(self.session_id):
                self.session_id = db.create_session(None)
            self.table_no = None
            self._go(ORDERING, "ready to take order without table selection")

        if re.fullmatch(r"\s*(?:table|t|seat)\s*\d+\s*[.!?]*\s*", text, re.I):
            return self.say("No table number is needed. What would you like to order?")

        # FSM State 4: CONFIRMED (State locked - modifications/cancellations blocked)
        if self.state == CONFIRMED:
            if CANCEL_ORDER_RE.match(text) or "cancel" in text.lower():
                return self.say("Cannot cancel order: order is already confirmed and sent to the kitchen.")
            return self.say("Your order is already confirmed and locked. Please start a new order to continue.")

        # Out-of-Domain Guardrail (Reject weather, general knowledge, etc.)
        if OFF_TOPIC_RE.search(text):
            if self.pending_cart_quantity:
                self.pending_cart_quantity = None
                self._persist()
            return self.say("I am the AI Virtual Waiter for Perpetual Bistro and can only assist with your food order and our menu. What would you like to order?")

        # Cancellation Handling
        if self.pending_confirmation == "cancel_order":
            if CONFIRM_RE.match(text):
                result = db.cancel_order(self.session_id)
                self._log("cancel_order", result=result)
                if result["ok"]:
                    self.session_id, self.table_no, self.history = db.create_session(None), None, []
                    self._go(ORDERING, "cancelled order; ready for a new order")
                    self.pending_confirmation = None
                    return self.say("Your order has been cancelled and the reserved stock released. What would you like to order?")
                self.pending_confirmation = None
                return self.say(f"I couldn't cancel the order: {result['error']}")
            if DECLINE_RE.match(text):
                self.pending_confirmation = None
                self._persist()
                return self.say("Okay, I kept your order. What would you like to do next?")
            # Non-yes/no interrupt: Keep order safe!
            catalog_reply = self._catalog_query(text)
            if catalog_reply:
                self.pending_confirmation = None
                self._persist()
                return self.say("I kept your order while answering that. " + catalog_reply)
            self.pending_confirmation = None
            self._persist()
            self.say("I kept your order while answering that.")
            return self._respond_to_user(text)

        if self.pending_combo_upgrade:
            if DECLINE_RE.match(text):
                self.pending_combo_upgrade = None
                self.pending_combo_offer = None
                self._persist()
                return self.say("No problem. Your order is unchanged.")
            return self._handle_combo_choice(text)

        if self.pending_combo_offer:
            if DECLINE_RE.match(text):
                self.pending_combo_offer = None
                self._persist()
                return self.say("No problem. I kept the original item on your order.")
            if UPGRADE_ACCEPT_RE.match(text):
                offer = self.pending_combo_offer
                self.pending_combo_upgrade = {
                    "line_id": offer["line_id"],
                    "combo_name": offer["combo_name"],
                    "combo_id": offer["combo_id"],
                    "side_name": None,
                    "drink_name": None,
                }
                self.pending_combo_offer = None
                self._persist()
                return self._handle_combo_choice(text)

        if self.pending_cart_quantity:
            quantity = _parse_quantity_followup(text)
            if quantity is not None:
                if quantity < 1:
                    return self.say("Please provide a quantity of at least one.")
                request = {**self.pending_cart_quantity, "quantity": quantity}
                self.pending_cart_quantity = None
                self._persist()
                return self._apply_cart_quantity_request(request, text)
            self.pending_cart_quantity = None
            self._persist()

        if CANCEL_ORDER_RE.match(text) and self.state in (ORDERING, REVIEW):
            self.pending_confirmation = "cancel_order"
            self._persist()
            return self.say("Do you want to cancel your entire unconfirmed order? Reply yes to cancel or no to keep it.")

        # FSM State 3: REVIEW -> CONFIRMED Transition
        if self.state == REVIEW and CONFIRM_RE.match(text):
            self.confirm()
            return self.transcript[-1]["text"]

        # If user requests changes while in REVIEW, transition back to ORDERING
        if self.state == REVIEW and (
            re.search(r"\b(add|extra|remove|cancel|change|make it|no |less)\b", text, re.I)
        ):
            self._go(ORDERING, "modifying order during review")

        # FSM State 2: ORDERING -> REVIEW Transition
        if self.state == ORDERING and REVIEW_RE.search(text) and not re.search(r"\b(add|remove|no|extra)\b", text, re.I):
            self.go_review()
            return self.transcript[-1]["text"]

        cart_reply = self._cart_quantity_request(text)
        if cart_reply is not None:
            return cart_reply

        # Catalog Query Fast Path
        catalog_reply = self._catalog_query(text)
        if catalog_reply:
            return self.say(catalog_reply)

        return self._respond_to_user(text)

    def _handle_combo_choice(self, text):
        pending = self.pending_combo_upgrade
        options = db.get_combo_options(pending["combo_id"])
        if not options.get("ok"):
            self.pending_combo_upgrade = None
            self._persist()
            return self.say(f"I couldn't load the meal choices: {options.get('error', 'Unknown error')}")

        normalized = (text or "").casefold()
        chosen = {}
        choice_aliases = {
            "French Fries": ("fries",),
            "Garden Salad": ("salad",),
            "Iced Tea": ("tea",),
            "Bottled Water": ("water",),
            "Mango Smoothie": ("smoothie",),
        }
        for category, field in (("sides", "side_name"), ("drinks", "drink_name")):
            available = [item for item in options[category] if item["available_qty"] > 0]
            matches = [
                item for item in available
                if item["name"].casefold() in normalized
                or any(re.search(rf"\b{re.escape(alias)}\b", normalized)
                       for alias in choice_aliases.get(item["name"], ()))
            ]
            if len(matches) == 1:
                chosen[field] = matches[0]["name"]
            elif len(matches) > 1:
                names = ", ".join(item["name"] for item in matches)
                return self.say(f"Which {category[:-1]} did you mean: {names}?")
        for field, value in chosen.items():
            pending[field] = value

        missing = []
        for category, field, label in (("sides", "side_name", "side"), ("drinks", "drink_name", "drink")):
            if pending[field]:
                continue
            available = [item for item in options[category] if item["available_qty"] > 0]
            if not available:
                return self.say(f"There are no {category} currently available for that meal. Your tab is unchanged.")
            names = ", ".join(
                f"{item['name']} ({'+' if item['price_adjustment'] > 0 else ''}"
                f"PHP {item['price_adjustment']:.2f})"
                if item["price_adjustment"] else item["name"]
                for item in available
            )
            missing.append(f"{label}: {names}")
        if missing:
            self._persist()
            if len(missing) == 2:
                return self.say(
                    f"Sure. Which side and drink would you like for the {pending['combo_name']}? "
                    f"Available {missing[0]}; {missing[1]}."
                )
            return self.say(f"Which {missing[0]} would you like?")

        result = self._run_tool("upgrade_to_combo", {
            "line_id": pending["line_id"], "combo_name": pending["combo_name"],
            "side_name": pending["side_name"], "drink_name": pending["drink_name"],
        })
        if not result["ok"]:
            return self.say(f"I couldn't complete the upgrade: {result['error']} Your tab is unchanged.")
        self.pending_combo_upgrade = None
        self.pending_combo_offer = None
        self._persist()
        return self.say(
            f"{result['message']} Side: {pending['side_name']}; drink: {pending['drink_name']}. "
            "Your tab has been updated."
        )

    def _system_prompt(self):
        return (
            "You are the AI Virtual Waiter at Perpetual Bistro. "
            f"Current FSM State: {self.state}.\n"
            "Be a polite, attentive café ordering assistant. Keep replies concise (1-3 sentences).\n"
            "Strict Guardrails:\n"
            "1. Ground all menu, stock, allergen, and price answers in tool results. Never hallucinate.\n"
            "2. If an item is out of stock (or requested quantity exceeds stock), use find_available_alternatives and offer in-stock items.\n"
            "3. If customer asks off-topic questions (e.g. weather, politics, homework), politely decline and redirect them to ordering.\n"
            "4. Put special customizations (e.g. 'no onions', 'extra crispy') in the instructions argument.\n"
            "5. When customer wants to finish, prompt them to review their order.\n"
            f"Active Tab Status: {json.dumps(db.view_current_order(self.session_id))}"
        )

    def _llm_turn(self, text):
        self.history.append({"role": "user", "content": text})
        self.history = self.history[-30:]
        self.last_followups = []

        try:
            if not self.model:
                self.connect()

            for _ in range(6):
                resp = OLLAMA_CLIENT.chat(
                    model=self.model,
                    tools=TOOLS,
                    think=False,
                    messages=[{"role": "system", "content": self._system_prompt()}] + self.history
                )
                msg = resp.message
                tool_calls = msg.tool_calls or []

                if not tool_calls:
                    reply_text = msg.content or "How else may I help with your order?"
                    self.history.append({"role": "assistant", "content": reply_text})
                    return reply_text

                # Execute tool calls emitted by Qwen 2.5
                msg_dict = {"role": getattr(msg, "role", "assistant"), "content": getattr(msg, "content", "")}
                if getattr(msg, "tool_calls", None):
                    msg_dict["tool_calls"] = [
                        {"function": {"name": getattr(c.function, "name", ""), "arguments": getattr(c.function, "arguments", {})}}
                        for c in msg.tool_calls
                    ]
                self.history.append(msg_dict)
                for call in tool_calls:
                    fn_name = call.function.name
                    args = call.function.arguments or {}
                    result = self._run_tool(fn_name, args)
                    self.history.append({
                        "role": "tool",
                        "content": json.dumps(result),
                    })

            # Fallback if loop finishes
            return "I have updated your tab. Let me know if you would like anything else!"

        except Exception as e:
            self._log("llm_error", error=str(e))
            return (
                "I couldn't connect to the local waiter model. Please check that Ollama "
                "is running and try again."
            )
