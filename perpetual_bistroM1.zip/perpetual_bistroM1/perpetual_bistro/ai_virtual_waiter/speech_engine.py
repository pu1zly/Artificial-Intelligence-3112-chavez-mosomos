"""Decoupled Speech I/O Pipeline for Perpetual Bistro AI Virtual Waiter.
Provides:
    - Speech-to-Text (STT): Microphone audio capture and transcription via SpeechRecognition.
    - Text-to-Speech (TTS): Audio vocalization via pyttsx3 with tuned rate and pitch/volume.
    - Milestone 1 Verification CLI script.
"""
import argparse
import os
import sys
import threading
import time

try:
    import speech_recognition as sr
except ImportError:
    sr = None

try:
    import pyttsx3
except ImportError:
    pyttsx3 = None


class SpeechEngine:
    def __init__(self, tts_rate: int = 185, tts_volume: float = 0.95, voice_index: int = None):
        """Initialize decoupled speech audio wrappers."""
        self.tts_rate = tts_rate
        self.tts_volume = tts_volume
        self.voice_index = voice_index
        self._lock = threading.Lock()
        self.recognizer = None
        self.tts_available = False
        self.stt_available = False
        self._active_engine = None
        self._ambient_calibrated = False

        self._init_tts()
        self._init_stt()

    def _init_tts(self):
        if pyttsx3 is None:
            print("[SpeechEngine] Notice: pyttsx3 module not installed. Running in silent TTS mode.")
            return
        try:
            engine = pyttsx3.init()
            engine.setProperty("rate", self.tts_rate)
            engine.setProperty("volume", self.tts_volume)
            if self.voice_index is not None:
                voices = engine.getProperty("voices")
                if 0 <= self.voice_index < len(voices):
                    engine.setProperty("voice", voices[self.voice_index].id)
            engine.stop()
            self.tts_available = True
        except Exception as e:
            print(f"[SpeechEngine] Warning: Could not initialize TTS engine: {e}")
            self.tts_available = False

    def _init_stt(self):
        if sr is None:
            print("[SpeechEngine] Notice: speech_recognition module not installed. Running text fallback for STT.")
            return
        try:
            self.recognizer = sr.Recognizer()
            self.recognizer.energy_threshold = 300
            self.recognizer.dynamic_energy_threshold = True
            self.recognizer.pause_threshold = 0.45
            self.recognizer.non_speaking_duration = 0.35
            self.stt_available = True
        except Exception as e:
            print(f"[SpeechEngine] Warning: Could not initialize STT recognizer: {e}")
            self.stt_available = False

    def stop(self):
        """Immediately skip and abort any active text-to-speech audio."""
        with self._lock:
            if self._active_engine:
                try:
                    self._active_engine.stop()
                except Exception:
                    pass
                self._active_engine = None

    def speak(self, text: str, block: bool = True) -> bool:
        """Convert agent response text string to audio speech via pyttsx3 with skip support."""
        if not text or not text.strip():
            return False

        # Instant skip: cancel prior speech before speaking new response
        self.stop()

        clean_text = text.replace("*", "").replace("#", "").replace("_", "").replace("`", "").strip()

        def _do_speak():
            with self._lock:
                try:
                    engine = pyttsx3.init()
                    self._active_engine = engine
                    engine.setProperty("rate", self.tts_rate)
                    engine.setProperty("volume", self.tts_volume)
                    if self.voice_index is not None:
                        voices = engine.getProperty("voices")
                        if 0 <= self.voice_index < len(voices):
                            engine.setProperty("voice", voices[self.voice_index].id)
                    engine.say(clean_text)
                    engine.runAndWait()
                except Exception as e:
                    print(f"[SpeechEngine TTS Error] {e}")
                finally:
                    self._active_engine = None

        if not self.tts_available:
            return False

        if block:
            _do_speak()
        else:
            t = threading.Thread(target=_do_speak, daemon=True)
            t.start()
        return True

    def listen(self, timeout: int = 5, phrase_time_limit: int = 8) -> str:
        """Capture microphone audio via SpeechRecognition with low-latency calibration."""
        if not self.stt_available or self.recognizer is None:
            print("[SpeechEngine] Microphone STT unavailable. Please enter text via keyboard:")
            return input("> ").strip()

        # Stop any active voice when listening starts
        self.stop()

        try:
            with sr.Microphone() as source:
                print("\n[SpeechEngine] Listening... Speak into your microphone now:")
                if not self._ambient_calibrated:
                    self.recognizer.adjust_for_ambient_noise(source, duration=0.2)
                    self._ambient_calibrated = True
                audio = self.recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)
                print("[SpeechEngine] Processing speech...")

            # Transcribe via Google Speech Recognition
            text = self.recognizer.recognize_google(audio)
            print(f"[SpeechEngine Recognized] \"{text}\"")
            return text.strip()
        except sr.WaitTimeoutError:
            print("[SpeechEngine] Listening timed out (no speech detected).")
            return ""
        except sr.UnknownValueError:
            print("[SpeechEngine] Could not understand audio.")
            return ""
        except sr.RequestError as e:
            print(f"[SpeechEngine Network Warning] Recognition service error: {e}. Falling back to keyboard:")
            return input("> ").strip()
        except Exception as e:
            print(f"[SpeechEngine Audio Error] Microphone input issue ({e}). Falling back to keyboard:")
            return input("> ").strip()


def run_milestone1_verification():
    """Verify that spoken/typed input triggers an FSM state transition and updates SQLite without GUI."""
    print("=" * 70)
    print("PERPETUAL BISTRO - MILESTONE 1 VERIFICATION & CHECKPOINT")
    print("Core Modules: restaurant.db, db_tools.py, fsm_controller.py, speech_engine.py")
    print("=" * 70)

    try:
        import db_tools as db
        from fsm_controller import WaiterAgent, GREETING, ORDERING, REVIEW, CONFIRMED
    except ImportError:
        # Fallback for relative package path
        from ai_virtual_waiter import db_tools as db
        from ai_virtual_waiter.fsm_controller import WaiterAgent, GREETING, ORDERING, REVIEW, CONFIRMED

    print("\n[Step 1] Initializing fresh SQLite database...")
    db.init_db(reset=True)
    with db.conn() as c:
        menu_count = c.execute("SELECT COUNT(*) FROM menu_items").fetchone()[0]
    print(f" SQLite Database online. Menu items loaded: {menu_count}")

    print("\n[Step 2] Initializing Speech Engine (STT & TTS)...")
    speech = SpeechEngine(tts_rate=175, tts_volume=0.9)
    print(f" TTS Ready: {speech.tts_available} | STT Ready: {speech.stt_available}")

    print("\n[Step 3] Initializing FSM Controller...")
    agent = WaiterAgent()
    agent.reset()
    print(f" Initial State: {agent.state} (Expected: {GREETING})")
    assert agent.state == GREETING, "FSM failed initial GREETING state test"

    print("\n[Step 4] Simulating Spoken Input for Table Capture: 'Hello, Table 4 please'...")
    prompt = "Hello, Table 4 please"
    print(f" Customer Input: \"{prompt}\"")
    reply = agent.handle_user(prompt)
    print(f" Waiter Reply: {reply}")
    print(f" Current FSM State: {agent.state} (Expected: {ORDERING})")
    assert agent.state == ORDERING, f"Expected state {ORDERING}, got {agent.state}"
    assert agent.table_no == 4, f"Expected table 4, got {agent.table_no}"
    print(f" Captured Table Number: {agent.table_no}")

    # Check SQLite Session
    with db.conn() as c:
        session = c.execute("SELECT * FROM table_sessions WHERE session_id=?", (agent.session_id,)).fetchone()
    print(f" SQLite table_sessions record: session_id={session['session_id']}, table_no={session['table_no']}, status={session['status']}")
    assert session is not None and session["status"] == "open"

    print("\n[Step 5] Triggering Spoken Output via Text-to-Speech...")
    speech.speak("Welcome to Table 4! I am your AI Virtual Waiter. How can I serve you today?", block=True)

    print("\n[Step 6] Adding Item to Order via Tool Binding: 'Cheeseburger'...")
    add_result = agent._run_tool("add_item_to_order_tool", {
        "item_name": "Cheeseburger",
        "qty": 2,
        "instructions": "no onions, extra crispy"
    })
    print(f" Tool Execution Result: {add_result}")
    assert add_result.get("ok") is True

    # Check SQLite Order Line Items
    with db.conn() as c:
        cart = c.execute("SELECT * FROM cart_items WHERE session_id=?", (agent.session_id,)).fetchall()
    print(f" SQLite cart_items count: {len(cart)} row(s)")
    assert len(cart) == 1
    print(f" Line Item: item_id={cart[0]['item_id']}, quantity={cart[0]['quantity']}, instructions=\"{cart[0]['special_instructions']}\"")

    print("\n[Step 7] Testing Out-of-Stock Guardrail: 'Crispy Slice Salmon' (stock is 0)...")
    oos_result = agent._run_tool("add_item_to_order_tool", {
        "item_name": "Crispy Slice Salmon",
        "qty": 1
    })
    print(f" Out-of-stock guard outcome: ok={oos_result.get('ok')}, error=\"{oos_result.get('error')}\"")
    assert oos_result.get("ok") is False, "Guardrail failed to block out-of-stock item!"
    print(" Out-of-stock guardrail successfully blocked order.")

    print("\n" + "=" * 70)
    print("MILESTONE 1 VERIFICATION PASSED SUCCESSFULLY!")
    print("All core deliverables verified: Speech I/O, FSM Controller, SQLite CRUD Engine.")
    print("=" * 70)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Speech Engine & Milestone 1 Verification.")
    parser.add_argument("--verify", action="store_true", default=True, help="Run Milestone 1 verification checklist")
    parser.add_argument("--listen", action="store_true", help="Interactive microphone test")
    args = parser.parse_args()

    if args.listen:
        se = SpeechEngine()
        spoken = se.listen()
        print(f"Captured: {spoken}")
        se.speak(f"You said: {spoken}")
    else:
        run_milestone1_verification()
