"""Decoupled Speech I/O Pipeline for Perpetual Bistro AI Virtual Waiter.
Provides:
    - Speech-to-Text (STT): Microphone audio capture and transcription via SpeechRecognition.
    - Text-to-Speech (TTS): Audio vocalization via pyttsx3 with tuned rate and pitch/volume.
    - Milestone 1 Verification CLI script.
"""
import argparse
import importlib.metadata
import importlib.util
import os
import sys
import tempfile
import threading
import time

try:
    import speech_recognition as sr
except ImportError:
    sr = None

try:
    import pyttsx3
except ImportError:
    pyttsx3 = None


class SpeechRecognitionUnavailable(RuntimeError):
    """Raised when the local Whisper transcription engine cannot be loaded."""


class SpeechEngine:
    DEFAULT_WHISPER_MODEL = "medium.en"
    WHISPER_SAMPLE_RATE = 16000

    def __init__(self, tts_rate: int = 185, tts_volume: float = 0.95, voice_index: int = None):
        """Initialize decoupled speech audio wrappers."""
        self.tts_rate = tts_rate
        self.tts_volume = tts_volume
        self.voice_index = voice_index
        self._lock = threading.Lock()
        self.recognizer = None
        self.tts_available = False
        self.stt_available = False
        self._active_engine = None
        self._whisper_model = None
        self._whisper_lock = threading.Lock()

        self._init_tts()
        self._init_stt()

    def _init_tts(self):
        if pyttsx3 is None:
            print("[SpeechEngine] Notice: pyttsx3 module not installed. Running in silent TTS mode.")
            return
        try:
            engine = pyttsx3.init()
            engine.setProperty("rate", self.tts_rate)
            engine.setProperty("volume", self.tts_volume)
            if self.voice_index is not None:
                voices = engine.getProperty("voices")
                if 0 <= self.voice_index < len(voices):
                    engine.setProperty("voice", voices[self.voice_index].id)
            engine.stop()
            self.tts_available = True
        except Exception as e:
            print(f"[SpeechEngine] Warning: Could not initialize TTS engine: {e}")
            self.tts_available = False

    def _init_stt(self):
        if sr is None:
            print("[SpeechEngine] Notice: microphone capture is unavailable. Terminal input remains available.")
            return
        try:
            self.recognizer = sr.Recognizer()
            self.recognizer.energy_threshold = 300
            self.recognizer.dynamic_energy_threshold = True
            self.recognizer.pause_threshold = 0.8
            self.recognizer.non_speaking_duration = 0.5
            self.stt_available = True
        except Exception as e:
            print(f"[SpeechEngine] Warning: Could not initialize STT recognizer: {e}")
            self.stt_available = False

    def stop(self):
        """Immediately skip and abort any active text-to-speech audio."""
        with self._lock:
            if self._active_engine:
                try:
                    self._active_engine.stop()
                except Exception:
                    pass
                self._active_engine = None

    def speak(self, text: str, block: bool = True) -> bool:
        """Convert agent response text string to audio speech via pyttsx3 with skip support."""
        if not text or not text.strip():
            return False

        # Instant skip: cancel prior speech before speaking new response
        self.stop()

        clean_text = text.replace("*", "").replace("#", "").replace("_", "").replace("`", "").strip()

        def _do_speak():
            with self._lock:
                try:
                    engine = pyttsx3.init()
                    self._active_engine = engine
                    engine.setProperty("rate", self.tts_rate)
                    engine.setProperty("volume", self.tts_volume)
                    if self.voice_index is not None:
                        voices = engine.getProperty("voices")
                        if 0 <= self.voice_index < len(voices):
                            engine.setProperty("voice", voices[self.voice_index].id)
                    engine.say(clean_text)
                    engine.runAndWait()
                except Exception as e:
                    print(f"[SpeechEngine TTS Error] {e}")
                finally:
                    self._active_engine = None

        if not self.tts_available:
            return False

        if block:
            _do_speak()
        else:
            t = threading.Thread(target=_do_speak, daemon=True)
            t.start()
        return True

    def listen(self, timeout: int = 5, phrase_time_limit: int = 8) -> str:
        """Capture microphone audio via SpeechRecognition with low-latency calibration."""
        if not self.stt_available or self.recognizer is None:
            print("[SpeechEngine] Microphone STT unavailable. Please enter text via keyboard:")
            return input("> ").strip()

        # Stop any active voice when listening starts
        self.stop()

        try:
            with sr.Microphone() as source:
                print("\n[SpeechEngine] Listening... Speak into your microphone now:")
                self.recognizer.adjust_for_ambient_noise(source, duration=0.6)
                audio = self.recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)
                print("[SpeechEngine] Transcribing locally with Whisper...")

            with tempfile.TemporaryDirectory() as temp_dir:
                audio_path = os.path.join(temp_dir, "recording.wav")
                with open(audio_path, "wb") as audio_file:
                    audio_file.write(audio.get_wav_data())
                text = self.transcribe_audio_file(audio_path)
            print(f"[SpeechEngine Recognized] \"{text}\"")
            return text.strip()
        except sr.WaitTimeoutError:
            print("[SpeechEngine] Listening timed out (no speech detected).")
            return ""
        except Exception as e:
            print(f"[SpeechEngine Audio Error] Microphone input issue ({e}). Falling back to keyboard:")
            return input("> ").strip()

    def transcribe_audio_file(self, audio_path: str) -> str:
        """Enhance and transcribe a recording locally with the Whisper English model."""
        try:
            from faster_whisper import WhisperModel
            from faster_whisper.audio import decode_audio
        except ImportError as error:
            raise SpeechRecognitionUnavailable(
                "Local speech recognition is unavailable. Install the project requirements "
                "including faster-whisper."
            ) from error

        with self._whisper_lock:
            if self._whisper_model is None:
                try:
                    model_name = os.environ.get("WHISPER_MODEL", "").strip() or self.DEFAULT_WHISPER_MODEL
                    self._whisper_model = WhisperModel(
                        model_name, device="cpu", compute_type="int8"
                    )
                except Exception as error:
                    raise SpeechRecognitionUnavailable(
                        "Could not load the local Whisper model. Check the model download "
                        "and available system memory."
                    ) from error

            audio = decode_audio(audio_path, sampling_rate=self.WHISPER_SAMPLE_RATE)
            audio = self._enhance_audio(audio)
            segments, _ = self._whisper_model.transcribe(
                audio,
                language="en",
                beam_size=5,
                vad_filter=True,
                vad_parameters={"min_silence_duration_ms": 400},
                condition_on_previous_text=False,
                initial_prompt=(
                    "Perpetual Bistro cafe menu: espresso, Americano, cappuccino, latte, "
                    "caramel macchiato, Spanish latte, mocha, matcha, frappe, milkshake, "
                    "tea, lemonade, croissant, muffin, cinnamon roll, cheesecake."
                ),
            )
            return " ".join(segment.text.strip() for segment in segments).strip()

    @staticmethod
    def _enhance_audio(audio):
        """Remove low-frequency rumble and gently normalize quiet speech without clipping."""
        import numpy as np

        samples = np.asarray(audio, dtype=np.float32).reshape(-1)
        if samples.size == 0:
            return samples

        samples = samples - np.mean(samples)
        alpha = float(np.exp(-2.0 * np.pi * 80 / SpeechEngine.WHISPER_SAMPLE_RATE))
        filtered = np.empty_like(samples)
        previous_input = 0.0
        previous_output = 0.0
        for index, sample in enumerate(samples):
            output = alpha * (previous_output + float(sample) - previous_input)
            filtered[index] = output
            previous_input = float(sample)
            previous_output = output

        rms = float(np.sqrt(np.mean(np.square(filtered), dtype=np.float64)))
        if rms < 1e-6:
            return filtered

        gain = min(0.08 / rms, 8.0)
        filtered *= gain
        peak = float(np.max(np.abs(filtered)))
        if peak > 0.95:
            filtered *= 0.95 / peak
        return filtered

    def whisper_status(self) -> dict:
        """Report local Whisper installation and runtime state without loading its model."""
        try:
            installed = importlib.util.find_spec("faster_whisper") is not None
        except (ImportError, ValueError):
            installed = False

        if not installed:
            return {
                "available": False,
                "model": os.environ.get("WHISPER_MODEL", "").strip() or self.DEFAULT_WHISPER_MODEL,
                "loaded": False,
                "device": "CPU (int8)",
                "error": "faster-whisper is not installed. Install dependencies from requirements.txt.",
            }

        try:
            version = importlib.metadata.version("faster-whisper")
        except importlib.metadata.PackageNotFoundError:
            version = "unknown"

        return {
            "available": True,
            "model": os.environ.get("WHISPER_MODEL", "").strip() or self.DEFAULT_WHISPER_MODEL,
            "loaded": self._whisper_model is not None,
            "version": version,
            "device": "CPU (int8)",
        }


def run_milestone1_verification():
    """Verify that spoken/typed input triggers an FSM state transition and updates SQLite without GUI."""
    try:
        import db_tools as db
        from fsm_controller import WaiterAgent, ORDERING
    except ImportError:
        # Fallback for relative package path
        from ai_virtual_waiter import db_tools as db
        from ai_virtual_waiter.fsm_controller import WaiterAgent, ORDERING

    original_db_path = db.DB_PATH
    with tempfile.TemporaryDirectory() as temp_dir:
        db.DB_PATH = os.path.join(temp_dir, "verification.db")
        try:
            _run_milestone1_verification_checks(db, WaiterAgent, ORDERING)
        finally:
            db.DB_PATH = original_db_path


def _run_milestone1_verification_checks(db, WaiterAgent, ORDERING):
    print("=" * 70)
    print("PERPETUAL BISTRO - MILESTONE 1 VERIFICATION & CHECKPOINT")
    print("Core Modules: temporary SQLite database, FSM, and speech engine")
    print("=" * 70)

    print("\n[Step 1] Initializing fresh SQLite database...")
    db.init_db()
    with db.conn() as c:
        menu_count = c.execute("SELECT COUNT(*) FROM menu_items").fetchone()[0]
    print(f" SQLite Database online. Menu items loaded: {menu_count}")

    print("\n[Step 2] Initializing Speech Engine (STT & TTS)...")
    speech = SpeechEngine(tts_rate=175, tts_volume=0.9)
    print(f" TTS Ready: {speech.tts_available} | STT Ready: {speech.stt_available}")

    print("\n[Step 3] Initializing FSM Controller...")
    agent = WaiterAgent()
    agent.reset()
    print(f" Initial State: {agent.state} (Expected: {ORDERING})")
    assert agent.state == ORDERING, "FSM did not start ready to take an order"

    print("\n[Step 4] Verifying table number is not required...")
    prompt = "Table 4"
    print(f" Customer Input: \"{prompt}\"")
    reply = agent.handle_user(prompt)
    print(f" Waiter Reply: {reply}")
    assert agent.state == ORDERING, f"Expected state {ORDERING}, got {agent.state}"
    assert agent.table_no is None, f"Unexpected table number: {agent.table_no}"

    # Check SQLite Session
    with db.conn() as c:
        session = c.execute("SELECT * FROM table_sessions WHERE session_id=?", (agent.session_id,)).fetchone()
    print(f" SQLite order session: session_id={session['session_id']}, status={session['status']}")
    assert session is not None and session["status"] == "open" and session["table_no"] is None

    print("\n[Step 5] Triggering Spoken Output via Text-to-Speech...")
    speech.speak("Welcome to Perpetual Bistro! What can I get started for you today?", block=True)

    print("\n[Step 6] Adding Item to Order via Tool Binding: 'Café Latte'...")
    add_result = agent._run_tool("add_item_to_order_tool", {
        "item_name": "Café Latte",
        "qty": 2,
        "instructions": "extra hot"
    })
    print(f" Tool Execution Result: {add_result}")
    assert add_result.get("ok") is True

    # Check SQLite Order Line Items
    with db.conn() as c:
        cart = c.execute("SELECT * FROM cart_items WHERE session_id=?", (agent.session_id,)).fetchall()
    print(f" SQLite cart_items count: {len(cart)} row(s)")
    assert len(cart) == 1
    print(f" Line Item: item_id={cart[0]['item_id']}, quantity={cart[0]['quantity']}, instructions=\"{cart[0]['special_instructions']}\"")

    print("\n[Step 7] Testing insufficient-stock guardrail: 19 Blueberry Muffins...")
    oos_result = agent._run_tool("add_item_to_order_tool", {
        "item_name": "Blueberry Muffin",
        "qty": 19
    })
    print(f" Stock guard outcome: ok={oos_result.get('ok')}, error=\"{oos_result.get('error')}\"")
    assert oos_result.get("ok") is False, "Guardrail failed to block out-of-stock item!"
    assert "Only 18 x Blueberry Muffin available" in oos_result.get("error", "")
    print(" Inventory guardrail successfully blocked the excess quantity.")

    print("\n" + "=" * 70)
    print("MILESTONE 1 VERIFICATION PASSED SUCCESSFULLY!")
    print("All core deliverables verified: Speech I/O, FSM Controller, SQLite CRUD Engine.")
    print("=" * 70)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Speech Engine & Milestone 1 Verification.")
    parser.add_argument("--verify", action="store_true", default=True, help="Run Milestone 1 verification checklist")
    parser.add_argument("--listen", action="store_true", help="Interactive microphone test")
    args = parser.parse_args()

    if args.listen:
        se = SpeechEngine()
        spoken = se.listen()
        print(f"Captured: {spoken}")
        se.speak(f"You said: {spoken}")
    else:
        run_milestone1_verification()
