import os
import tempfile
import time
import tkinter as tk
from tkinter import ttk
import unittest

import db_tools as db
import fsm_agent
from virtual_waiter_prototype import WaiterApp


class GuiIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        db.DB_PATH = os.path.join(self.temp.name, "restaurant.db")
        fsm_agent.LOG_PATH = os.path.join(self.temp.name, "conversation.json")
        db.init_db()
        self.agent = fsm_agent.WaiterAgent()
        self.agent.reset()
        self.root = tk.Tk()
        self.root.withdraw()
        self.app = WaiterApp(self.root, self.agent)
        self.root.update()

    def tearDown(self):
        self._flush(timeout=3.0)
        self.app.wait_for_idle(timeout=2.0)
        self.app.cleanup()
        try:
            self.root.destroy()
        except Exception:
            pass
        time.sleep(0.05)
        try:
            self.temp.cleanup()
        except Exception:
            pass

    @staticmethod
    def _descendants(widget):
        children = list(widget.winfo_children())
        return children + [
            descendant
            for child in children
            for descendant in GuiIntegrationTests._descendants(child)
        ]

    def _flush(self, timeout=5.0):
        start = time.time()
        while time.time() - start < timeout:
            try:
                self.root.update()
            except Exception:
                break
            while not self.app.completed_actions.empty():
                self.app._poll_actions()
                try:
                    self.root.update()
                except Exception:
                    break
            if not self.app.busy and self.app.completed_actions.empty():
                break
            time.sleep(0.02)
        try:
            self.root.update()
        except Exception:
            pass

    def test_menu_window_opens_ready_for_order(self):
        # Open menu window
        menu_win = self.app._show_menu()
        self.root.update()
        self.assertIsNotNone(menu_win)
        self.assertTrue(menu_win.winfo_exists())
        self.assertIn("Click 'Add' to place items", self.app.menu_notice.cget("text"))

    def test_adding_item_from_menu_gui_updates_tab_and_chat(self):
        self.agent.handle_user("Table 5")
        self.app.render()
        menu_win = self.app._show_menu()
        self.root.update()

        # Add Espresso via Menu GUI
        self.app._add_menu_item("Espresso")
        self._flush()

        # Verify menu window stays open
        self.assertTrue(menu_win.winfo_exists())

        # Verify cart in Main GUI updated
        snapshot = self.agent.snapshot()
        items = snapshot["order"]["items"]
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["name"], "Espresso")

        # Verify chat transcript contains waiter acknowledgment with allergens
        latest_transcript = self.agent.transcript[-1]["text"]
        self.assertIn("Added 1 x Espresso", latest_transcript)
        self.assertIn("Allergen information: none listed", latest_transcript)

    def test_menu_gui_shows_categories_from_the_active_cafe_catalog(self):
        self.agent.handle_user("Table 5")
        self.app.render()
        menu_win = self.app._show_menu()
        self.root.update()

        self.assertTrue(menu_win.winfo_exists())
        self.assertIn("24 a la carte item(s)", self.app.menu_status_label.cget("text"))
        notebooks = [
            widget
            for widget in self._descendants(menu_win)
            if isinstance(widget, ttk.Notebook)
        ]
        self.assertEqual(len(notebooks), 1)
        self.assertEqual(
            [notebooks[0].tab(tab, "text") for tab in notebooks[0].tabs()],
            ["Menu"],
        )
        labels = {
            widget.cget("text")
            for widget in self._descendants(menu_win)
            if isinstance(widget, ttk.Label)
        }
        self.assertIn("Coffee", labels)
        self.assertIn("Frappes", labels)
        self.assertIn("Pastries", labels)
        self.assertNotIn("Mains", labels)
        self.assertNotIn("Pasta", labels)

    def test_menu_gui_updates_stock_dynamically(self):
        self.agent.handle_user("Table 5")
        self.app.render()
        self.app._show_menu()
        self.root.update()

        # Blueberry Muffin starts with 18 portions available
        self.app._add_menu_item("Blueberry Muffin")
        self._flush()

        pastries = [i for i in db.get_menu_by_category("Pastries")["items"] if i["name"] == "Blueberry Muffin"]
        self.assertEqual(pastries[0]["available_qty"], 17)

        # Add second portion
        self.app._add_menu_item("Blueberry Muffin")
        self._flush()

        pastries = [i for i in db.get_menu_by_category("Pastries")["items"] if i["name"] == "Blueberry Muffin"]
        self.assertEqual(pastries[0]["available_qty"], 16)

    def test_adding_item_in_review_transitions_fsm_to_taking_order(self):
        self.agent.handle_user("Table 5")
        self.agent._run_tool("add_item_to_order", {"item_name": "Espresso", "qty": 1})
        self.agent.go_review()
        self.assertEqual(self.agent.state, fsm_agent.REVIEW)
        self.app.render()

        self.app._add_menu_item("Blueberry Muffin")
        self._flush()

        self.assertEqual(self.agent.state, fsm_agent.TAKING_ORDER)

    def test_menu_filter_sync_from_chat_submission(self):
        self.agent.handle_user("Table 5")
        self.app.render()
        self.app._show_menu()
        self.root.update()

        # Submit dietary filter in composer
        self.app.message.insert(0, "Can I see the vegetarian options?")
        self.app._submit()
        self._flush()

        self.assertEqual(self.app.active_menu_filter, "Vegetarian")
        self.assertEqual(self.app.menu_filter.get(), "Vegetarian")

        # Submit full menu browse in composer
        self.app.message.insert(0, "Show me the full menu please")
        self.app._submit()
        self._flush()

        self.assertEqual(self.app.active_menu_filter, "All items")
        self.assertEqual(self.app.menu_filter.get(), "All items")

    def test_activity_window_single_instance(self):
        act1 = self.app._show_activity()
        self.root.update()
        act2 = self.app._show_activity()
        self.root.update()
        self.assertIs(act1, act2)


if __name__ == "__main__":
    unittest.main()
