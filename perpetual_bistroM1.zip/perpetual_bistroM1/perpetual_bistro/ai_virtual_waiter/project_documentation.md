# Perpetual Bistro - AI Virtual Waiter
## Final Project Technical Documentation & Architecture Specification
**Institution:** University of Perpetual Help System DALTA (UPHSD)  
**Course:** Artificial Intelligence - Lab (Lesson 7)  
**Instructor:** Prof. Rob Malitao  
**System Execution:** 100% Local (Zero Cloud Dependencies)  
**Core Tech Stack:** Python 3.10+, Local Ollama (Qwen 2.5), SQLite 3, STT/TTS Speech Modules, Flask (HTML/Tailwind CSS) & CustomTkinter  

---

## 1. Executive Summary & Business Scenario

Perpetual Bistro, the campus dining facility at UPHSD, requires a modern table-side digital waiter to streamline customer ordering, dietary checks, and kitchen inventory updates. To ensure high privacy, offline resiliency during campus network outages, and zero operational API costs, the system is designed to run entirely locally without cloud dependencies.

The AI Virtual Waiter serves as an interactive, voice-enabled, state-aware dining assistant. Customers interact naturally through typed or spoken language:
- Inquiring about menu items, prices, and dietary options (e.g., vegetarian, dairy-free, gluten-free).
- Requesting dish preparations and customizations ("2 cheeseburgers, no onions, extra crispy").
- Dynamic meal combo recommendations with component substitutions.
- Active order tab monitoring and human-in-the-loop manual adjustments (+, -, delete).
- Real-time inventory reservation and atomic stock subtraction in SQLite.
- Strict Finite State Machine (FSM) dialogue progression (`GREETING` &rarr; `ORDERING` &rarr; `REVIEW` &rarr; `CONFIRMED`).
- Generation of an itemized receipt upon checkout with locked post-confirmation immutability.

---

## 2. System Architecture & Conversation Flow

The system employs a multi-tiered architecture that strictly separates audio I/O, user interface, dialogue state control, LLM reasoning, and database transactions:

```mermaid
flowchart TD
    subgraph IO_Layer ["VOICE & TEXT INTERFACE (I/O Layer)"]
        MIC["Speech-to-Text (STT) Microphone<br/>(SpeechRecognition / Whisper)"]
        SPEAKER["Text-to-Speech (TTS) Speaker<br/>(pyttsx3: 175 wpm, Vol 0.9)"]
        UI_WEB["Web Tablet Ordering Interface<br/>(Flask + Tailwind CSS + REST API)"]
        UI_GUI["Desktop Kiosk GUI<br/>(CustomTkinter / Tkinter)"]
    end

    subgraph Core_Engine ["CORE VIRTUAL WAITER AGENT ENGINE"]
        FSM["FSM State Controller (fsm_controller.py)<br/>[GREETING &rarr; ORDERING &rarr; REVIEW &rarr; CONFIRMED]"]
        LLM["Local Ollama Engine (Qwen 2.5:7b)<br/>Autonomous Reasoning & Structured JSON Tool Calling"]
    end

    subgraph Data_Layer ["SQLITE PERSISTENCE LAYER (restaurant.db)"]
        DB_TOOLS["SQLite CRUD Wrapper & Guardrails (db_tools.py)"]
        T_MENU["menu_items<br/>(Stock & Allergens)"]
        T_SESS["table_sessions<br/>(Open / Confirmed / Cancelled)"]
        T_CART["order_line_items / cart_items<br/>(Active Reservations)"]
        T_COMBO["combo_components & choices"]
    end

    MIC -->|Spoken Audio| FSM
    UI_WEB <-->|HTTP / REST JSON| FSM
    UI_GUI <-->|Event Dispatch| FSM
    FSM -->|Response Text| SPEAKER
    FSM <-->|Structured Tool Calls| LLM
    FSM -->|Atomic Mutating Queries| DB_TOOLS
    DB_TOOLS <--> T_MENU
    DB_TOOLS <--> T_SESS
    DB_TOOLS <--> T_CART
    DB_TOOLS <--> T_COMBO
```

---

## 3. Finite State Machine (FSM) State Management & Guardrails

The ordering workflow enforces a deterministic Finite State Machine to eliminate state skipping, illegal shortcuts, and invalid cart mutations:

```mermaid
stateDiagram-v2
    [*] --> GREETING: Launch Application

    state GREETING {
        [*] --> AwaitTableNumber
        AwaitTableNumber --> AwaitTableNumber: General Menu / Allergen Queries
    }

    GREETING --> ORDERING: Table Number Captured (create_session)
    GREETING --> GREETING: Block Direct Checkout Jump ("Cannot jump from GREETING to CONFIRMED")

    state ORDERING {
        [*] --> TakingOrder
        TakingOrder --> TakingOrder: Add Item (add_item_to_order_tool)
        TakingOrder --> TakingOrder: Out-of-Stock Guard Triggered (Offers Alternatives)
        TakingOrder --> TakingOrder: Combo Upgrade Offer & Selection
        TakingOrder --> TakingOrder: Manual HITL Adjust (+ / - / Delete)
        TakingOrder --> TakingOrder: Off-Domain Query Blocked (Redirect to Menu)
    }

    ORDERING --> REVIEW: User signals completion ("That's all", "Review tab")
    
    state REVIEW {
        [*] --> PresentItemizedSummary
        PresentItemizedSummary --> ORDERING: Edit Request ("Add more fries", "Change quantity")
    }

    REVIEW --> CONFIRMED: Customer Confirms ("Yes, confirm it")
    
    state CONFIRMED {
        [*] --> LockCartModifications
        LockCartModifications --> GenerateItemizedReceipt
        LockCartModifications --> LockCartModifications: Reject Edits / Cancellations
    }

    ORDERING --> GREETING: Cancel Order (Confirmed)
    REVIEW --> GREETING: Cancel Order (Confirmed)
    CONFIRMED --> GREETING: "New Table / Reset" Triggered
```

### State Definitions & Enforced Transition Rules:
1. **`GREETING`**:
   - Captures table number and initializes a new open table session in SQLite.
   - Answers general menu or allergen queries while gently prompting for the customer's table number.
   - **Guardrail**: Direct transitions to `CONFIRMED` or `REVIEW` are strictly blocked.
2. **`ORDERING`**:
   - Parses customer natural language into structured tool calls (`add_item_to_order_tool`, `upgrade_to_combo`, `remove_item_from_order`).
   - Checks inventory constraints before committing additions.
   - Transitions to `REVIEW` when customer indicates completion ("I'm done", "That's all", "Show bill").
3. **`REVIEW`**:
   - Formats and presents the itemized cart, line totals, 10% service charge, and grand total PHP for verification.
   - **Guardrail**: Any cart modification during `REVIEW` automatically transitions back to `ORDERING`.
4. **`CONFIRMED`**:
   - Transactionally re-verifies stock, atomically deducts inventory from `menu_items`, and updates session status to `confirmed`.
   - Generates the official itemized receipt.
   - **Guardrail**: Cart modifications and cancellations are permanently locked.

---

## 4. Programmatic Inventory Guardrails & Edge Cases

The system implements strict programmatic safeguards in Python rather than relying solely on LLM prompt obedience:

### Edge Case 1: Out-of-Stock Items (e.g., Crispy Slice Salmon when Stock = 0)
- **Constraint**: `init_restaurant_db.sql` seeds `Crispy Slice Salmon` with `stock_qty = 0`.
- **Implementation**: Inside `db_tools.py:add_item_to_order_tool()`, available inventory is computed by subtracting open session reservations from `stock_qty`.
- **Behavior**: If `available == 0`, the transaction is blocked, and the system autonomously executes `find_available_alternatives()` to return available dishes in the same category (e.g., `Grilled Salmon`, `Cheeseburger`, `Chicken Inasal`).

### Edge Case 2: Insufficient Stock (e.g., Requesting 5 Pan-Seared Salmon when Stock = 2)
- **Constraint**: `Pan-Seared Salmon` has 2 units in stock.
- **Behavior**: Requesting 5 units returns an error `Only 2 x Pan-Seared Salmon available`, preventing inventory over-allocation, and suggests available alternatives.

### Edge Case 3: Post-Confirmation Immutability (CONFIRMED State)
- **Constraint**: Once an order reaches `CONFIRMED`, food preparation begins in the kitchen.
- **Implementation**: Both the FSM Controller (`fsm_controller.py`) and SQLite CRUD functions (`db_tools.py`) reject addition, quantity editing, line deletion, and order cancellation with:
  `"Cannot modify order: order is already confirmed and sent to the kitchen."`

### Edge Case 4: Out-of-Domain & Off-Topic Query Rejection
- **Constraint**: Virtual Waiter must not act as a general-purpose chatbot.
- **Implementation**: Off-topic topics (weather, politics, sports, general programming) are caught and rejected:
  `"I am the AI Virtual Waiter for Perpetual Bistro and can only assist with your food order and our menu. What would you like to order?"`

### Edge Case 5: Non-Yes/No Interruption During Cancellation
- **Constraint**: Asking a menu question during a pending order cancellation must not cancel the tab.
- **Implementation**: Unrelated queries abort the cancellation prompt, answer the catalog question, and preserve all active cart items safely.

---

## 5. Database Schema & Data Dictionary

The relational database is stored in SQLite (`restaurant.db`) with foreign key enforcement enabled (`PRAGMA foreign_keys = ON`).

### Table: `menu_items`
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | INTEGER | PRIMARY KEY | Unique menu item ID |
| `name` | TEXT | UNIQUE, NOT NULL | Item name (e.g., 'Cheeseburger') |
| `category` | TEXT | NOT NULL | 'Mains', 'Pasta', 'Sides', 'Drinks', 'Desserts', 'Combos' |
| `price` | REAL | NOT NULL | Price in Philippine Peso (PHP) |
| `stock_qty` | INTEGER | NOT NULL, DEFAULT 0 | Real-time kitchen inventory count |
| `allergens` | TEXT | NOT NULL, DEFAULT '' | Comma-separated allergen tags (dairy, egg, gluten, etc.) |
| `dietary_tags`| TEXT | NOT NULL, DEFAULT '' | Tags such as 'vegetarian', 'vegan' |

### Table: `table_sessions`
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `session_id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique table session ID |
| `table_no` | INTEGER | NOT NULL | Dining table number |
| `status` | TEXT | NOT NULL, DEFAULT 'open' | Status: `open`, `confirmed`, `cancelled` |

### Table: `order_line_items` (and View: `cart_items`)
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `line_id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique cart line item ID |
| `session_id` | INTEGER | NOT NULL, REFERENCES table_sessions | Foreign key to active session |
| `item_id` | INTEGER | NOT NULL, REFERENCES menu_items | Foreign key to menu item |
| `quantity` | INTEGER | NOT NULL, CHECK (quantity > 0) | Quantity ordered |
| `special_instructions`| TEXT | NOT NULL, DEFAULT '' | Customizations ("no onions, extra crispy") |

### Table: `combo_components`
Defines bundle components for discounted meals:
- Main dish (Burger / Chicken / Veggie Burger / Salmon)
- Side dish (Default: French Fries)
- Beverage (Default: Iced Tea)

---

## 6. Decoupled Speech I/O Pipeline (`speech_engine.py`)

The speech subsystem is fully abstracted and decoupled from the UI and state engine:

```
[Microphone Audio] ──> [speech_recognition.Recognizer] ──> [String Text]
                                                                  │
                                                                  ▼
                                                      [fsm_controller.WaiterAgent]
                                                                  │
                                                                  ▼
[Speaker Output]   <── [pyttsx3 Audio Vocalizer]   <── [Response String]
```

- **Speech-to-Text (STT)**:
  - Captures ambient microphone audio via `speech_recognition.Microphone()`.
  - Calibrates for ambient background noise dynamically (`adjust_for_ambient_noise`).
  - Converts audio into string text with polite fallbacks.
- **Text-to-Speech (TTS)**:
  - Vocalizes responses via `pyttsx3` with speed tuned to 175 wpm for natural pacing and volume set to 0.9.
  - Decoupled thread-safe playback ensures UI responsiveness.

---

## 7. User Interface (UI/UX) Dashboard

The system provides a real-time ordering screen adhering to the digital tablet concept:
1. **Live Chat & Voice Transcript**:
   - Real-time conversation bubbles distinguishing customer messages from Virtual Waiter replies.
   - Push-to-Talk microphone button with pulse animations for voice recording.
   - Quick-action suggestion chips for common orders and queries.
2. **Active Cart Table**:
   - Detailed breakdown displaying Item Name, Customizations/Combo Choices, Unit Price, and Line Total.
   - **Manual Human-in-the-Loop Override Buttons**: Direct `+` and `-` quantity adjustment buttons, and `Delete` button on each cart line.
3. **Financial Summary**:
   - Subtotal, Service Fee (10%), and Grand Total (PHP).
4. **Interactive Controls**:
   - "Review Order" & "Confirm & Pay" buttons.
   - Menu Explorer Modal with category navigation and allergen filters.
   - Modal itemized receipt upon checkout.

---

## 8. Driver-Navigator Tandem Pair Collaboration Log

| Milestone / Task | Driver Focus | Navigator Focus | Verification Test |
| :--- | :--- | :--- | :--- |
| **Milestone 1**: Database DDL & Seed Data | Wrote relational DDL in `init_restaurant_db.sql` | Audited foreign keys, check constraints, and `cart_items` view | `init_db.py --reset` executes cleanly without SQL errors |
| **Milestone 1**: CRUD & Inventory Guardrails | Implemented `db_tools.py` helper functions | Built atomic stock subtraction and out-of-stock guards | `add_item_to_order_tool()` blocks items when `stock_qty = 0` |
| **Milestone 1**: FSM Core Controller | Implemented `fsm_controller.py` state machine class | Verified transition logic and illegal jump guardrails | Cannot jump from `GREETING` directly to `CONFIRMED` |
| **Milestone 1**: Decoupled Speech Pipeline | Implemented `speech_engine.py` STT and TTS wrappers | Tuned voice rate (175 wpm) and ambient noise calibration | `speech_engine.py --verify` passes CLI verification |
| **Milestone 2**: Web Tablet Dashboard & API | Built Flask routes, HTML template, and Tailwind layout | Designed interactive cart table and HITL override buttons | Live UI updates automatically upon tool execution |
| **Milestone 2**: Post-Confirmation Immutability | Implemented transaction locks in `db_tools.py` and FSM | Engineered regression unit tests in `test_pdf_milestone_requirements.py` | 39 automated unit tests pass with 100% success |

---

## 9. Verification & Live Demonstration Script

### Pre-Defense Verification:
1. Ensure Ollama is running locally:
   ```bash
   ollama list
   ```
   *(Verify `qwen2.5:7b` is present)*.
2. Initialize fresh database catalog:
   ```bash
   python init_db.py --reset
   ```
3. Run automated regression checks:
   ```bash
   python -m unittest discover -s tests -v
   ```
   *(All 39 unit tests pass)*.

### Live Demonstration Sequence:
1. **Launch Application**:
   ```bash
   python app.py
   ```
   *Opens Web Tablet Interface at `http://127.0.0.1:5000`*.
2. **Scenario 1: Greeting & Table Capture**:
   - User: *"Hello, Table 4 please"*
   - System: Captures table 4, transitions `GREETING` &rarr; `ORDERING`.
3. **Scenario 2: Allergen Inquiry & Custom Order**:
   - User: *"Does the pesto penne contain nuts?"*
   - Waiter: Confirms nuts are listed from recorded database allergens.
   - User: *"Add 2 cheeseburgers, no onions, extra crispy"*
   - System: Cart updates with 2 Cheeseburgers, notes instructions, and suggests meal combo upgrade.
4. **Scenario 3: Edge-Case Test 1 (Out-of-Stock Item)**:
   - User: *"Can I order the Crispy Slice Salmon?"*
   - System: Blocks addition because stock is 0. Offers in-stock alternatives (`Grilled Salmon`, `Cheeseburger`).
5. **Scenario 4: Order Review & Confirmation**:
   - User: *"That's all, review my order"*
   - System: Transitions `ORDERING` &rarr; `REVIEW`, presents itemized subtotal and 10% fee.
   - User: *"Confirm order"*
   - System: Atomically deducts inventory, transitions `REVIEW` &rarr; `CONFIRMED`, displays official receipt modal.
6. **Scenario 5: Edge-Case Test 2 (Post-Confirmation Lock)**:
   - User: *"Please add one more iced tea"* or *"Cancel order"*
   - System: Rejects modification: `"Order is already confirmed and locked."`
