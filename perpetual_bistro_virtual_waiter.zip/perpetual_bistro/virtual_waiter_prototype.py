"""Perpetual Bistro virtual waiter. Run:  python virtual_waiter_prototype.py   ->  http://localhost:5000
Add --cli for a plain terminal chat instead of the web dashboard."""
import argparse, os, threading
from flask import Flask, jsonify, request, send_from_directory
import db_tools as db
from fsm_agent import MODEL, WaiterAgent

app = Flask(__name__, static_folder="static")
agent, lock = None, threading.Lock()


@app.get("/")
def index():
    return send_from_directory("static", "index.html")


@app.get("/api/state")
def state():
    return jsonify(agent.snapshot())


@app.post("/api/chat")
def chat():
    text = (request.json or {}).get("message", "").strip()
    with lock:
        if text:
            agent.handle_user(text)
    return jsonify(agent.snapshot())


@app.post("/api/adjust")
def adjust():
    d = request.json or {}
    with lock:
        agent.adjust(d.get("line_id"), d.get("delta", 0))
    return jsonify(agent.snapshot())


@app.post("/api/review")
def review():
    with lock:
        agent.go_review()
    return jsonify(agent.snapshot())


@app.post("/api/confirm")
def confirm():
    with lock:
        agent.confirm()
    return jsonify(agent.snapshot())


@app.post("/api/reset")
def reset():
    with lock:
        agent.reset()
    return jsonify(agent.snapshot())


def run_cli():
    print(agent.transcript[-1]["text"])
    while agent.state != "STATE_CONFIRMED":
        try:
            t = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if t:
            print("Waiter:", agent.handle_user(t), f"[{agent.state}]")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--port", type=int, default=5000)
    p.add_argument("--cli", action="store_true")
    p.add_argument("--reset-db", action="store_true", help="re-create restaurant.db (restores stock)")
    a = p.parse_args()
    db.init_db(reset=a.reset_db)
    agent = WaiterAgent()
    try:
        import ollama
        if not any(MODEL in m.model for m in ollama.list().models):
            print(f"[!] Model '{MODEL}' not found. Run: ollama pull {MODEL}")
    except Exception:
        print("[!] Cannot reach Ollama. Start it with: ollama serve")
    run_cli() if a.cli else app.run(host="127.0.0.1", port=a.port, debug=False, threaded=True)
