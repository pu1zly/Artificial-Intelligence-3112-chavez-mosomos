# Perpetual Bistro - Stateful Virtual Waiter (Lab 6.1, Option 1: Web Dashboard)

## Windows quick start
Install Python and Ollama once, then double-click `run_waiter.bat`. It sets up everything, starts Ollama, pulls qwen2.5 if needed and opens the browser. `run_waiter_RESET.bat` starts fresh.

## Setup (manual)
1. Install Ollama (https://ollama.com), then: `ollama pull qwen2.5` and keep `ollama serve` running.
2. `pip install -r requirements.txt`
3. `python virtual_waiter_prototype.py`  -> open http://localhost:5000
   - `--cli` terminal chat | `--port 8000` | `--reset-db` restore stock | env `OLLAMA_MODEL=qwen2.5:3b` for a smaller model

## Try it
"Table 4" -> "What pastas do you have?" -> "2 cheeseburgers, no onions" -> "Does the pesto penne have nuts?"
-> "Remove one cheeseburger" -> "Add grilled salmon x3" (only 2 in stock) -> "That's all" -> "Confirm".

## Memory
The order, conversation, table number and FSM state are saved in `restaurant.db` after every step. Refresh the page or
stop and re-run the program and the kiosk resumes where it left off (edit the order, then confirm). Use
`--reset-db` to wipe everything and start fresh (also restores stock).

## FSM
GREETING -> TAKING_ORDER <-> REVIEW -> CONFIRMED (editing in REVIEW returns to TAKING_ORDER).

## Files
`init_restaurant_db.sql`, `db_tools.py`, `fsm_agent.py`, `virtual_waiter_prototype.py`, `static/index.html`,
`pair_collaboration_log.md`, `sample_conversation_log.json` (auto-saved on confirm).
