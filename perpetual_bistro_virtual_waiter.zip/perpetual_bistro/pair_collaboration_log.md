# Pair Collaboration Log - Lab 6.1

**Pair:** Student A (_name_) & Student B (_name_)  |  **Dates:** _fill in_

> Template: replace the italic placeholders with what you actually did. Keep it honest; the rubric grades equal participation.

| Session | Driver | Navigator | Task | Notes / decisions |
|---|---|---|---|---|
| 1 (first half) | A | B | `init_restaurant_db.sql`, `db_tools.py` | _e.g. fuzzy item matching so the LLM can't invent items_ |
| 1 (first half) | A | B | `fsm_agent.py` tool schemas + FSM states | _e.g. session_id injected in code, never chosen by the LLM_ |
| **Rotation** | | | _swap roles halfway_ | |
| 2 (second half) | B | A | Web dashboard (`static/index.html`), Flask routes | _e.g. polling cart every 1.5 s_ |
| 2 (second half) | B | A | Edge-case testing (out-of-stock, removing missing items) | _bugs found / fixed_ |

## Key design decisions
1. Stock is only deducted at `STATE_CONFIRMED`, inside one SQLite transaction.
2. The live tab is re-injected into the system prompt every turn (memory + anti-hallucination).
3. _add your own_

## What each person learned
- A: _..._
- B: _..._
