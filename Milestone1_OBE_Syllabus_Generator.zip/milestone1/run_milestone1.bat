@echo off
REM ============================================================================
REM run_milestone1.bat
REM AI-Powered OBE Syllabus Generator Microservice - Milestone 1 Launcher
REM Two-Pass Ollama Course Outcomes Engine (K/S/A schema validated)
REM Just double-click. Uses whichever Ollama model you already have installed.
REM ============================================================================

setlocal
cd /d "%~dp0"

echo ============================================================
echo  CCS OBE SYLLABUS GENERATOR - MILESTONE 1
echo  Structured LLM Engine ^& Schema Validation
echo ============================================================
echo.

REM --- Check Python is available -------------------------------------------
where python >nul 2>nul
if errorlevel 1 (
    echo [-] Python was not found on PATH.
    echo     Install Python 3.10+ from https://www.python.org/downloads/
    echo     and check "Add python.exe to PATH" during setup.
    echo.
    pause
    exit /b 1
)

REM --- Ensure required packages are installed -------------------------------
echo [*] Checking required Python packages...
python -c "import pydantic" >nul 2>nul
if errorlevel 1 (
    echo [*] Installing pydantic...
    python -m pip install pydantic --quiet
)
python -c "import ollama" >nul 2>nul
if errorlevel 1 (
    echo [*] Installing ollama Python client...
    python -m pip install ollama --quiet
)
echo.

REM --- Check Ollama daemon is reachable --------------------------------------
where ollama >nul 2>nul
if errorlevel 1 (
    echo [-] Ollama was not found on PATH.
    echo     Install it from https://ollama.com/download
    echo.
    pause
    exit /b 1
)

echo [*] Running the batch Course Outcomes engine against your local Ollama...
echo     (auto-detects whichever model you already have installed)
echo.
python llm_engine.py --retries 3 --output sample_validated_output.json

echo.
echo ============================================================
echo  Output saved to: sample_validated_output.json
echo ============================================================
echo.
pause
endlocal
