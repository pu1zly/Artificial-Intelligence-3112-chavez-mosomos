"""Finite-state controller + Ollama (qwen2.5) tool-calling loop with per-session memory."""
import datetime, json, os, re
import ollama
import db_tools as db

MODEL = os.environ.get("OLLAMA_MODEL", "qwen2.5")
GREETING, TAKING_ORDER, REVIEW, CONFIRMED = "STATE_GREETING", "STATE_TAKING_ORDER", "STATE_REVIEW", "STATE_CONFIRMED"
LOG_PATH = os.path.join(db.HERE, "sample_conversation_log.json")
CONFIRM_RE = re.compile(r"^\s*(yes|yep|yeah|confirm|confirmed|ok|okay|correct|looks good|send it|that'?s right)\b", re.I)
REVIEW_RE = re.compile(r"\b(that'?s all|that is all|i'?m done|im done|bill|check ?out|review|finish|done)\b", re.I)


def _tool(name, desc, props=None, req=()):
    return {"type": "function", "function": {"name": name, "description": desc,
            "parameters": {"type": "object", "properties": props or {}, "required": list(req)}}}


TOOLS = [
    _tool("get_menu_by_category", "List menu items (with ids, prices, stock, allergens). Use 'all' for everything.",
          {"category": {"type": "string", "description": "Mains, Pasta, Sides, Drinks, Desserts or all"}}, ["category"]),
    _tool("check_item_allergen", "Check whether a menu item contains an allergen.",
          {"item_id": {"type": "integer"}, "allergen": {"type": "string"}}, ["item_id", "allergen"]),
    _tool("add_item_to_order", "Add a menu item to the customer's tab.",
          {"item_name": {"type": "string"}, "qty": {"type": "integer"},
           "instructions": {"type": "string", "description": "e.g. 'no onions, extra cheese'"}}, ["item_name", "qty"]),
    _tool("remove_item_from_order", "Remove an item (or some quantity of it) from the tab.",
          {"item_name": {"type": "string"}, "qty": {"type": "integer", "description": "omit to remove all"}}, ["item_name"]),
    _tool("view_current_order", "Show the current tab with totals."),
    _tool("proceed_to_review", "Call when the customer says they are finished ordering."),
]
MUTATING = {"add_item_to_order", "remove_item_from_order"}


class WaiterAgent:
    def __init__(self):
        if not self._load():
            self.reset()

    # ------------------------------------------------------------ persistence (survives refresh + restart)
    def _persist(self):
        db.save_kiosk_state({"state": self.state, "session_id": self.session_id, "table_no": self.table_no,
                             "history": self.history, "transcript": self.transcript, "log": self.log,
                             "receipt": self.receipt})

    def _load(self):
        try:
            d = db.load_kiosk_state()
            if not d or (d["session_id"] and not db.session_exists(d["session_id"])):
                return False
            self.state, self.session_id, self.table_no = d["state"], d["session_id"], d["table_no"]
            self.history, self.transcript, self.log, self.receipt = d["history"], d["transcript"], d["log"], d["receipt"]
            self._log("session_resumed")
            return True
        except Exception:
            return False

    # ------------------------------------------------------------ session
    def reset(self):
        self.state, self.session_id, self.table_no = GREETING, None, None
        self.history, self.transcript, self.log, self.receipt = [], [], [], None
        greeting = "Welcome to Perpetual Bistro! Which table number are you at?"
        self.transcript.append({"role": "waiter", "text": greeting})
        self._log("session_reset")

    def _log(self, event, **data):
        self.log.append({"time": datetime.datetime.now().isoformat(timespec="seconds"),
                         "state": self.state, "event": event, **data})
        self._persist()

    def _go(self, new, reason):
        self._log("state_transition", from_state=self.state, to_state=new, reason=reason)
        self.state = new
        self._persist()

    def snapshot(self):
        order = db.view_current_order(self.session_id) if self.session_id else None
        return {"state": self.state, "table_no": self.table_no, "transcript": self.transcript,
                "order": order, "receipt": self.receipt}

    def save_log(self):
        with open(LOG_PATH, "w") as f:
            json.dump({"table_no": self.table_no, "session_id": self.session_id, "events": self.log}, f, indent=2)

    # ------------------------------------------------------------ actions
    def say(self, text):
        self.transcript.append({"role": "waiter", "text": text})
        self._persist()
        return text

    def go_review(self):
        if self.state != TAKING_ORDER:
            return
        if not db.view_current_order(self.session_id)["items"]:
            self.say("Your tab is empty. Tell me what you'd like first.")
            return
        self._go(REVIEW, "customer finished ordering")
        self.say(self._summary() + " Is everything correct? Say 'confirm' or press Confirm order.")

    def confirm(self):
        if self.state != REVIEW:
            return
        res = db.confirm_order(self.session_id)
        self._log("confirm_order", result=res)
        if not res["ok"]:
            self._go(TAKING_ORDER, "confirmation failed")
            self.say(f"Sorry, I couldn't confirm: {res['error']} Let's adjust your order.")
            return
        self.receipt = res["receipt"]
        self._go(CONFIRMED, "customer confirmed")
        self._log("db_state", order=self.receipt)
        self.say(f"Order confirmed and sent to the kitchen. Total {self.receipt['total']:.2f} PHP. Thank you!")
        self.save_log()

    def adjust(self, line_id, delta):
        res = db.adjust_line(int(line_id), int(delta))
        self._log("manual_adjust", line_id=line_id, delta=delta, result=res)
        return res

    def _summary(self):
        o = db.view_current_order(self.session_id)
        lines = ", ".join(f"{i['quantity']}x {i['name']}" + (f" ({i['instructions']})" if i["instructions"] else "")
                          for i in o["items"])
        return f"Your tab: {lines}. Subtotal {o['subtotal']:.2f}, service fee {o['service_fee']:.2f}, total {o['total']:.2f} PHP."

    # ------------------------------------------------------------ conversation
    def handle_user(self, text):
        self.transcript.append({"role": "user", "text": text})
        self._log("user_message", text=text)
        if self.state == GREETING:
            m = re.search(r"\d+", text)
            if not m:
                return self.say("I didn't catch a table number. What number is on your table?")
            self.table_no = int(m.group())
            self.session_id = db.create_session(self.table_no)
            self._go(TAKING_ORDER, f"table {self.table_no} captured")
            return self.say(f"Welcome to Table {self.table_no}! I can show the menu, check allergens, and take your order. What would you like?")
        if self.state == CONFIRMED:
            return self.say("Your order is already confirmed. Press 'New table' to start another.")
        if self.state == REVIEW and CONFIRM_RE.match(text):
            self.confirm()
            return self.transcript[-1]["text"]
        if self.state == TAKING_ORDER and REVIEW_RE.search(text) and not re.search(r"\b(add|remove|no|extra)\b", text, re.I):
            self.go_review()
            return self.transcript[-1]["text"]
        return self.say(self._llm_turn(text))

    def _system_prompt(self):
        return (f"You are the virtual waiter at Perpetual Bistro, serving Table {self.table_no}. Current state: {self.state}.\n"
                "Rules: ONLY mention menu items, prices, stock or allergens returned by tools - never invent them. "
                "To add, remove or list anything you MUST call a tool; never claim a change without a successful tool result. "
                "Put modifications (e.g. 'no onions', 'extra cheese') in the 'instructions' argument. "
                "If a tool returns an error or suggestions, tell the customer plainly and offer alternatives. "
                "Keep replies to 1-3 short sentences. Prices are in PHP.\n"
                f"Ground truth of the tab right now: {json.dumps(db.view_current_order(self.session_id))}")

    def _llm_turn(self, text):
        self.history.append({"role": "user", "content": text})
        self.history = self.history[-30:]
        try:
            for _ in range(6):
                resp = ollama.chat(model=MODEL, tools=TOOLS,
                                   messages=[{"role": "system", "content": self._system_prompt()}] + self.history)
                msg = resp.message
                calls = msg.tool_calls or []
                self.history.append({"role": "assistant", "content": msg.content or "",
                                     **({"tool_calls": [{"function": {"name": c.function.name,
                                         "arguments": dict(c.function.arguments)}} for c in calls]} if calls else {})})
                if not calls:
                    return (msg.content or "").strip() or "Sorry, could you say that again?"
                for c in calls:
                    result = self._run_tool(c.function.name, dict(c.function.arguments))
                    self.history.append({"role": "tool", "tool_name": c.function.name, "content": json.dumps(result)})
            return "Sorry, I got tangled up - could you repeat that?"
        except Exception as e:  # Ollama offline, model missing, etc.
            self._log("llm_error", error=str(e))
            return f"My ordering brain is offline ({type(e).__name__}). Make sure `ollama serve` is running and `ollama pull {MODEL}` is done."

    def _run_tool(self, name, args):
        args.pop("session_id", None)  # the LLM never controls the session
        fn = {"get_menu_by_category": db.get_menu_by_category, "check_item_allergen": db.check_item_allergen,
              "add_item_to_order": db.add_item_to_order, "remove_item_from_order": db.remove_item_from_order}.get(name)
        try:
            if name == "proceed_to_review":
                if db.view_current_order(self.session_id)["items"]:
                    self._go(REVIEW, "LLM called proceed_to_review")
                    result = {"ok": True, "message": "Now in review. Summarise the tab for the customer."}
                else:
                    result = {"ok": False, "error": "The tab is empty."}
            elif name == "view_current_order":
                result = {"ok": True, **db.view_current_order(self.session_id)}
            elif fn:
                if name in ("add_item_to_order", "remove_item_from_order"):
                    args["session_id"] = self.session_id
                result = fn(**args)
                if name in MUTATING and result.get("ok") and self.state == REVIEW:
                    self._go(TAKING_ORDER, "order edited during review")
            else:
                result = {"ok": False, "error": f"Unknown tool '{name}'."}
        except (TypeError, ValueError, KeyError) as e:
            result = {"ok": False, "error": f"Bad arguments: {e}"}
        self._log("tool_call", tool=name, arguments=args, result=result)
        self._log("db_state", order=db.view_current_order(self.session_id))
        return result
