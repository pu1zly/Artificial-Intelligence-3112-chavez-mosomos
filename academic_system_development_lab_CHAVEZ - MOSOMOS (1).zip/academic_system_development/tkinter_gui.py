"""Tkinter interface for the OBE course outcome and syllabus generators.

GUI enhancements by Mosomos (collaboration continuation on Chavez's pipeline):
  - Tabbed, readable previews (Course Outcomes table / Weekly Schedule table / Raw JSON)
  - Menu bar with recent files, keyboard shortcuts, and an About dialog
  - Persisted settings + recent files between sessions
  - Indeterminate progress bar while Ollama jobs run in the background
  - Inline field validation (red outline) instead of only popup errors
  - Model selector with common Ollama presets (still freely editable)
  - "Build 14-Week Syllabus" is disabled until Course Outcomes exist
  - Cross-platform "reveal in file manager" (Windows / macOS / Linux)
"""

import json
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText
from typing import Any, Callable, Optional

from lab1_1_generator import generate_course_outcomes
from lab1_2_pipeline import build_complete_syllabus
from obe_schemas import CourseOutcomePayload, OBESyllabusPayload


DEFAULT_TITLE = "Data Structures and Algorithms"
DEFAULT_CODE = "CS201"
DEFAULT_DESCRIPTION = "Fundamental data structures and algorithm analysis techniques."
DEFAULT_MODEL = "qwen2.5:1.5b"
MODEL_PRESETS = ["qwen2.5:1.5b", "qwen2.5:3b", "qwen2.5:7b", "llama3.1:8b", "mistral"]
MAX_RECENT_FILES = 5
CONFIG_PATH = Path(__file__).resolve().parent / "obe_gui_settings.json"

# Palette — adapted from the Azure Group reference swatch, tuned for
# screen comfort: no pure-white/pure-black pairing (too much glare over a
# long session), text/background contrast checked against WCAG AA (>=4.5:1
# for normal text) rather than just picked by eye.
COLOR_BG = "#F1F7F9"           # soft blue-white app background (not stark white)
COLOR_PANEL = "#FBFDFE"        # panel surfaces, barely-tinted off-white
COLOR_ACCENT = "#0A61C9"       # primary action blue (5.9:1 contrast with white text)
COLOR_ACCENT_DARK = "#064089"  # header / hover / pressed state
COLOR_ACCENT_DEEPEST = "#07326A"  # reserved for high-emphasis borders/focus
COLOR_TEXT = "#1B2733"         # near-black slate, softer than pure #000
COLOR_MUTED = "#4F6B85"        # muted blue-grey for hints (5.6:1 on white)
COLOR_SUCCESS = "#1E7145"
COLOR_ERROR = "#B3261E"
COLOR_BORDER = "#C9D6E6"       # soft blue border/divider, low visual noise


class OBEGeneratorApp(tk.Tk):
    """Desktop front end for the existing OBE generation pipeline."""

    def __init__(self) -> None:
        super().__init__()
        self.title("OBE Academic System")
        self.geometry("1200x800")
        self.minsize(900, 620)
        self.configure(bg=COLOR_BG)

        self._events: queue.Queue[tuple[str, Any]] = queue.Queue()
        self._worker_active = False
        self._course_payload: Optional[CourseOutcomePayload] = None
        self._syllabus_payload: Optional[OBESyllabusPayload] = None

        self._config = self._load_config()
        recent = self._config.get("recent_files", [])

        self.title_var = tk.StringVar(value=self._config.get("course_title", DEFAULT_TITLE))
        self.code_var = tk.StringVar(value=self._config.get("course_code", DEFAULT_CODE))
        self.pos_var = tk.StringVar(value=self._config.get("target_pos", "1,2,3,4"))
        self.model_var = tk.StringVar(value=self._config.get("model_name", DEFAULT_MODEL))
        self.retries_var = tk.IntVar(value=self._config.get("max_retries", 3))
        self.co_output_var = tk.StringVar(value=self._config.get("co_output", "lab1_1_output.json"))
        self.syllabus_output_var = tk.StringVar(
            value=self._config.get("syllabus_output", "sample_output_syllabus.json")
        )
        self.status_var = tk.StringVar(value="Ready")
        self._recent_files: list[str] = recent

        self._build_style()
        self._build_menu()
        self._build_layout()
        self.description_text.insert("1.0", self._config.get("course_description", DEFAULT_DESCRIPTION))
        self._refresh_build_button_state()
        self._refresh_recent_menu()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(100, self._process_events)

    # ------------------------------------------------------------------
    # Style / layout
    # ------------------------------------------------------------------
    def _build_style(self) -> None:
        style = ttk.Style(self)
        if "clam" in style.theme_names():
            style.theme_use("clam")

        style.configure(".", background=COLOR_BG, foreground=COLOR_TEXT, font=("Segoe UI", 10))
        style.configure("TFrame", background=COLOR_BG)
        style.configure("Panel.TFrame", background=COLOR_PANEL)
        style.configure("TLabelframe", background=COLOR_PANEL, bordercolor=COLOR_BORDER)
        style.configure("TLabelframe.Label", background=COLOR_PANEL, foreground=COLOR_TEXT, font=("Segoe UI", 10, "bold"))
        style.configure("TLabel", background=COLOR_BG, foreground=COLOR_TEXT)
        style.configure("Panel.TLabel", background=COLOR_PANEL, foreground=COLOR_TEXT)
        style.configure("Header.TFrame", background=COLOR_ACCENT_DARK)
        style.configure("Header.TLabel", background=COLOR_ACCENT_DARK, foreground="white")
        style.configure("Title.TLabel", background=COLOR_ACCENT_DARK, foreground="white", font=("Segoe UI", 20, "bold"))
        style.configure("Subtitle.TLabel", background=COLOR_ACCENT_DARK, foreground="#D6E7F7", font=("Segoe UI", 10))
        style.configure("Section.TLabel", background=COLOR_PANEL, font=("Segoe UI", 11, "bold"))
        style.configure(
            "Action.TButton",
            padding=(12, 9),
            background=COLOR_ACCENT,
            foreground="white",
            font=("Segoe UI", 10, "bold"),
        )
        style.map(
            "Action.TButton",
            background=[("active", COLOR_ACCENT_DARK), ("disabled", "#9FB6D6")],
            foreground=[("disabled", "#EAF1F8")],
        )
        style.configure("Secondary.TButton", padding=(10, 6))
        # Hide the dotted keyboard-focus ring by matching it to each button's
        # own background instead of the theme default (it was rendering as a
        # distracting "double box" around whichever button last had focus).
        style.configure("TButton", focuscolor=style.lookup("TButton", "background"))
        style.map("Action.TButton", focuscolor=[("!disabled", COLOR_ACCENT)])
        style.configure("Secondary.TButton", focuscolor="#E4EEF7")
        style.configure("Invalid.TEntry", fieldbackground="#FBEAE8", bordercolor=COLOR_ERROR)
        style.configure("Status.TLabel", background="#E4EEF7", foreground=COLOR_MUTED, padding=(8, 4))
        style.configure("StatusOk.TLabel", background="#E3F3E8", foreground=COLOR_SUCCESS, padding=(8, 4))
        style.configure("StatusErr.TLabel", background="#FBEAE8", foreground=COLOR_ERROR, padding=(8, 4))
        style.configure("Hint.TLabel", background=COLOR_PANEL, foreground=COLOR_MUTED, font=("Segoe UI", 8, "italic"))
        style.configure("Treeview", rowheight=26, font=("Segoe UI", 9), background=COLOR_PANEL,
                        fieldbackground=COLOR_PANEL, foreground=COLOR_TEXT, bordercolor=COLOR_BORDER)
        style.map("Treeview", background=[("selected", COLOR_ACCENT)], foreground=[("selected", "white")])
        style.configure(
            "Treeview.Heading",
            font=("Segoe UI", 9, "bold"),
            background=COLOR_ACCENT_DARK,
            foreground="white",
            relief="flat",
        )
        style.map("Treeview.Heading", background=[("active", COLOR_ACCENT_DARK)])

    def _build_menu(self) -> None:
        menubar = tk.Menu(self)

        file_menu = tk.Menu(menubar, tearoff=False)
        file_menu.add_command(label="Open Course Outcomes...", accelerator="Ctrl+O", command=self.load_course_outcomes)
        self._recent_menu = tk.Menu(file_menu, tearoff=False)
        file_menu.add_cascade(label="Open Recent", menu=self._recent_menu)
        file_menu.add_separator()
        file_menu.add_command(label="Save Course Outcomes As...", command=lambda: self._choose_output(self.co_output_var, "Save Course Outcomes"))
        file_menu.add_command(label="Save Syllabus As...", command=lambda: self._choose_output(self.syllabus_output_var, "Save Syllabus"))
        file_menu.add_separator()
        file_menu.add_command(label="Exit", accelerator="Ctrl+Q", command=self._on_close)
        menubar.add_cascade(label="File", menu=file_menu)

        run_menu = tk.Menu(menubar, tearoff=False)
        run_menu.add_command(label="Generate Course Outcomes", accelerator="Ctrl+G", command=self.generate_outcomes)
        run_menu.add_command(label="Build 14-Week Syllabus", accelerator="Ctrl+B", command=self.build_syllabus)
        menubar.add_cascade(label="Run", menu=run_menu)

        help_menu = tk.Menu(menubar, tearoff=False)
        help_menu.add_command(label="About", command=self._show_about)
        menubar.add_cascade(label="Help", menu=help_menu)

        self.config(menu=menubar)
        self.bind_all("<Control-o>", lambda _e: self.load_course_outcomes())
        self.bind_all("<Control-g>", lambda _e: self.generate_outcomes())
        self.bind_all("<Control-b>", lambda _e: self.build_syllabus())
        self.bind_all("<Control-q>", lambda _e: self._on_close())

    def _build_layout(self) -> None:
        header = ttk.Frame(self, style="Header.TFrame", padding=(24, 18))
        header.pack(fill="x")
        ttk.Label(header, text="OBE Academic System", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            header,
            text="Generate validated course outcomes and a complete 14-week syllabus with Ollama.",
            style="Subtitle.TLabel",
        ).pack(anchor="w", pady=(2, 0))

        body = ttk.Frame(self, padding=16)
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, minsize=380)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        # ---- Left: settings panel (scrollable) ----
        settings_outer = ttk.Frame(body, style="Panel.TFrame", width=380)
        settings_outer.grid(row=0, column=0, sticky="nsew", padx=(0, 16))
        settings_outer.grid_propagate(False)
        settings_canvas = tk.Canvas(settings_outer, bg=COLOR_PANEL, highlightthickness=0)
        settings_scroll = ttk.Scrollbar(settings_outer, orient="vertical", command=settings_canvas.yview)
        settings = ttk.Frame(settings_canvas, style="Panel.TFrame", padding=16)
        settings_window = settings_canvas.create_window((0, 0), window=settings, anchor="nw")

        def _sync_scrollregion(_event: tk.Event) -> None:
            settings_canvas.configure(scrollregion=settings_canvas.bbox("all"))

        def _sync_inner_width(event: tk.Event) -> None:
            # Keep the inner frame exactly as wide as the visible canvas so
            # content never gets clipped off to the right (the earlier fixed
            # canvas width was cutting off the "Reveal" buttons and path text).
            settings_canvas.itemconfig(settings_window, width=event.width)

        settings.bind("<Configure>", _sync_scrollregion)
        settings_canvas.bind("<Configure>", _sync_inner_width)
        settings_canvas.configure(yscrollcommand=settings_scroll.set)
        settings_canvas.pack(side="left", fill="both", expand=True)
        settings_scroll.pack(side="right", fill="y")

        def _on_mousewheel(event: tk.Event) -> None:
            settings_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        settings_canvas.bind("<Enter>", lambda _e: settings_canvas.bind_all("<MouseWheel>", _on_mousewheel))
        settings_canvas.bind("<Leave>", lambda _e: settings_canvas.unbind_all("<MouseWheel>"))

        settings.columnconfigure(1, weight=1)
        ttk.Label(settings, text="Course & model settings", style="Section.TLabel").grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 10)
        )

        self.title_entry = self._add_entry(settings, 1, "Course title", self.title_var)
        self.code_entry = self._add_entry(settings, 2, "Course code", self.code_var)
        self.pos_entry = self._add_entry(settings, 3, "Target POs (1-6)", self.pos_var)

        ttk.Label(settings, text="Ollama model", style="Panel.TLabel").grid(row=4, column=0, sticky="w", pady=4, padx=(0, 8))
        self.model_combo = ttk.Combobox(settings, textvariable=self.model_var, values=MODEL_PRESETS, width=27)
        self.model_combo.grid(row=4, column=1, sticky="ew", pady=4)

        self.retries_entry = self._add_entry(settings, 5, "Max retries", self.retries_var, width=8)

        ttk.Label(settings, text="Description", style="Panel.TLabel").grid(row=6, column=0, sticky="nw", pady=(10, 4))
        description = tk.Text(settings, height=5, width=28, wrap="word", relief="solid", borderwidth=1)
        description.grid(row=6, column=1, sticky="ew", pady=(10, 4))
        self.description_text = description

        ttk.Separator(settings).grid(row=7, column=0, columnspan=2, sticky="ew", pady=12)
        ttk.Label(settings, text="Output files", style="Section.TLabel").grid(
            row=8, column=0, columnspan=2, sticky="w", pady=(0, 6)
        )
        self._add_path_row(settings, 9, "CO JSON", self.co_output_var, "Save Course Outcomes")
        self._add_path_row(settings, 10, "Syllabus JSON", self.syllabus_output_var, "Save Syllabus")

        actions = ttk.Frame(settings, style="Panel.TFrame")
        actions.grid(row=11, column=0, columnspan=2, sticky="ew", pady=(18, 4))
        actions.columnconfigure(0, weight=1)
        self.generate_button = ttk.Button(
            actions, text="Step 1 · Generate Course Outcomes", style="Action.TButton", command=self.generate_outcomes
        )
        self.generate_button.grid(row=0, column=0, sticky="ew", pady=3)
        self.build_button = ttk.Button(
            actions, text="Step 2 · Build 14-Week Syllabus", style="Action.TButton", command=self.build_syllabus
        )
        self.build_button.grid(row=1, column=0, sticky="ew", pady=3)
        ttk.Button(actions, text="Load CO JSON from disk", style="Secondary.TButton", command=self.load_course_outcomes).grid(
            row=2, column=0, sticky="ew", pady=3
        )
        self.build_hint = ttk.Label(
            actions, text="Generate or load Course Outcomes first.", style="Hint.TLabel", wraplength=260
        )
        self.build_hint.grid(row=3, column=0, sticky="w", pady=(6, 0))

        self.progress = ttk.Progressbar(actions, mode="indeterminate")
        self.progress.grid(row=4, column=0, sticky="ew", pady=(10, 0))

        # ---- Right: tabbed results ----
        results = ttk.Frame(body)
        results.grid(row=0, column=1, sticky="nsew")
        results.columnconfigure(0, weight=1)
        results.rowconfigure(0, weight=1)

        notebook = ttk.Notebook(results)
        notebook.grid(row=0, column=0, sticky="nsew")
        self.notebook = notebook

        # Course outcomes tab
        co_tab = ttk.Frame(notebook, style="Panel.TFrame", padding=10)
        notebook.add(co_tab, text="Course Outcomes")
        co_tab.columnconfigure(0, weight=1)
        co_tab.rowconfigure(0, weight=1)
        co_columns = ("num", "bloom", "po", "desc")
        self.co_tree = ttk.Treeview(co_tab, columns=co_columns, show="headings")
        self.co_tree.heading("num", text="CO#")
        self.co_tree.heading("bloom", text="Bloom Level")
        self.co_tree.heading("po", text="Mapped POs")
        self.co_tree.heading("desc", text="Description")
        self.co_tree.column("num", width=45, anchor="center")
        self.co_tree.column("bloom", width=180)
        self.co_tree.column("po", width=90, anchor="center")
        self.co_tree.column("desc", width=460)
        self.co_tree.grid(row=0, column=0, sticky="nsew")
        co_scroll = ttk.Scrollbar(co_tab, orient="vertical", command=self.co_tree.yview)
        self.co_tree.configure(yscrollcommand=co_scroll.set)
        co_scroll.grid(row=0, column=1, sticky="ns")

        # Weekly schedule tab
        week_tab = ttk.Frame(notebook, style="Panel.TFrame", padding=10)
        notebook.add(week_tab, text="Weekly Schedule")
        week_tab.columnconfigure(0, weight=1)
        week_tab.rowconfigure(1, weight=1)
        ttk.Label(week_tab, text="Double-click a week to see its full details (LLOs, TLA, assessment, evidence).", style="Hint.TLabel").grid(
            row=0, column=0, sticky="w", pady=(0, 6)
        )
        week_columns = ("week", "period", "topic", "aligned")
        self.week_tree = ttk.Treeview(week_tab, columns=week_columns, show="headings")
        self.week_tree.heading("week", text="Week")
        self.week_tree.heading("period", text="Period")
        self.week_tree.heading("topic", text="Topic")
        self.week_tree.heading("aligned", text="Aligned CO")
        self.week_tree.column("week", width=55, anchor="center")
        self.week_tree.column("period", width=90, anchor="center")
        self.week_tree.column("topic", width=420)
        self.week_tree.column("aligned", width=100, anchor="center")
        self.week_tree.grid(row=1, column=0, sticky="nsew")
        week_scroll = ttk.Scrollbar(week_tab, orient="vertical", command=self.week_tree.yview)
        self.week_tree.configure(yscrollcommand=week_scroll.set)
        week_scroll.grid(row=1, column=1, sticky="ns")
        self.week_tree.bind("<Double-1>", self._show_week_detail)
        self._week_lookup: dict[str, dict[str, Any]] = {}

        # Raw JSON tab
        json_tab = ttk.Frame(notebook, style="Panel.TFrame", padding=10)
        notebook.add(json_tab, text="Raw JSON")
        json_tab.columnconfigure(0, weight=1)
        json_tab.rowconfigure(0, weight=1)
        self.preview = ScrolledText(json_tab, wrap="none", undo=False, font=("Cascadia Mono", 10), relief="solid", borderwidth=1)
        self.preview.grid(row=0, column=0, sticky="nsew")
        self.preview.configure(state="disabled")

        # ---- Status bar ----
        self.status_label = ttk.Label(self, textvariable=self.status_var, style="Status.TLabel", anchor="w")
        self.status_label.pack(fill="x", side="bottom")

    def _add_entry(
        self, parent: ttk.Widget, row: int, label: str, variable: tk.Variable, width: int = 27
    ) -> ttk.Entry:
        ttk.Label(parent, text=label, style="Panel.TLabel").grid(row=row, column=0, sticky="w", pady=4, padx=(0, 8))
        entry = ttk.Entry(parent, textvariable=variable, width=width)
        entry.grid(row=row, column=1, sticky="ew", pady=4)
        return entry

    def _add_path_row(
        self, parent: ttk.Widget, row: int, label: str, variable: tk.StringVar, dialog_title: str
    ) -> None:
        ttk.Label(parent, text=label, style="Panel.TLabel").grid(row=row, column=0, sticky="w", pady=4, padx=(0, 8))
        path_frame = ttk.Frame(parent, style="Panel.TFrame")
        path_frame.grid(row=row, column=1, sticky="ew", pady=4)
        path_frame.columnconfigure(0, weight=1)
        entry = ttk.Entry(path_frame, textvariable=variable)
        entry.grid(row=0, column=0, sticky="ew")
        ttk.Button(
            path_frame,
            text="...",
            width=3,
            style="Secondary.TButton",
            command=lambda: self._choose_output(variable, dialog_title),
        ).grid(row=0, column=1, padx=(4, 0))
        ttk.Button(
            path_frame,
            text="\U0001F4C2",  # folder icon, keeps the button narrow
            width=3,
            style="Secondary.TButton",
            command=lambda: self._reveal_in_file_manager(variable),
        ).grid(row=0, column=2, padx=(4, 0))
        # Full path always available on hover, even when the entry text is
        # too long to fit in the narrow panel.
        self._add_tooltip(entry, variable)

    def _add_tooltip(self, widget: tk.Widget, variable: tk.StringVar) -> None:
        """Minimal hover tooltip showing the full text of a variable.

        Used on the output-path entries so the full path is still readable
        on hover even when it's too long to fit in the narrow settings panel.
        """
        tip = {"window": None}

        def show(_event: tk.Event) -> None:
            text = variable.get().strip()
            if not text or tip["window"] is not None:
                return
            x = widget.winfo_rootx()
            y = widget.winfo_rooty() + widget.winfo_height() + 4
            top = tk.Toplevel(widget)
            top.wm_overrideredirect(True)
            top.wm_geometry(f"+{x}+{y}")
            label = tk.Label(
                top, text=text, background=COLOR_ACCENT_DEEPEST, foreground="white",
                padx=6, pady=3, font=("Segoe UI", 8),
            )
            label.pack()
            tip["window"] = top

        def hide(_event: tk.Event) -> None:
            if tip["window"] is not None:
                tip["window"].destroy()
                tip["window"] = None

        widget.bind("<Enter>", show)
        widget.bind("<Leave>", hide)

    # ------------------------------------------------------------------
    # Config persistence
    # ------------------------------------------------------------------
    def _load_config(self) -> dict[str, Any]:
        try:
            with CONFIG_PATH.open("r", encoding="utf-8") as file:
                data = json.load(file)
                if isinstance(data, dict):
                    return data
        except (OSError, json.JSONDecodeError):
            pass
        return {}

    def _save_config(self) -> None:
        data = {
            "course_title": self.title_var.get(),
            "course_code": self.code_var.get(),
            "course_description": self.description_text.get("1.0", "end").strip(),
            "target_pos": self.pos_var.get(),
            "model_name": self.model_var.get(),
            "max_retries": self.retries_var.get(),
            "co_output": self.co_output_var.get(),
            "syllabus_output": self.syllabus_output_var.get(),
            "recent_files": self._recent_files[:MAX_RECENT_FILES],
        }
        try:
            with CONFIG_PATH.open("w", encoding="utf-8") as file:
                json.dump(data, file, indent=2)
        except OSError:
            pass

    def _on_close(self) -> None:
        self._save_config()
        self.destroy()

    def _remember_recent_file(self, path: str) -> None:
        if not path:
            return
        path = str(Path(path).resolve())
        self._recent_files = [path] + [p for p in self._recent_files if p != path]
        self._recent_files = self._recent_files[:MAX_RECENT_FILES]
        self._refresh_recent_menu()

    def _refresh_recent_menu(self) -> None:
        self._recent_menu.delete(0, "end")
        if not self._recent_files:
            self._recent_menu.add_command(label="(No recent files)", state="disabled")
            return
        for path in self._recent_files:
            self._recent_menu.add_command(
                label=path, command=lambda p=path: self._load_course_outcomes_from_path(p)
            )

    # ------------------------------------------------------------------
    # File dialogs / OS integration
    # ------------------------------------------------------------------
    def _choose_output(self, variable: tk.StringVar, title: str) -> None:
        path = filedialog.asksaveasfilename(
            title=title,
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
        )
        if path:
            variable.set(path)

    def _reveal_in_file_manager(self, variable: tk.StringVar) -> None:
        raw = variable.get().strip()
        if not raw:
            messagebox.showinfo("No output path", "Choose an output file path first.")
            return

        path = Path(raw).expanduser().resolve()
        target_dir = path.parent
        try:
            target_dir.mkdir(parents=True, exist_ok=True)
            if sys.platform.startswith("win"):
                if path.exists():
                    subprocess.Popen(["explorer.exe", f"/select,{path}"])
                else:
                    os.startfile(target_dir)  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                if path.exists():
                    subprocess.Popen(["open", "-R", str(path)])
                else:
                    subprocess.Popen(["open", str(target_dir)])
            else:
                subprocess.Popen(["xdg-open", str(target_dir)])
        except OSError as error:
            messagebox.showerror("Could not open file manager", str(error))

    def _show_about(self) -> None:
        messagebox.showinfo(
            "About OBE Academic System",
            "OBE Academic System\n\n"
            "Course outcome & syllabus generation pipeline (Lab 1.1 / 1.2) by Chavez.\n"
            "GUI refinements by Mosomos.\n\n"
            "Keyboard shortcuts:\n"
            "  Ctrl+G  Generate Course Outcomes\n"
            "  Ctrl+B  Build 14-Week Syllabus\n"
            "  Ctrl+O  Open Course Outcomes JSON\n"
            "  Ctrl+Q  Exit",
        )

    # ------------------------------------------------------------------
    # Validation helpers
    # ------------------------------------------------------------------
    def _mark_invalid(self, entry: ttk.Entry, invalid: bool) -> None:
        entry.configure(style="Invalid.TEntry" if invalid else "TEntry")

    def _clear_validation(self) -> None:
        for entry in (self.title_entry, self.code_entry, self.pos_entry, self.retries_entry):
            self._mark_invalid(entry, False)

    def _parse_settings(self) -> dict[str, Any]:
        self._clear_validation()
        errors: list[str] = []

        title = self.title_var.get().strip()
        if not title:
            errors.append("Course title is required.")
            self._mark_invalid(self.title_entry, True)

        code = self.code_var.get().strip()
        if not code:
            errors.append("Course code is required.")
            self._mark_invalid(self.code_entry, True)

        description = self.description_text.get("1.0", "end").strip()
        if not description:
            errors.append("Course description is required.")

        target_pos: list[int] = []
        try:
            target_pos = [int(value.strip()) for value in self.pos_var.get().split(",") if value.strip()]
            if not target_pos or any(po < 1 or po > 6 for po in target_pos):
                raise ValueError
        except ValueError:
            errors.append("Target POs must be comma-separated numbers from 1 through 6 (e.g. 1,2,3).")
            self._mark_invalid(self.pos_entry, True)

        retries = 3
        try:
            retries = int(self.retries_var.get())
            if retries < 0:
                raise ValueError
        except (ValueError, tk.TclError):
            errors.append("Max retries must be a non-negative integer.")
            self._mark_invalid(self.retries_entry, True)

        if errors:
            raise ValueError("\n".join(errors))

        return {
            "course_title": title,
            "course_code": code,
            "course_description": description,
            "target_pos": target_pos,
            "model_name": self.model_var.get().strip() or DEFAULT_MODEL,
            "max_retries": retries,
        }

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------
    def generate_outcomes(self) -> None:
        try:
            settings = self._parse_settings()
        except ValueError as error:
            messagebox.showerror("Invalid settings", str(error))
            return

        output_path = self.co_output_var.get().strip()
        self._set_status("Generating course outcomes and saving the JSON file...", "busy")
        self._run_in_background(
            lambda: self._generate_outcomes_job(settings, output_path),
        )

    def _generate_outcomes_job(
        self, settings: dict[str, Any], output_path: str
    ) -> tuple[str, CourseOutcomePayload, str]:
        payload = generate_course_outcomes(**settings)
        json_output = payload.model_dump_json(indent=2)
        self._write_json(output_path, json_output)
        return json_output, payload, output_path

    def build_syllabus(self) -> None:
        if self._course_payload is None and not Path(self.co_output_var.get().strip() or "").exists():
            messagebox.showinfo(
                "Course Outcomes needed",
                "Generate or load Course Outcomes before building the syllabus.",
            )
            return
        try:
            settings = self._parse_settings()
        except ValueError as error:
            messagebox.showerror("Invalid settings", str(error))
            return

        output_path = self.syllabus_output_var.get().strip()
        self._set_status("Building the 14-week syllabus...", "busy")
        self._run_in_background(
            lambda: self._build_syllabus_job(settings, output_path),
        )

    def _build_syllabus_job(
        self, settings: dict[str, Any], output_path: str
    ) -> tuple[str, None, str]:
        payload = self._course_payload
        if payload is None:
            co_path = Path(self.co_output_var.get().strip())
            if not co_path.exists():
                raise FileNotFoundError("Generate or load Course Outcomes before building the syllabus.")
            with co_path.open("r", encoding="utf-8") as file:
                payload = CourseOutcomePayload.model_validate(json.load(file))

        syllabus = build_complete_syllabus(
            course_metadata=payload,
            model_name=settings["model_name"],
            max_retries=settings["max_retries"],
        )
        json_output = syllabus.model_dump_json(indent=2)
        self._write_json(output_path, json_output)
        return json_output, None, output_path

    def load_course_outcomes(self) -> None:
        path = filedialog.askopenfilename(
            title="Open Course Outcomes JSON",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
        )
        if not path:
            return
        self._load_course_outcomes_from_path(path)

    def _load_course_outcomes_from_path(self, path: str) -> None:
        try:
            with open(path, "r", encoding="utf-8") as file:
                payload = CourseOutcomePayload.model_validate(json.load(file))
        except (OSError, json.JSONDecodeError, ValueError) as error:
            messagebox.showerror("Could not load Course Outcomes", str(error))
            return

        self._course_payload = payload
        self.co_output_var.set(path)
        self._show_preview(payload.model_dump_json(indent=2))
        self._populate_co_tree(payload)
        self._remember_recent_file(path)
        self._refresh_build_button_state()
        self._set_status(f"Loaded Course Outcomes from {path}", "ok")
        self.notebook.select(0)

    # ------------------------------------------------------------------
    # Background job plumbing
    # ------------------------------------------------------------------
    def _run_in_background(self, job: Callable[[], tuple[str, Any, str]]) -> None:
        if self._worker_active:
            messagebox.showinfo("Generation in progress", "Please wait for the current operation to finish.")
            return
        self._worker_active = True
        self._set_buttons_enabled(False)
        self.progress.start(12)

        def worker() -> None:
            try:
                result = job()
                self._events.put(("success", result))
            except Exception as error:  # noqa: BLE001 - surfaced to the UI
                self._events.put(("error", error))

        threading.Thread(target=worker, daemon=True).start()

    def _process_events(self) -> None:
        try:
            event, payload = self._events.get_nowait()
        except queue.Empty:
            self.after(100, self._process_events)
            return

        self._worker_active = False
        self.progress.stop()
        self._set_buttons_enabled(True)
        if event == "success":
            json_output, course_payload, output_path = payload
            if course_payload is not None:
                self._course_payload = course_payload
                self._populate_co_tree(course_payload)
                self._remember_recent_file(output_path)
            else:
                try:
                    self._syllabus_payload = OBESyllabusPayload.model_validate_json(json_output)
                    self._populate_week_tree(self._syllabus_payload)
                    self.notebook.select(1)
                except ValueError:
                    pass
            try:
                saved_output = Path(output_path).read_text(encoding="utf-8")
            except OSError as error:
                self._set_status("Completed, but preview could not be refreshed", "error")
                messagebox.showerror("Preview refresh failed", str(error))
            else:
                self._show_preview(saved_output)
                self._set_status(f"Saved and preview refreshed: {output_path}", "ok")
            self._refresh_build_button_state()
        else:
            self._set_status("Operation failed", "error")
            messagebox.showerror("Generation failed", str(payload))
        self.after(100, self._process_events)

    def _set_buttons_enabled(self, enabled: bool) -> None:
        state = "normal" if enabled else "disabled"
        self.generate_button.configure(state=state)
        if enabled:
            self._refresh_build_button_state()
        else:
            self.build_button.configure(state="disabled")

    def _refresh_build_button_state(self) -> None:
        has_co = self._course_payload is not None or Path(self.co_output_var.get().strip() or "").exists()
        self.build_button.configure(state="normal" if has_co else "disabled")
        self.build_hint.configure(
            text="Ready to build the syllabus." if has_co else "Generate or load Course Outcomes first."
        )

    def _set_status(self, text: str, kind: str = "info") -> None:
        self.status_var.set(text)
        style = {"ok": "StatusOk.TLabel", "error": "StatusErr.TLabel"}.get(kind, "Status.TLabel")
        self.status_label.configure(style=style)

    # ------------------------------------------------------------------
    # Preview population
    # ------------------------------------------------------------------
    def _show_preview(self, text: str) -> None:
        self.preview.configure(state="normal")
        self.preview.delete("1.0", "end")
        self.preview.insert("1.0", text)
        self.preview.configure(state="disabled")

    def _populate_co_tree(self, payload: CourseOutcomePayload) -> None:
        self.co_tree.delete(*self.co_tree.get_children())
        self.co_tree.tag_configure("odd", background=COLOR_BG)
        self.co_tree.tag_configure("even", background=COLOR_PANEL)
        for index, outcome in enumerate(payload.course_outcomes):
            self.co_tree.insert(
                "",
                "end",
                values=(
                    outcome.clo_number,
                    outcome.bloom_level,
                    ", ".join(str(po) for po in outcome.mapped_po),
                    outcome.co_description,
                ),
                tags=("odd" if index % 2 else "even",),
            )

    def _populate_week_tree(self, syllabus: OBESyllabusPayload) -> None:
        self.week_tree.delete(*self.week_tree.get_children())
        self.week_tree.tag_configure("odd", background=COLOR_BG)
        self.week_tree.tag_configure("even", background=COLOR_PANEL)
        self._week_lookup.clear()
        for index, week in enumerate(syllabus.weekly_schedule):
            item_id = self.week_tree.insert(
                "",
                "end",
                values=(
                    week.week_number,
                    week.period,
                    week.topic,
                    ", ".join(str(co) for co in week.aligned_co),
                ),
                tags=("odd" if index % 2 else "even",),
            )
            self._week_lookup[item_id] = week.model_dump()

    def _show_week_detail(self, _event: tk.Event) -> None:
        selection = self.week_tree.selection()
        if not selection:
            return
        week = self._week_lookup.get(selection[0])
        if not week:
            return

        llo_lines = "\n".join(f"  [{llo['category']}] {llo['outcome_text']}" for llo in week.get("llos", []))
        detail = (
            f"Week {week['week_number']} — {week['period']}\n"
            f"Topic: {week['topic']}\n\n"
            f"Lesson Learning Outcomes:\n{llo_lines or '  (none listed)'}\n\n"
            f"Teaching & Learning Activity:\n  {week['teaching_learning_activity']}\n\n"
            f"Assessment Tool:\n  {week['assessment_tool']}\n\n"
            f"Evidence:\n  {week['evidence']}\n\n"
            f"Aligned Course Outcomes: {', '.join(str(c) for c in week['aligned_co'])}"
        )
        messagebox.showinfo(f"Week {week['week_number']} details", detail)

    @staticmethod
    def _write_json(path: str, content: str) -> None:
        if not path:
            raise ValueError("An output JSON path is required.")
        output = Path(path)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(content, encoding="utf-8")


if __name__ == "__main__":
    app = OBEGeneratorApp()
    app.mainloop()
