"""
obe_json_generator.py
CLI Entrypoint for Lab Activity 1.1: Local LLM JSON Engine for OBE Components.
"""

import sys
from lab1_1_generator import main

if __name__ == "__main__":
    main()
