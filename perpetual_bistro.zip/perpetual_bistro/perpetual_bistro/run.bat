@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0ai_virtual_waiter"
call run.bat %*
