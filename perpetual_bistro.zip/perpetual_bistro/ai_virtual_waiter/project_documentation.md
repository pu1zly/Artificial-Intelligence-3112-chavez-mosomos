# Perpetual Bistro - AI Virtual Waiter
## Final Project Technical Documentation & Architecture Specification
**Institution:** University of Perpetual Help System DALTA (UPHSD)  
**Course:** Artificial Intelligence - Lab (Lesson 7)  
**Instructor:** Prof. Rob Malitao  
**System Execution:** 100% Local (Zero Cloud Dependencies)  
**Core Tech Stack:** Python 3.10+, Local Ollama (Qwen 2.5), SQLite 3, STT/TTS Speech Modules, Flask (HTML/Tailwind CSS) & CustomTkinter  

---

## 1. Executive Summary & Business Scenario

Perpetual Bistro, the campus dining facility at UPHSD, requires a modern table-side digital waiter to streamline customer ordering, dietary checks, and kitchen inventory updates. To ensure high privacy, offline resiliency during campus network outages, and zero operational API costs, the system is designed to run entirely locally without cloud dependencies.

The AI Virtual Waiter serves as an interactive, voice-enabled, state-aware café assistant. Customers interact through typed or spoken language:
- Inquiring about menu items, prices, and listed allergens.
- Requesting café items and customizations ("2 Café Lattes, extra hot").
- Updating existing order quantities in natural language ("add one more espresso", "take off two espressos"), with inventory checks and clarification for customized lines.
- Meal combo selection and substitutions when combo entries are configured; the shipped catalog currently has no combos.
- Active order tab monitoring and human-in-the-loop manual adjustments (+, -, delete).
- Real-time inventory reservation and atomic stock subtraction in SQLite.
- Strict Finite State Machine (FSM) dialogue progression (`GREETING` &rarr; `ORDERING` &rarr; `REVIEW` &rarr; `CONFIRMED`).
- Generation of an itemized receipt upon checkout with locked post-confirmation immutability.

---

## 2. System Architecture & Conversation Flow

The system employs a multi-tiered architecture that strictly separates audio I/O, user interface, dialogue state control, LLM reasoning, and database transactions:

```mermaid
flowchart TD
    subgraph IO_Layer ["VOICE & TEXT INTERFACE (I/O Layer)"]
        MIC["Speech-to-Text (STT) Microphone<br/>(Local faster-whisper)"]
        SPEAKER["Text-to-Speech (TTS) Speaker<br/>(pyttsx3: 175 wpm, Vol 0.9)"]
        UI_WEB["Web Tablet Ordering Interface<br/>(Flask + Tailwind CSS + REST API)"]
        UI_GUI["Desktop Kiosk GUI<br/>(CustomTkinter / Tkinter)"]
    end

    subgraph Core_Engine ["CORE VIRTUAL WAITER AGENT ENGINE"]
        FSM["FSM State Controller (fsm_controller.py)<br/>[GREETING &rarr; ORDERING &rarr; REVIEW &rarr; CONFIRMED]"]
        LLM["Local Ollama Engine<br/>(configured Qwen model)"]
    end

    subgraph Data_Layer ["SQLITE PERSISTENCE LAYER (restaurant.db)"]
        DB_TOOLS["SQLite CRUD Wrapper & Guardrails (db_tools.py)"]
        T_MENU["menu_items<br/>(Stock & Allergens)"]
        T_SESS["table_sessions<br/>(Open / Confirmed / Cancelled)"]
        T_CART["order_line_items / cart_items<br/>(Active Reservations)"]
        T_COMBO["combo_components & choices"]
    end

    MIC -->|Spoken Audio| FSM
    UI_WEB <-->|HTTP / REST JSON| FSM
    UI_GUI <-->|Event Dispatch| FSM
    FSM -->|Response Text| SPEAKER
    FSM <-->|Structured Tool Calls| LLM
    FSM -->|Atomic Mutating Queries| DB_TOOLS
    DB_TOOLS <--> T_MENU
    DB_TOOLS <--> T_SESS
    DB_TOOLS <--> T_CART
    DB_TOOLS <--> T_COMBO
```

---

## 3. Finite State Machine (FSM) State Management & Guardrails

The ordering workflow enforces a deterministic Finite State Machine to eliminate state skipping, illegal shortcuts, and invalid cart mutations:

```mermaid
stateDiagram-v2
    [*] --> ORDERING: Launch Application (create table-free order session)

    state ORDERING {
        [*] --> TakingOrder
        TakingOrder --> TakingOrder: Add Item (add_item_to_order_tool)
        TakingOrder --> TakingOrder: Out-of-Stock Guard Triggered (Offers Alternatives)
        TakingOrder --> TakingOrder: Optional combo upgrade (if configured)
        TakingOrder --> TakingOrder: Manual HITL Adjust (+ / - / Delete)
        TakingOrder --> TakingOrder: Off-Domain Query Blocked (Redirect to Menu)
    }

    ORDERING --> REVIEW: User signals completion ("That's all", "Review tab")
    
    state REVIEW {
        [*] --> PresentItemizedSummary
        PresentItemizedSummary --> ORDERING: Edit Request ("Add more fries", "Change quantity")
    }

    REVIEW --> CONFIRMED: Customer Confirms ("Yes, confirm it")
    
    state CONFIRMED {
        [*] --> LockCartModifications
        LockCartModifications --> GenerateItemizedReceipt
        LockCartModifications --> LockCartModifications: Reject Edits / Cancellations
    }

    ORDERING --> ORDERING: Cancel Order (Confirmed; start fresh order)
    REVIEW --> ORDERING: Cancel Order (Confirmed; start fresh order)
    CONFIRMED --> ORDERING: "New Order / Reset" Triggered
```

### State Definitions & Enforced Transition Rules:
1. **`ORDERING`**:
   - Starts an open order session in SQLite without requiring a table number.
   - Presents the order prompt immediately and answers menu or allergen queries.
   - Parses customer natural language into structured tool calls (`add_item_to_order_tool`, `upgrade_to_combo`, `remove_item_from_order`).
   - Deterministically handles common add/remove quantity phrases against the active cart before falling back to the language model.
   - Checks inventory constraints before committing additions.
   - Transitions to `REVIEW` when customer indicates completion ("I'm done", "That's all", "Show bill").
2. **`REVIEW`**:
   - Formats and presents the itemized cart, line totals, 10% service charge, and grand total PHP for verification.
   - **Guardrail**: Any cart modification during `REVIEW` automatically transitions back to `ORDERING`.
3. **`CONFIRMED`**:
   - Transactionally re-verifies stock, atomically deducts inventory from `menu_items`, and updates session status to `confirmed`.
   - Generates the official itemized receipt.
   - **Guardrail**: Cart modifications and cancellations are permanently locked.

---

## 4. Programmatic Inventory Guardrails & Edge Cases

The system implements strict programmatic safeguards in Python rather than relying solely on LLM prompt obedience:

### Edge Case 1: Out-of-Stock Items
- **Constraint**: A menu item may have zero stock or fewer portions available than requested.
- **Implementation**: Inside `db_tools.py:add_item_to_order_tool()`, available inventory is computed by subtracting open session reservations from `stock_qty`.
- **Behavior**: Requests exceeding stock are blocked and in-stock alternatives from the same category are returned. The shipped café catalog includes pastries such as Blueberry Muffin (18 portions), not the older restaurant menu examples.

### Edge Case 2: Insufficient Stock
- **Constraint**: Requests cannot exceed remaining stock after reservations.
- **Behavior**: The order returns the available quantity and alternatives, preventing inventory over-allocation.

### Edge Case 3: Post-Confirmation Immutability (CONFIRMED State)
- **Constraint**: Once an order reaches `CONFIRMED`, food preparation begins in the kitchen.
- **Implementation**: Both the FSM Controller (`fsm_controller.py`) and SQLite CRUD functions (`db_tools.py`) reject addition, quantity editing, line deletion, and order cancellation with:
  `"Cannot modify order: order is already confirmed and sent to the kitchen."`

### Edge Case 4: Out-of-Domain & Off-Topic Query Rejection
- **Constraint**: Virtual Waiter must not act as a general-purpose chatbot.
- **Implementation**: Off-topic topics (weather, politics, sports, general programming) are caught and rejected:
  `"I am the AI Virtual Waiter for Perpetual Bistro and can only assist with your food order and our menu. What would you like to order?"`

### Edge Case 5: Non-Yes/No Interruption During Cancellation
- **Constraint**: Asking a menu question during a pending order cancellation must not cancel the tab.
- **Implementation**: Unrelated queries abort the cancellation prompt, answer the catalog question, and preserve all active cart items safely.

---

## 5. Database Schema & Data Dictionary

The relational database is stored in SQLite (`restaurant.db`) with foreign key enforcement enabled (`PRAGMA foreign_keys = ON`).

### Table: `menu_items`
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | INTEGER | PRIMARY KEY | Unique menu item ID |
| `name` | TEXT | UNIQUE, NOT NULL | Item name (e.g., 'Café Latte') |
| `category` | TEXT | NOT NULL | Shipped categories: Coffee, Frappes, Milkshakes, Tea & Refreshers, Pastries. Other categories are supported when configured. |
| `price` | REAL | NOT NULL | Price in Philippine Peso (PHP) |
| `stock_qty` | INTEGER | NOT NULL, DEFAULT 0 | Real-time kitchen inventory count |
| `allergens` | TEXT | NOT NULL, DEFAULT '' | Comma-separated allergen tags (dairy, egg, gluten, etc.) |
| `dietary_tags`| TEXT | NOT NULL, DEFAULT '' | Tags such as 'vegetarian', 'vegan' |

### Table: `table_sessions`
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `session_id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique table session ID |
| `table_no` | INTEGER | NULL | Optional dining table number |
| `status` | TEXT | NOT NULL, DEFAULT 'open' | Status: `open`, `confirmed`, `cancelled` |

### Table: `order_line_items` (and View: `cart_items`)
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `line_id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique cart line item ID |
| `session_id` | INTEGER | NOT NULL, REFERENCES table_sessions | Foreign key to active session |
| `item_id` | INTEGER | NOT NULL, REFERENCES menu_items | Foreign key to menu item |
| `quantity` | INTEGER | NOT NULL, CHECK (quantity > 0) | Quantity ordered |
| `special_instructions`| TEXT | NOT NULL, DEFAULT '' | Customizations ("no onions, extra crispy") |

### Table: `combo_components`
Defines bundle components for optional meal combos. The current seed catalog does not include combo records; combo choices appear only when configured in the database.

---

## 6. Decoupled Speech I/O Pipeline (`speech_engine.py`)

The speech subsystem is fully abstracted and decoupled from the UI and state engine:

```
[Microphone Audio] ──> [faster-whisper medium.en (local)] ──> [String Text]
                                                                  │
                                                                  ▼
                                                      [fsm_controller.WaiterAgent]
                                                                  │
                                                                  ▼
[Speaker Output]   <── [pyttsx3 Audio Vocalizer]   <── [Response String]
```

- **Speech-to-Text (STT)**:
  - The dashboard records press-and-hold microphone input with browser echo cancellation, noise suppression, and automatic gain control.
  - Recorded audio is transcribed locally by the open-source `faster-whisper` `medium.en` model with CPU `int8` inference and voice activity detection.
  - Audio is converted to mono 16 kHz, filtered to reduce low-frequency rumble, and gently normalized with a gain cap to help with quiet microphones while avoiding clipping.
  - The Windows `run.bat` launcher checks that `faster-whisper` and the configured model are already installed/downloaded. It reports missing components and does not install or download them automatically.
  - The terminal/voice assistant uses `SpeechRecognition` for microphone capture and the same local Whisper model for transcription.
- **Text-to-Speech (TTS)**:
  - Vocalizes responses via `pyttsx3` with speed tuned to 175 wpm for natural pacing and volume set to 0.9.
  - Decoupled thread-safe playback ensures UI responsiveness.

---

## 7. User Interface (UI/UX) Dashboard

The system provides a real-time ordering screen adhering to the digital tablet concept:
1. **Live Chat & Voice Transcript**:
   - Real-time conversation bubbles distinguishing customer messages from Virtual Waiter replies.
   - Push-to-Talk microphone button with pulse animations for voice recording.
   - Quick-action suggestion chips for common orders and queries.
2. **Active Cart Table**:
   - Detailed breakdown displaying Item Name, Customizations/Combo Choices, Unit Price, and Line Total.
   - **Manual Human-in-the-Loop Override Buttons**: Direct `+` and `-` quantity adjustment buttons, and `Delete` button on each cart line.
3. **Financial Summary**:
   - Subtotal, Service Fee (10%), and Grand Total (PHP).
4. **Interactive Controls**:
   - "Review Order" & "Confirm & Pay" buttons.
   - Menu Explorer Modal with category navigation and allergen filters.
   - Modal itemized receipt upon checkout.
   - The paid receipt includes an optional **Verify post-confirmation lock** action for the live defense. It attempts add, quantity edit, delete, and cancel against the just-confirmed receipt, reports that the operations were blocked, and leaves the automatically reset next-customer order untouched.

---

## 8. Verification and Launch

Install Python dependencies:

```bash
pip install -r requirements.txt
```

On Windows, run `run.bat` to check Ollama and automatically select the newest-generation, largest installed general-purpose Qwen chat model. The same selection logic is used by the waiter agent. Set `OLLAMA_MODEL` to require one specific installed model; the launcher will report an error rather than downloading it if it is missing. The launcher also checks that faster-whisper and its configured model are already available, and never downloads or installs them automatically. Prepare the machine while online first: install dependencies with `pip install -r requirements.txt`, pull a Qwen model such as `ollama pull qwen3:8b`, and initialize the faster-whisper `medium.en` model once with `python -c "from faster_whisper import WhisperModel; WhisperModel('medium.en', device='cpu', compute_type='int8')"` while online. Set `WHISPER_MODEL` to use a different cached model. Ollama must be running; its app is detected through the local API.

Run the automated tests (they use temporary databases):

```bash
python -m unittest discover -s tests -v
```

Optionally reset the live database catalog. This deletes existing local order/database data:

```bash
python init_db.py --reset
```

For direct Python launch, ensure Ollama and the configured local model are ready first:

```bash
python app.py
```

The web tablet opens at `http://127.0.0.1:5000`. Customers can browse the seeded coffee, frappe, milkshake, tea/refreshers, and pastry categories; add items to the virtual receipt; review and confirm the order; and make no further changes after confirmation. The UI displays meal-combo options only when combo records are configured in the database.
