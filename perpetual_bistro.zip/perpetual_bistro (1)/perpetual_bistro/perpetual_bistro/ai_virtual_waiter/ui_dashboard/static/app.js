// Perpetual Bistro AI Virtual Waiter - Tablet UI Controller
document.addEventListener("DOMContentLoaded", () => {
    // Elements
    const chatTranscript = document.getElementById("chat-transcript");
    const chatForm = document.getElementById("chat-form");
    const chatInput = document.getElementById("chat-input");
    const btnMic = document.getElementById("btn-mic");
    const ttsToggle = document.getElementById("tts-toggle");
    const fsmStatusBadge = document.getElementById("fsm-status-badge");
    const tabSubtitle = document.getElementById("tab-subtitle");
    const cartTableBody = document.getElementById("cart-table-body");
    const emptyCartRow = document.getElementById("empty-cart-row");
    const cartSubtotal = document.getElementById("cart-subtotal");
    const cartServiceFee = document.getElementById("cart-service-fee");
    const cartGrandTotal = document.getElementById("cart-grand-total");
    const btnReviewOrder = document.getElementById("btn-review-order");
    const btnConfirmOrder = document.getElementById("btn-confirm-order");
    const btnCancelOrder = document.getElementById("btn-cancel-order");
    const menuCardsContainer = document.getElementById("menu-cards-container");
    const dietaryFilterSelect = document.getElementById("dietary-filter-select");
    const receiptModal = document.getElementById("receipt-modal");
    const btnCloseReceipt = document.getElementById("btn-close-receipt");

    // Stepper Elements
    const stepGreeting = document.getElementById("step-greeting");
    const stepOrdering = document.getElementById("step-ordering");
    const stepReview = document.getElementById("step-review");
    const stepConfirmed = document.getElementById("step-confirmed");

    // Switcher & Menu Status Elements
    const tabBtnMenu = document.getElementById("tab-btn-menu");
    const tabBtnWaiter = document.getElementById("tab-btn-waiter");
    const viewMenu = document.getElementById("view-menu");
    const viewWaiter = document.getElementById("view-waiter");
    const waiterBadge = document.getElementById("waiter-badge");
    const menuOrderStatus = document.getElementById("menu-order-status");
    const menuStatusText = document.getElementById("menu-status-text");
    const menuStatusIcon = document.getElementById("menu-status-icon");
    const btnStatusViewChat = document.getElementById("btn-status-view-chat");
    const btnTechnicianPanel = document.getElementById("btn-technician-panel");
    const technicianModal = document.getElementById("technician-modal");
    const btnCloseTechnician = document.getElementById("btn-close-technician");
    const btnTechHealth = document.getElementById("btn-tech-health");
    const btnTechRedetectAi = document.getElementById("btn-tech-redetect-ai");
    const btnTechRefresh = document.getElementById("btn-tech-refresh");
    const btnTechStopAudio = document.getElementById("btn-tech-stop-audio");
    const btnTechResetSession = document.getElementById("btn-tech-reset-session");
    const technicianStatus = document.getElementById("technician-status");

    let pushToTalkActive = false;
    let isRecording = false;
    let isTranscribingAudio = false;
    let mediaRecorder = null;
    let recordingStream = null;
    let audioChunks = [];
    let keyboardPushToTalkKey = null;
    const defaultChatPlaceholder = chatInput ? chatInput.placeholder : "";
    let activeTab = "menu"; // "menu" or "waiter"
    let currentCategory = "all";
    let currentDiet = "all";

    // Tab Switcher Controller
    function switchTab(tab) {
        activeTab = tab;
        if (tab === "menu") {
            if (viewMenu) viewMenu.classList.remove("hidden");
            if (viewWaiter) viewWaiter.classList.add("hidden");
            if (tabBtnMenu) {
                tabBtnMenu.className = "px-4 py-2 font-bold text-xs rounded-t-lg transition flex items-center gap-2 bg-[#fbf7ef] text-[#4a0020] shadow";
            }
            if (tabBtnWaiter) {
                tabBtnWaiter.className = "px-4 py-2 font-semibold text-xs rounded-t-lg transition flex items-center gap-2 text-neutral-300 hover:text-white hover:bg-[#5f0029]/60";
            }
        } else {
            if (viewMenu) viewMenu.classList.add("hidden");
            if (viewWaiter) viewWaiter.classList.remove("hidden");
            if (tabBtnWaiter) {
                tabBtnWaiter.className = "px-4 py-2 font-bold text-xs rounded-t-lg transition flex items-center gap-2 bg-[#4a0020] text-[#fccc0c] shadow border-t-2 border-[#fccc0c]";
            }
            if (tabBtnMenu) {
                tabBtnMenu.className = "px-4 py-2 font-semibold text-xs rounded-t-lg transition flex items-center gap-2 text-neutral-300 hover:text-white hover:bg-[#5f0029]/60";
            }
            if (waiterBadge) waiterBadge.classList.add("hidden");
            if (chatTranscript) chatTranscript.scrollTop = chatTranscript.scrollHeight;
        }
    }

    if (tabBtnMenu) tabBtnMenu.addEventListener("click", () => switchTab("menu"));
    if (tabBtnWaiter) tabBtnWaiter.addEventListener("click", () => switchTab("waiter"));
    if (btnStatusViewChat) btnStatusViewChat.addEventListener("click", () => switchTab("waiter"));

    function stopMic() {
        isRecording = false;
        if (btnMic) btnMic.classList.remove("mic-recording");
    }

    // Instantly skip & silence any ongoing speech
    function stopSpeech() {
        if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel();
        }
        fetch("/api/voice_stop", { method: "POST" }).catch(() => {});
    }

    function releaseRecordingStream() {
        if (recordingStream) {
            recordingStream.getTracks().forEach(track => track.stop());
            recordingStream = null;
        }
    }

    function showSpeechInputError(message) {
        if (!chatInput) return;
        chatInput.placeholder = message;
        window.setTimeout(() => {
            if (chatInput && chatInput.placeholder === message) {
                chatInput.placeholder = defaultChatPlaceholder;
            }
        }, 6000);
    }

    async function transcribeRecordedAudio(blob) {
        isTranscribingAudio = true;
        if (btnMic) btnMic.disabled = true;
        if (chatInput) chatInput.placeholder = "Transcribing locally with Whisper...";
        try {
            const formData = new FormData();
            const extension = blob.type.includes("ogg") ? "ogg" :
                blob.type.includes("mp4") ? "mp4" : "webm";
            formData.append("audio", blob, `recording.${extension}`);
            const response = await fetch("/api/voice_listen", {
                method: "POST",
                body: formData,
            });
            const data = await response.json().catch(() => ({}));
            if (!response.ok || !data.ok) {
                throw new Error(data.error || "Local speech recognition failed. Please try again.");
            }
            if (chatInput) chatInput.value = data.text;
            await submitMessage(data.text);
        } catch (error) {
            console.error("Local Whisper transcription failed:", error);
            showSpeechInputError(error.message);
        } finally {
            isTranscribingAudio = false;
            if (btnMic) btnMic.disabled = !navigator.mediaDevices?.getUserMedia || !window.MediaRecorder;
            if (chatInput && chatInput.placeholder === "Transcribing locally with Whisper...") {
                chatInput.placeholder = defaultChatPlaceholder;
            }
        }
    }

    async function startPushToTalk() {
        if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder ||
            pushToTalkActive || isRecording || isTranscribingAudio) return;
        pushToTalkActive = true;
        audioChunks = [];
        if (chatInput) chatInput.placeholder = "Listening... release the mic to transcribe and send.";
        stopSpeech();
        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                audio: {
                    channelCount: { ideal: 1 },
                    sampleRate: { ideal: 16000 },
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true,
                },
            });
            if (!pushToTalkActive) {
                stream.getTracks().forEach(track => track.stop());
                return;
            }
            recordingStream = stream;
            const mimeType = [
                "audio/webm;codecs=opus",
                "audio/webm",
                "audio/mp4",
                "audio/ogg;codecs=opus",
            ].find(type => window.MediaRecorder.isTypeSupported(type));
            mediaRecorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
            mediaRecorder.addEventListener("dataavailable", event => {
                if (event.data.size > 0) audioChunks.push(event.data);
            });
            mediaRecorder.addEventListener("stop", () => {
                const blob = new Blob(audioChunks, { type: mediaRecorder.mimeType });
                audioChunks = [];
                mediaRecorder = null;
                releaseRecordingStream();
                stopMic();
                if (blob.size > 0) {
                    transcribeRecordedAudio(blob);
                } else {
                    showSpeechInputError("No audio was captured. Hold the mic and speak, then release.");
                }
            }, { once: true });
            mediaRecorder.start(250);
            isRecording = true;
            if (btnMic) btnMic.classList.add("mic-recording");
        } catch (error) {
            pushToTalkActive = false;
            releaseRecordingStream();
            const message = error.name === "NotAllowedError"
                ? "Microphone access is blocked. Allow microphone access and try again."
                : error.name === "NotFoundError"
                    ? "No microphone was found. Connect a microphone and try again."
                    : `Could not start microphone recording: ${error.message}`;
            showSpeechInputError(message);
        }
    }

    function stopPushToTalk() {
        if (!pushToTalkActive) return;
        pushToTalkActive = false;
        if (mediaRecorder && mediaRecorder.state === "recording") {
            mediaRecorder.stop();
            if (chatInput) chatInput.placeholder = "Preparing recording...";
        } else {
            releaseRecordingStream();
            stopMic();
            if (chatInput && chatInput.placeholder.startsWith("Listening...")) {
                chatInput.placeholder = defaultChatPlaceholder;
            }
        }
    }

    window.addEventListener("blur", () => {
        keyboardPushToTalkKey = null;
        stopPushToTalk();
    });
    document.addEventListener("visibilitychange", () => {
        if (document.hidden) stopPushToTalk();
    });

    // Push-to-talk: hold the microphone button to record, release to send.
    if (btnMic) {
        const recordingSupported = Boolean(navigator.mediaDevices?.getUserMedia && window.MediaRecorder);
        btnMic.title = recordingSupported
            ? "Press and hold to talk; release to transcribe locally and send"
            : "Microphone recording is unavailable in this browser. Type your message instead.";
        btnMic.setAttribute("aria-label", btnMic.title);
        btnMic.disabled = !recordingSupported;
        btnMic.classList.toggle("opacity-40", !recordingSupported);
        btnMic.classList.toggle("cursor-not-allowed", !recordingSupported);

        btnMic.addEventListener("pointerdown", (event) => {
            if (!recordingSupported) return;
            event.preventDefault();
            btnMic.setPointerCapture(event.pointerId);
            startPushToTalk();
        });
        btnMic.addEventListener("pointerup", stopPushToTalk);
        btnMic.addEventListener("pointercancel", stopPushToTalk);
        btnMic.addEventListener("lostpointercapture", stopPushToTalk);
        btnMic.addEventListener("keydown", (event) => {
            if ((event.key === " " || event.key === "Enter") && !event.repeat) {
                event.preventDefault();
                keyboardPushToTalkKey = event.key;
                startPushToTalk();
            }
        });
        btnMic.addEventListener("keyup", (event) => {
            if (event.key === keyboardPushToTalkKey) {
                event.preventDefault();
                keyboardPushToTalkKey = null;
                stopPushToTalk();
            }
        });
    }

    // TTS speech vocalization using browser SpeechSynthesis with instant skip
    function speakText(text) {
        if (!ttsToggle || !ttsToggle.checked || !('speechSynthesis' in window) || !text) return;
        
        stopSpeech();

        const clean = text
            .replace(/[*#_`~]/g, '')
            .replace(/PHP\s*/gi, 'pesos ')
            .replace(/\s+/g, ' ')
            .trim();

        if (!clean) return;

        const utterance = new SpeechSynthesisUtterance(clean);
        utterance.rate = 1.15;
        utterance.pitch = 1.0;

        if (window.speechSynthesis.paused) {
            window.speechSynthesis.resume();
        }

        window.speechSynthesis.speak(utterance);
    }

    // Fetch and sync active state
    async function syncState() {
        try {
            const res = await fetch("/api/state");
            const data = await res.json();
            renderState(data);
        } catch (e) {
            console.error("Failed to sync state:", e);
        }
    }

    function normalizeFsmState(state) {
        return String(state || "STATE_GREETING")
            .replace("STATE_", "")
            .replace("TAKING_ORDER", "ORDERING");
    }

    function setConfirmButtonState(state) {
        if (!btnConfirmOrder) return;
        const canConfirm = normalizeFsmState(state) === "REVIEW";
        btnConfirmOrder.disabled = !canConfirm;
        btnConfirmOrder.setAttribute("aria-disabled", String(!canConfirm));
        btnConfirmOrder.classList.toggle("opacity-40", !canConfirm);
        btnConfirmOrder.classList.toggle("cursor-not-allowed", !canConfirm);
        btnConfirmOrder.title = canConfirm
            ? "Choose a payment method"
            : "Click Review Order before confirming and paying";
    }

    // Render Full System State
    function renderState(data) {
        const { state, cart, transcript, receipt } = data;

        if (tabSubtitle) {
            const itemCount = (cart && cart.items) ? cart.items.length : 0;
            tabSubtitle.textContent = `Order • ${itemCount} items`;
        }

        // Update FSM Status Badge
        const normalizedState = normalizeFsmState(state);
        if (fsmStatusBadge) {
            fsmStatusBadge.textContent = normalizedState;
        }

        // Payment may only begin after the customer has entered the review phase.
        // This is also enforced by the API, but disabling the control makes the
        // required next step clear in the tablet interface.
        setConfirmButtonState(normalizedState);

        // Update Stepper
        if (stepGreeting && stepOrdering && stepReview && stepConfirmed) {
            [stepGreeting, stepOrdering, stepReview, stepConfirmed].forEach(el => {
                el.className = "px-2.5 py-0.5 rounded-full transition-all text-neutral-400";
            });

            if (normalizedState === "GREETING") {
                stepGreeting.className = "px-2.5 py-0.5 rounded-full transition-all fsm-step-active";
            } else if (normalizedState === "ORDERING") {
                stepGreeting.className = "px-2.5 py-0.5 rounded-full transition-all fsm-step-passed";
                stepOrdering.className = "px-2.5 py-0.5 rounded-full transition-all fsm-step-active";
            } else if (normalizedState === "REVIEW") {
                stepGreeting.className = "px-2.5 py-0.5 rounded-full transition-all fsm-step-passed";
                stepOrdering.className = "px-2.5 py-0.5 rounded-full transition-all fsm-step-passed";
                stepReview.className = "px-2.5 py-0.5 rounded-full transition-all fsm-step-active";
            } else if (normalizedState === "CONFIRMED") {
                [stepGreeting, stepOrdering, stepReview].forEach(el => el.className = "px-2.5 py-0.5 rounded-full transition-all fsm-step-passed");
                stepConfirmed.className = "px-2.5 py-0.5 rounded-full transition-all fsm-step-active";
            }
        }

        // Render Cart Table (Virtual Receipt)
        renderCart(cart, normalizedState);

        // Render Transcript
        renderTranscript(transcript);

        // Show receipt if confirmed — handled by payment modal flow; no auto-popup here
        // if (receipt && normalizedState === "CONFIRMED") { showReceipt(receipt); }
    }

    // Render Active Cart Rows & Totals (Virtual Receipt)
    function renderCart(cart, currentState) {
        if (!cartTableBody) return;
        const items = (cart && cart.items) ? cart.items : [];
        cartTableBody.innerHTML = "";

        if (items.length === 0) {
            cartTableBody.appendChild(emptyCartRow);
            if (cartSubtotal) cartSubtotal.textContent = "PHP 0.00";
            if (cartServiceFee) cartServiceFee.textContent = "PHP 0.00";
            if (cartGrandTotal) cartGrandTotal.textContent = "PHP 0.00";
            return;
        }

        const isLocked = currentState === "CONFIRMED";

        items.forEach(item => {
            const tr = document.createElement("tr");
            tr.className = "hover:bg-[#f6eee0] transition";

            const comboDetails = item.side_name ? `<div class="text-[10px] text-neutral-500"><i class="fa-solid fa-angles-right text-[8px]"></i> ${item.side_name}, ${item.drink_name}</div>` : '';
            const instructions = item.instructions ? `<div class="text-[10px] text-amber-800 italic font-mono"><i class="fa-solid fa-note-sticky text-[8px]"></i> ${item.instructions}</div>` : '';

            tr.innerHTML = `
                <td class="py-2.5 pl-1 pr-2">
                    <span class="font-bold text-[#4a0020] text-xs">${item.name}</span>
                    ${comboDetails}
                    ${instructions}
                </td>
                <td class="py-2.5 px-1 text-center whitespace-nowrap">
                    <div class="inline-flex items-center gap-1 bg-[#ede2cb] rounded px-1.5 py-0.5">
                        <button class="cart-btn-dec text-neutral-600 hover:text-rose-700 font-bold px-1 ${isLocked ? 'opacity-40 cursor-not-allowed' : ''}" data-id="${item.line_id}" ${isLocked ? 'disabled' : ''}>-</button>
                        <span class="font-semibold text-xs min-w-[14px]">${item.quantity}</span>
                        <button class="cart-btn-inc text-neutral-600 hover:text-emerald-700 font-bold px-1 ${isLocked ? 'opacity-40 cursor-not-allowed' : ''}" data-id="${item.line_id}" ${isLocked ? 'disabled' : ''}>+</button>
                    </div>
                </td>
                <td class="py-2.5 px-2 text-right font-mono font-semibold text-neutral-700 whitespace-nowrap text-xs">
                    PHP ${Number(item.line_total).toFixed(2)}
                </td>
                <td class="py-2.5 pr-1 text-center whitespace-nowrap">
                    <button class="cart-btn-del bg-rose-100 hover:bg-rose-600 hover:text-white text-rose-700 font-extrabold w-6 h-6 rounded flex items-center justify-center transition text-xs shadow-sm mx-auto ${isLocked ? 'opacity-40 cursor-not-allowed' : ''}" data-id="${item.line_id}" data-name="${item.name}" title="Remove ${item.name} from receipt" ${isLocked ? 'disabled' : ''}>
                        ✕
                    </button>
                </td>
            `;
            cartTableBody.appendChild(tr);
        });

        // Totals
        if (cartSubtotal) cartSubtotal.textContent = `PHP ${Number(cart.subtotal || 0).toFixed(2)}`;
        if (cartServiceFee) cartServiceFee.textContent = `PHP ${Number(cart.service_fee || 0).toFixed(2)}`;
        if (cartGrandTotal) cartGrandTotal.textContent = `PHP ${Number(cart.total || 0).toFixed(2)}`;

        // Attach Manual Override Listeners
        document.querySelectorAll(".cart-btn-inc").forEach(btn => {
            btn.addEventListener("click", () => adjustCart(btn.dataset.id, 1));
        });
        document.querySelectorAll(".cart-btn-dec").forEach(btn => {
            btn.addEventListener("click", () => adjustCart(btn.dataset.id, -1));
        });
        document.querySelectorAll(".cart-btn-del").forEach(btn => {
            btn.addEventListener("click", () => deleteCart(btn.dataset.id, btn.dataset.name));
        });
    }

    // Render Chat Transcript
    function renderTranscript(messages) {
        if (!chatTranscript) return;
        chatTranscript.innerHTML = "";

        const displayMessages = (messages && messages.length > 0) ? messages : [
            {
                role: "waiter",
                text: "Welcome to Perpetual Bistro! What can I get started for you today?"
            }
        ];

        displayMessages.forEach(msg => {
            const isUser = msg.role === "user";
            const div = document.createElement("div");
            div.className = `flex items-start gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`;

            if (!isUser) {
                div.innerHTML = `
                    <div class="w-8 h-8 rounded-full bg-[#fccc0c] text-[#4a0020] flex items-center justify-center text-sm font-bold flex-shrink-0 shadow">
                        <i class="fa-solid fa-robot"></i>
                    </div>
                    <div class="chat-bubble-waiter p-3 rounded-2xl max-w-[85%] text-sm shadow whitespace-pre-line">
                        <p class="font-semibold text-xs text-[#e5c785] mb-1">Perpetual Bistro Waiter</p>
                        <p>${escapeHtml(msg.text)}</p>
                    </div>
                `;
            } else {
                div.innerHTML = `
                    <div class="chat-bubble-user p-3 rounded-2xl max-w-[85%] text-sm font-medium shadow whitespace-pre-line">
                        <p class="font-semibold text-xs text-[#5f0029] mb-1 text-right">You (Customer)</p>
                        <p>${escapeHtml(msg.text)}</p>
                    </div>
                    <div class="w-8 h-8 rounded-full bg-neutral-700 text-[#fbf7ef] flex items-center justify-center text-sm font-bold flex-shrink-0 shadow">
                        <i class="fa-solid fa-user"></i>
                    </div>
                `;
            }
            chatTranscript.appendChild(div);
        });

        chatTranscript.scrollTop = chatTranscript.scrollHeight;
    }

    function escapeHtml(text) {
        const div = document.createElement("div");
        div.textContent = text;
        return div.innerHTML;
    }

    // Submit Message via Chat or Menu Action
    async function submitMessage(text, isMenuOrder = false, itemName = "") {
        if (!text || !text.trim()) return;
        
        stopSpeech();
        if (chatInput) chatInput.value = "";

        // Status banner when picking an item from the menu
        if (isMenuOrder && menuOrderStatus) {
            menuOrderStatus.classList.remove("hidden");
            if (menuStatusIcon) menuStatusIcon.className = "fa-solid fa-spinner fa-spin text-amber-600";
            if (menuStatusText) menuStatusText.textContent = `Reading your order... Adding 1 ${itemName} to your virtual receipt.`;
        }

        // Temporary optimistic display in transcript
        if (chatTranscript) {
            const tempDiv = document.createElement("div");
            tempDiv.className = "flex items-start gap-2.5 justify-end";
            tempDiv.innerHTML = `
                <div class="chat-bubble-user p-3 rounded-2xl max-w-[85%] text-sm font-medium shadow">
                    <p class="font-semibold text-xs text-[#5f0029] mb-1 text-right">You (Customer)</p>
                    <p>${escapeHtml(text)}</p>
                </div>
                <div class="w-8 h-8 rounded-full bg-neutral-700 text-[#fbf7ef] flex items-center justify-center text-sm font-bold flex-shrink-0">
                    <i class="fa-solid fa-user"></i>
                </div>
            `;
            chatTranscript.appendChild(tempDiv);
            chatTranscript.scrollTop = chatTranscript.scrollHeight;
        }

        try {
            const res = await fetch("/api/chat", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ text })
            });
            const data = await res.json();
            renderState(data);

            if (isMenuOrder && menuOrderStatus) {
                if (menuStatusIcon) menuStatusIcon.className = "fa-solid fa-circle-check text-emerald-600";
                if (menuStatusText) menuStatusText.textContent = `I've added ${itemName} to your order, is that all?`;
            }

            if (activeTab === "menu" && waiterBadge) {
                waiterBadge.classList.remove("hidden");
            }

            if (data.response) {
                speakText(data.response);
            }
        } catch (e) {
            console.error("Chat error:", e);
            if (isMenuOrder && menuOrderStatus) {
                if (menuStatusIcon) menuStatusIcon.className = "fa-solid fa-triangle-exclamation text-rose-600";
                if (menuStatusText) menuStatusText.textContent = `Could not add ${itemName}. Please try again.`;
            }
        }
    }

    if (chatInput) {
        chatInput.addEventListener("input", () => {
            stopSpeech();
        });
    }

    if (chatForm) {
        chatForm.addEventListener("submit", (e) => {
            e.preventDefault();
            if (chatInput) submitMessage(chatInput.value.trim());
        });
    }

    // Quick Action Chips
    document.querySelectorAll(".chip-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            stopSpeech();
            submitMessage(btn.dataset.msg);
        });
    });

    // Cart Adjustments
    async function adjustCart(lineId, delta) {
        stopSpeech();
        try {
            const res = await fetch("/api/cart/adjust", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ line_id: lineId, delta })
            });
            const data = await res.json();
            renderState(data);
            loadMenuCards(currentCategory, currentDiet);
        } catch (e) {
            console.error("Adjust error:", e);
        }
    }

    // Delete item via prominent "X" button
    async function deleteCart(lineId, itemName = "") {
        stopSpeech();
        try {
            const res = await fetch("/api/cart/delete", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ line_id: lineId })
            });
            const data = await res.json();
            renderState(data);
            loadMenuCards(currentCategory, currentDiet);

            const msg = itemName ? `Removed ${itemName} from your virtual receipt.` : "Item removed from your receipt.";
            if (menuOrderStatus) {
                menuOrderStatus.classList.remove("hidden");
                if (menuStatusIcon) menuStatusIcon.className = "fa-solid fa-trash-can text-rose-600";
                if (menuStatusText) menuStatusText.textContent = msg;
            }

            // Assistant speech confirmation
            speakText(msg);
        } catch (e) {
            console.error("Delete error:", e);
        }
    }

    // Review Button
    if (btnReviewOrder) {
        btnReviewOrder.addEventListener("click", async () => {
            stopSpeech();
            try {
                const res = await fetch("/api/cart/review", { method: "POST" });
                const data = await res.json();
                renderState(data);
                // The review response is the authoritative transition that
                // unlocks checkout, even if the client had an older state.
                setConfirmButtonState(data.state);
                switchTab("waiter");
                if (data.response) speakText(data.response);
            } catch (e) {
                console.error("Review error:", e);
            }
        });
    }

    // Payment flow state
    let pendingReceipt = null;
    let paymentPending = false;
    const paymentModal = document.getElementById("payment-modal");
    const successModal = document.getElementById("success-modal");
    const btnPayCash = document.getElementById("btn-pay-cash");
    const btnPayEwallet = document.getElementById("btn-pay-ewallet");
    const btnPaymentCancel = document.getElementById("btn-payment-cancel");
    const successPaymentMethod = document.getElementById("success-payment-method");

    // Confirm Button → ask for a payment method.  The order is committed only
    // after the customer chooses Cash or E-Wallet, so "Go back to review"
    // remains truthful and usable.
    if (btnConfirmOrder) {
        btnConfirmOrder.addEventListener("click", async () => {
            stopSpeech();
            try {
                // Re-read the server state before opening payment. This keeps
                // the popup usable after a review transition without trusting
                // a stale button attribute in the browser.
                const res = await fetch("/api/state");
                const data = await res.json();
                renderState(data);
                if (normalizeFsmState(data.state) !== "REVIEW") return;
                paymentPending = true;
                if (paymentModal) paymentModal.classList.remove("hidden");
            } catch (e) {
                console.error("Unable to open payment options:", e);
            }
        });
    }

    // Payment method selection
    async function resetForNextCustomer() {
        const res = await fetch("/api/reset", { method: "POST" });
        const data = await res.json();
        renderState(data);
        await loadMenuCards("all", "all");
        if (menuOrderStatus) menuOrderStatus.classList.add("hidden");
        switchTab("waiter");
    }

    async function processPayment(method) {
        if (!paymentPending) return;
        if (btnPayCash) btnPayCash.disabled = true;
        if (btnPayEwallet) btnPayEwallet.disabled = true;
        try {
            const res = await fetch("/api/cart/confirm", { method: "POST" });
            const data = await res.json();
            renderState(data);
            if (!data.ok || !data.receipt) {
                paymentPending = false;
                if (paymentModal) paymentModal.classList.add("hidden");
                if (data.response) speakText(data.response);
                return;
            }
            const receipt = data.receipt;
            if (paymentModal) paymentModal.classList.add("hidden");
            // The receipt is preserved for the success screen while the active
            // waiter session is immediately prepared for the next customer.
            await resetForNextCustomer();
            showSuccessModal(receipt, method);
        } catch (e) {
            console.error("Payment reset error:", e);
            // The payment confirmation remains visible even if refreshing the
            // new customer session failed; the user can use New Customer to retry.
            showSuccessModal(receipt, method);
        } finally {
            paymentPending = false;
            if (btnPayCash) btnPayCash.disabled = false;
            if (btnPayEwallet) btnPayEwallet.disabled = false;
        }
    }

    if (btnPayCash) {
        btnPayCash.addEventListener("click", () => processPayment("Cash"));
    }
    if (btnPayEwallet) {
        btnPayEwallet.addEventListener("click", () => processPayment("E-Wallet"));
    }
    if (btnPaymentCancel) {
        btnPaymentCancel.addEventListener("click", () => {
            if (paymentModal) paymentModal.classList.add("hidden");
            paymentPending = false;
            pendingReceipt = null;
        });
    }

    // Cancel Button
    if (btnCancelOrder) {
        btnCancelOrder.addEventListener("click", () => {
            stopSpeech();
            submitMessage("cancel my whole order");
        });
    }

    function renderTechnicianStatus(status) {
        if (!technicianStatus) return;
        const ai = status.ollama || {};
        const database = status.database || {};
        const whisper = status.whisper || {};
        const aiState = ai.connected ? `Online - ${ai.model}` : `Offline - ${ai.error || "Ollama is unavailable"}`;
        const dbState = database.connected ? "Online" : `Offline - ${database.error || "Database unavailable"}`;
        const whisperState = whisper.available
            ? `Ready - ${whisper.model} v${whisper.version || "unknown"} (${whisper.device || "local"})${whisper.loaded ? " · model loaded" : " · loads on first use"}`
            : `Unavailable - ${whisper.error || "faster-whisper is not installed"}`;
        technicianStatus.innerHTML = `<div class="font-bold ${status.ok ? "text-emerald-700" : "text-rose-700"}"><i class="fa-solid ${status.ok ? "fa-circle-check" : "fa-triangle-exclamation"} mr-1"></i>${status.ok ? "System ready" : "Attention needed"}</div><div class="mt-1">Waiter AI: ${escapeHtml(aiState)}</div><div>Speech AI (faster-whisper): ${escapeHtml(whisperState)}</div><div>Database: ${escapeHtml(dbState)}</div>`;
        const modelIndicator = document.getElementById("model-indicator");
        if (ai.connected && modelIndicator) {
            modelIndicator.innerHTML = `<i class="fa-solid fa-microchip"></i> ${escapeHtml(ai.model)}`;
        }
    }

    async function checkTechnicianHealth(redetect = false) {
        if (technicianStatus) technicianStatus.textContent = redetect ? "Redetecting local AI..." : "Checking local services...";
        const url = redetect ? "/api/technician/redetect-ai" : "/api/technician/health";
        const res = await fetch(url, { method: redetect ? "POST" : "GET" });
        const data = await res.json();
        renderTechnicianStatus(data);
    }

    if (btnTechnicianPanel) btnTechnicianPanel.addEventListener("click", async () => {
        if (technicianModal) technicianModal.classList.remove("hidden");
        try { await checkTechnicianHealth(); } catch (_) { if (technicianStatus) technicianStatus.textContent = "Unable to reach local services."; }
    });
    if (btnCloseTechnician) btnCloseTechnician.addEventListener("click", () => technicianModal?.classList.add("hidden"));
    if (btnTechHealth) btnTechHealth.addEventListener("click", () => checkTechnicianHealth().catch(() => { if (technicianStatus) technicianStatus.textContent = "Health check failed."; }));
    if (btnTechRedetectAi) btnTechRedetectAi.addEventListener("click", () => checkTechnicianHealth(true).catch(() => { if (technicianStatus) technicianStatus.textContent = "AI redetection failed. Check Ollama."; }));
    if (btnTechRefresh) btnTechRefresh.addEventListener("click", async () => {
        await syncState();
        await loadMenuCards(currentCategory, currentDiet);
        if (technicianStatus) technicianStatus.textContent = "Dashboard refreshed.";
    });
    if (btnTechStopAudio) btnTechStopAudio.addEventListener("click", () => {
        if (mediaRecorder && mediaRecorder.state === "recording") stopPushToTalk();
        stopMic();
        stopSpeech();
        if (technicianStatus) technicianStatus.textContent = "Audio and microphone stopped.";
    });
    if (btnTechResetSession) btnTechResetSession.addEventListener("click", async () => {
        if (!confirm("Reset the active customer session?")) return;
        btnTechResetSession.disabled = true;
        if (technicianStatus) technicianStatus.textContent = "Resetting customer session...";
        try {
            if (mediaRecorder && mediaRecorder.state === "recording") stopPushToTalk();
            stopMic();
            stopSpeech();
            const res = await fetch("/api/technician/reset-session", { method: "POST" });
            const data = await res.json();
            if (!res.ok || !data.ok) {
                throw new Error(data.error || "Unable to reset the customer session.");
            }
            renderState(data);
            await loadMenuCards("all", "all");
            if (menuOrderStatus) menuOrderStatus.classList.add("hidden");
            switchTab("waiter");
            if (technicianStatus) technicianStatus.textContent = "Customer session reset. The waiter is ready for a new order.";
        } catch (error) {
            console.error("Technician session reset failed:", error);
            if (technicianStatus) technicianStatus.textContent = `Session reset failed: ${error.message}`;
        } finally {
            btnTechResetSession.disabled = false;
        }
    });

    // Show Payment Success Modal with receipt details
    function showSuccessModal(receipt, method) {
        if (!successModal) return;

        const sessEl = document.getElementById("receipt-session");
        const totalEl = document.getElementById("receipt-total");
        const list = document.getElementById("receipt-items-list");
        const methodLabel = document.getElementById("success-payment-method");

        if (sessEl) sessEl.textContent = receipt.session_id || "--";
        if (totalEl) totalEl.textContent = `PHP ${Number(receipt.total || 0).toFixed(2)}`;
        if (methodLabel) methodLabel.textContent = `Paid via ${method} \u2022 Perpetual Bistro`;

        if (list) {
            list.innerHTML = "";
            (receipt.items || []).forEach(item => {
                const d = document.createElement("div");
                d.className = "flex justify-between";
                d.innerHTML = `<span>${item.quantity}x ${item.name}</span><span class="font-bold">PHP ${Number(item.line_total).toFixed(2)}</span>`;
                list.appendChild(d);
            });
        }

        speakText(`Payment successful! Thank you for dining at Perpetual Bistro.`);
        successModal.classList.remove("hidden");
        pendingReceipt = null;
    }

    // Keep legacy showReceipt as no-op (the old flow is replaced)
    function showReceipt() {}

    // "New Customer" button: close success modal, reset session, return to greeting
    if (btnCloseReceipt) {
        btnCloseReceipt.addEventListener("click", async () => {
            if (successModal) successModal.classList.add("hidden");
            stopSpeech();
            try {
                await resetForNextCustomer();
            } catch (_) {}
            speakText("Welcome to Perpetual Bistro! What can I get started for you today?");
        });
    }

    // Load Menu Cards
    async function loadMenuCards(cat = currentCategory, diet = currentDiet) {
        currentCategory = cat;
        currentDiet = diet;
        if (!menuCardsContainer) return;

        try {
            let url = `/api/menu?category=${encodeURIComponent(cat)}`;
            if (diet && diet !== "all") {
                url = `/api/menu/filter?diet=${encodeURIComponent(diet)}&category=${encodeURIComponent(cat)}`;
            }
            const res = await fetch(url);
            const data = await res.json();
            renderMenuCards(data.items || []);
        } catch (e) {
            menuCardsContainer.innerHTML = `<div class="col-span-full py-12 text-center text-rose-600 text-xs">Failed to load menu items.</div>`;
        }
    }

    const MENU_IMAGES = {
        "Espresso": "/static/images/menu/espresso.png",
        "Americano": "/static/images/menu/americano.png",
        "Cappuccino": "/static/images/menu/cappuccino.png",
        "Café Latte": "/static/images/menu/cafe_latte.png",
        "Caramel Macchiato": "/static/images/menu/caramel_macchiato.png",
        "Spanish Latte": "/static/images/menu/spanish_latte.png",
        "Mocha": "/static/images/menu/mocha.png",
        "Matcha Latte": "/static/images/menu/matcha_latte.png",
        "Vanilla Bean Frappe": "/static/images/menu/vanilla_bean_frappe.png",
        "Java Chip Frappe": "/static/images/menu/java_chip_frappe.png",
        "Caramel Frappe": "/static/images/menu/caramel_frappe.png",
        "Strawberry Cream Frappe": "/static/images/menu/strawberry_cream_frappe.png",
        "Classic Chocolate Milkshake": "/static/images/menu/classic_chocolate_milkshake.png",
        "Vanilla Milkshake": "/static/images/menu/vanilla_milkshake.png",
        "Strawberry Milkshake": "/static/images/menu/strawberry_milkshake.png",
        "Mango Milkshake": "/static/images/menu/mango_milkshake.png",
        "Iced Peach Tea": "/static/images/menu/iced_peach_tea.png",
        "Strawberry Lemonade": "/static/images/menu/strawberry_lemonade.png",
        "Butter Croissant": "/static/images/menu/butter_croissant.png",
        "Chocolate Croissant": "/static/images/menu/chocolate_croissant.png",
        "Blueberry Muffin": "/static/images/menu/blueberry_muffin.png",
        "Cinnamon Roll": "/static/images/menu/cinnamon_roll.png",
        "Matcha Cookie": "/static/images/menu/matcha_cookie.png",
        "New York Cheesecake Slice": "/static/images/menu/new_york_cheesecake_slice.png"
    };

    function renderMenuCards(items) {
        if (!menuCardsContainer) return;
        menuCardsContainer.innerHTML = "";

        if (!items || items.length === 0) {
            menuCardsContainer.innerHTML = `<div class="col-span-full py-12 text-center text-neutral-500 text-xs italic">No menu items match this filter.</div>`;
            return;
        }

        items.forEach(item => {
            const card = document.createElement("div");
            card.className = "bg-white p-4 rounded-2xl border border-[#e5d8c3] shadow-sm hover:shadow transition flex flex-col justify-between";

            const isOutOfStock = item.available_qty <= 0;
            const stockBadge = !isOutOfStock
                ? `<span class="bg-[#dcfce7] text-[#166534] text-[11px] font-semibold px-2.5 py-0.5 rounded-full inline-flex items-center gap-1"><i class="fa-solid fa-check text-[10px]"></i> ${item.available_qty} in stock</span>`
                : `<span class="bg-rose-100 text-rose-800 text-[11px] font-semibold px-2.5 py-0.5 rounded-full inline-flex items-center gap-1"><i class="fa-solid fa-triangle-exclamation text-[10px]"></i> Out of stock</span>`;

            const dietaryBadge = item.dietary_tags ? `<span class="bg-[#fef3c7] text-[#92400e] text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider">${item.dietary_tags}</span>` : '';
            const allergenText = item.allergens ? item.allergens : 'none listed';
            const allergens = `<p class="text-[11px] text-[#78716c] mt-1.5 truncate" title="${allergenText}"><span class="font-normal text-[#57534e]">Allergens:</span> ${allergenText}</p>`;

            const imgSrc = MENU_IMAGES[item.name];
            const imgHtml = imgSrc
                ? `<img src="${imgSrc}" alt="${item.name}" class="w-16 h-16 sm:w-20 sm:h-20 object-contain rounded-xl flex-shrink-0" onerror="this.style.display='none'; this.nextElementSibling.classList.remove('hidden');" /><div class="hidden w-16 h-16 sm:w-20 sm:h-20 rounded-xl bg-[#f4ecd8] text-[#7b1238] flex items-center justify-center flex-shrink-0"><i class="fa-solid fa-mug-hot text-2xl"></i></div>`
                : `<div class="w-16 h-16 sm:w-20 sm:h-20 rounded-xl bg-[#f4ecd8] text-[#7b1238] flex items-center justify-center flex-shrink-0"><i class="fa-solid fa-mug-hot text-2xl"></i></div>`;

            card.innerHTML = `
                <div>
                    <div class="flex items-start gap-3">
                        ${imgHtml}
                        <div class="flex-1 min-w-0">
                            <div class="flex items-start justify-between gap-1.5 mb-1">
                                <h4 class="font-bold text-sm text-[#4a0020] truncate">${item.name}</h4>
                                <span class="font-mono font-bold text-sm text-[#4a0020] whitespace-nowrap">PHP ${Number(item.price).toFixed(2)}</span>
                            </div>
                            <div class="flex flex-wrap items-center gap-1.5 my-1">
                                ${stockBadge}
                                ${dietaryBadge}
                            </div>
                            ${allergens}
                        </div>
                    </div>
                </div>
                <div class="mt-3 pt-2.5 border-t border-[#f0e4cf] flex items-center justify-end">
                    <button class="menu-add-btn bg-[#4a0020] hover:bg-[#5f0029] text-[#fccc0c] px-3.5 py-1.5 rounded-lg text-xs font-semibold shadow transition flex items-center gap-1.5 ${isOutOfStock ? 'opacity-40 cursor-not-allowed' : ''}" data-name="${item.name}" ${isOutOfStock ? 'disabled' : ''}>
                        <i class="fa-solid fa-plus text-[10px]"></i> Add to Receipt
                    </button>
                </div>
            `;
            menuCardsContainer.appendChild(card);
        });

        // Attach click listeners to "+ Add to Receipt" buttons
        document.querySelectorAll(".menu-add-btn").forEach(btn => {
            btn.addEventListener("click", async () => {
                const name = btn.dataset.name;
                stopSpeech();

                const origHtml = btn.innerHTML;
                btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin text-[10px]"></i> Reading order...`;
                btn.disabled = true;

                await submitMessage(`Add 1 ${name}`, true, name);

                btn.innerHTML = `<i class="fa-solid fa-check text-[10px]"></i> Added!`;
                btn.classList.add("bg-emerald-700");
                btn.disabled = false;

                setTimeout(() => {
                    btn.innerHTML = origHtml;
                    btn.classList.remove("bg-emerald-700");
                }, 1200);
            });
        });
    }

    // Category Tabs Filter
    document.querySelectorAll(".menu-cat-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            document.querySelectorAll(".menu-cat-btn").forEach(b => {
                b.className = "menu-cat-btn px-3 py-1 rounded-full font-semibold bg-white text-neutral-700 hover:bg-neutral-100 border border-[#d6c4a8] flex-shrink-0";
            });
            btn.className = "menu-cat-btn px-3 py-1 rounded-full font-semibold bg-[#4a0020] text-[#fccc0c] shadow-sm flex-shrink-0";
            loadMenuCards(btn.dataset.cat, currentDiet);
        });
    });

    if (dietaryFilterSelect) {
        dietaryFilterSelect.addEventListener("change", () => {
            loadMenuCards(currentCategory, dietaryFilterSelect.value);
        });
    }

    // Initial state load
    syncState();
    loadMenuCards("all", "all");
});
