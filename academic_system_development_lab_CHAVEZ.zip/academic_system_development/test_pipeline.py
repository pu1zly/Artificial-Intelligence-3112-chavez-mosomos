"""
test_pipeline.py
Automated test suite verifying OBE Schema enforcement, Bloom's verb constraints,
multi-turn 14-week schedule validation, institutional grading formulas,
and error-handling retry logic.
"""

import json
import os
import unittest
from pydantic import ValidationError

from obe_schemas import (
    CourseOutcome,
    CourseOutcomePayload,
    CourseOutcomeSchema,
    LessonLearningOutcome,
    WeeklySchedule,
    InstitutionalGradingBreakdown,
    OBESyllabusPayload,
    BANNED_VERBS,
)


class TestOBESchemas(unittest.TestCase):
    def test_course_outcome_valid(self):
        """Verify valid CourseOutcome parses correctly."""
        co = CourseOutcome(
            clo_number=1,
            bloom_level="Level 3-4 (Apply/Analyze)",
            co_description="Implement singly and doubly linked lists in modern C++.",
            mapped_po=[1, 2]
        )
        self.assertEqual(co.clo_number, 1)
        self.assertIn(1, co.mapped_po)

    def test_course_outcome_banned_verb_rejection(self):
        """Verify non-measurable verbs ('understand', 'learn') are rejected."""
        with self.assertRaises(ValidationError) as ctx:
            CourseOutcome(
                clo_number=1,
                bloom_level="Level 1-2 (Remember/Understand)",
                co_description="Understand the fundamental concepts of algorithms.",
                mapped_po=[1]
            )
        self.assertIn("violates OBE compliance rules", str(ctx.exception))

    def test_course_outcome_invalid_po_range(self):
        """Verify PO index must be in range [1-6]."""
        with self.assertRaises(ValidationError):
            CourseOutcome(
                clo_number=1,
                bloom_level="Level 3-4 (Apply/Analyze)",
                co_description="Implement a hash table.",
                mapped_po=[0, 7]
            )

    def test_lesson_learning_outcome_remediation(self):
        """Verify that passive verbs in LLO are automatically remediated to Bloom's equivalents."""
        llo = LessonLearningOutcome(
            category="K",
            outcome_text="Understand recursion and call stacks."
        )
        self.assertTrue(llo.outcome_text.startswith("Explain"))

    def test_institutional_grading_formula(self):
        """Verify grading formula sums to 100% and follows Slide 14 specifications."""
        gb = InstitutionalGradingBreakdown()
        # Class Standing = Quizzes 30% + Research 20% + Seatwork/Lab 50%
        self.assertEqual(gb.quizzes_weight_pct, 30.0)
        self.assertEqual(gb.research_weight_pct, 20.0)
        self.assertEqual(gb.seatwork_lab_weight_pct, 50.0)
        self.assertEqual(gb.class_standing_weight_pct, 70.0)
        self.assertEqual(gb.major_exam_weight_pct, 30.0)

    def test_sample_output_syllabus_file(self):
        """Verify the generated sample_output_syllabus.json file meets all lab criteria."""
        syllabus_path = "sample_output_syllabus.json"
        self.assertTrue(os.path.exists(syllabus_path), f"File {syllabus_path} must exist.")

        with open(syllabus_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # Validate against full OBESyllabusPayload Pydantic schema
        syllabus = OBESyllabusPayload.model_validate(data)

        # 1. Course Outcomes criteria: 4 to 5 outcomes
        self.assertTrue(4 <= len(syllabus.course_outcomes) <= 5)

        # 2. 14 Weeks exactly
        self.assertEqual(len(syllabus.weekly_schedule), 14)

        # 3. Week 7 is Midterm
        week_7 = syllabus.weekly_schedule[6]
        self.assertEqual(week_7.week_number, 7)
        self.assertEqual(week_7.period, "MIDTERM")
        self.assertTrue("midterm" in week_7.topic.lower() or "midterm" in week_7.assessment_tool.lower())

        # 4. Week 14 is Final
        week_14 = syllabus.weekly_schedule[13]
        self.assertEqual(week_14.week_number, 14)
        self.assertEqual(week_14.period, "FINAL")
        self.assertTrue("final" in week_14.topic.lower() or "final" in week_14.assessment_tool.lower())

        # 5. Full coverage: Every CO must be aligned at least once
        co_numbers = {co.clo_number for co in syllabus.course_outcomes}
        aligned_cos = set()
        for week in syllabus.weekly_schedule:
            aligned_cos.update(week.aligned_co)
        self.assertEqual(co_numbers - aligned_cos, set(), "All COs must be referenced in weekly_schedule")

        # 6. IT hands-on labs check
        for week in syllabus.weekly_schedule:
            tla_lower = week.teaching_learning_activity.lower()
            self.assertTrue(
                any(keyword in tla_lower for keyword in ["lab", "hands-on", "programming", "practical", "exam", "coding", "project"]),
                f"Week {week.week_number} TLA '{week.teaching_learning_activity}' does not reflect hands-on IT lab."
            )


if __name__ == "__main__":
    unittest.main()
