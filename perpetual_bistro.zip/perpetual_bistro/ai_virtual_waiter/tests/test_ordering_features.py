import os
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

import db_tools as db
import fsm_agent


class OrderingFeatureTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        db.DB_PATH = os.path.join(self.temp.name, "restaurant.db")
        fsm_agent.LOG_PATH = os.path.join(self.temp.name, "conversation.json")
        db.init_db()
        self.agent = fsm_agent.WaiterAgent()
        self.agent.handle_user("Table 7")
        self.session_id = self.agent.session_id

    def tearDown(self):
        self.temp.cleanup()

    def _add_combo_catalog(self):
        with db.conn() as connection:
            connection.executemany(
                "INSERT INTO menu_items(name,category,price,stock_qty,allergens,dietary_tags) "
                "VALUES (?,?,?,?,?,?)",
                [
                    ("Avocado Toast", "Mains", 210, 20, "gluten", "vegetarian"),
                    ("French Fries", "Sides", 90, 30, "", "vegan"),
                    ("Garden Salad", "Sides", 110, 15, "", "vegan"),
                    ("Cold Brew Coffee", "Drinks", 95, 40, "", "vegan"),
                    ("Matcha Tea", "Drinks", 130, 20, "dairy", "vegetarian"),
                    ("Avocado Toast Combo", "Combos", 350, 20, "", ""),
                ],
            )
            combo_id = connection.execute(
                "SELECT id FROM menu_items WHERE name='Avocado Toast Combo'"
            ).fetchone()["id"]
            main_id = connection.execute(
                "SELECT id FROM menu_items WHERE name='Avocado Toast'"
            ).fetchone()["id"]
            fries_id = connection.execute(
                "SELECT id FROM menu_items WHERE name='French Fries'"
            ).fetchone()["id"]
            garden_salad_id = connection.execute(
                "SELECT id FROM menu_items WHERE name='Garden Salad'"
            ).fetchone()["id"]
            drink_id = connection.execute(
                "SELECT id FROM menu_items WHERE name='Cold Brew Coffee'"
            ).fetchone()["id"]
            matcha_tea_id = connection.execute(
                "SELECT id FROM menu_items WHERE name='Matcha Tea'"
            ).fetchone()["id"]
            connection.executemany(
                "INSERT INTO combo_components(combo_item_id,component_item_id,quantity) "
                "VALUES (?,?,1)",
                [(combo_id, main_id), (combo_id, fries_id), (combo_id, drink_id)],
            )
        return {
            "combo_id": combo_id,
            "main_id": main_id,
            "side_id": fries_id,
            "garden_salad_id": garden_salad_id,
            "drink_id": drink_id,
            "matcha_tea_id": matcha_tea_id,
        }

    def test_dietary_filter_only_returns_explicit_tags(self):
        result = db.get_menu_by_dietary_filter("vegetarian")
        names = {item["name"] for item in result["items"]}
        self.assertIn("Cappuccino", names)
        self.assertIn("Blueberry Muffin", names)
        self.assertNotIn("Espresso", names)
        vegan_names = {
            item["name"] for item in db.get_menu_by_dietary_filter("vegan")["items"]
        }
        self.assertIn("Espresso", vegan_names)
        self.assertIn("Iced Peach Tea", vegan_names)

    def test_allergen_filter_options_match_cafe_menu(self):
        self.assertEqual(
            fsm_agent.allergen_filter_options(),
            (
                "No dairy (listed allergens)",
                "No egg (listed allergens)",
                "No gluten (listed allergens)",
                "No soy (listed allergens)",
            ),
        )

    def test_allergen_filter_stays_with_selected_menu_category(self):
        pastries = db.get_menu_by_dietary_filter(
            "allergen-free:dairy", category="Pastries"
        )
        self.assertTrue(pastries["ok"])
        self.assertTrue(all(item["category"] == "Pastries" for item in pastries["items"]))
        self.assertEqual(pastries["items"], [])

        drinks = db.get_menu_by_dietary_filter(
            "allergen-free:dairy", category="Tea & Refreshers"
        )
        self.assertTrue(drinks["ok"])
        self.assertEqual(
            {item["name"] for item in drinks["items"]},
            {"Iced Peach Tea", "Strawberry Lemonade"},
        )

    def test_dairy_free_filter_excludes_listed_dairy_and_updates_chat_menu(self):
        result = db.get_menu_by_dietary_filter("dairy-free")
        names = {item["name"] for item in result["items"]}
        self.assertIn("Espresso", names)
        self.assertIn("Iced Peach Tea", names)
        self.assertIn("Strawberry Lemonade", names)
        self.assertNotIn("Matcha Latte", names)
        self.assertTrue(all("dairy" not in item["allergens"].split(",") for item in result["items"]))

        reply = self.agent.handle_user("Show me dairy-free options")
        self.assertIn("Espresso", reply)
        self.assertIn("Strawberry Lemonade", reply)
        self.assertIn("Coffee:", reply)

    def test_menu_filter_supports_any_listed_allergen(self):
        cases = {
            "Can I see meals without gluten?": "gluten",
            "Show me egg-free meals": "egg",
            "Which meals have no soy?": "soy",
            "List meals without peanuts": "nuts",
            "Can I see meals free of milk?": "dairy",
        }
        for request, allergen in cases.items():
            with self.subTest(request=request):
                self.assertEqual(
                    fsm_agent.detect_menu_diet_filter(request), f"allergen-free:{allergen}"
                )
        result = db.get_menu_by_dietary_filter("allergen-free:gluten")
        names = {item["name"] for item in result["items"]}
        self.assertIn("Espresso", names)
        self.assertIn("Strawberry Lemonade", names)
        self.assertNotIn("Blueberry Muffin", names)
        self.assertTrue(all(
            "gluten" not in {value.strip().casefold() for value in item["allergens"].split(",")}
            for item in result["items"] if not item["is_combo"]
        ))
        reply = self.agent.handle_user("Which items have no gluten?")
        self.assertIn("no gluten listed", reply.lower())
        self.assertIn("Espresso", reply)

    def test_filter_label_round_trips_allergen_choice(self):
        label = fsm_agent.menu_filter_label("allergen-free:sesame")
        self.assertEqual(label, "No sesame (listed allergens)")
        self.assertEqual(fsm_agent.menu_filter_key(label), "allergen-free:sesame")

    def test_menu_filter_detection_does_not_change_item_allergen_questions(self):
        self.assertEqual(fsm_agent.detect_menu_diet_filter("show me dairy-free meals"), "allergen-free:dairy")
        self.assertEqual(fsm_agent.detect_menu_diet_filter("meals without dairy"), "allergen-free:dairy")
        self.assertIsNone(fsm_agent.detect_menu_diet_filter("I want a dairy-free cheeseburger"))
        self.assertIsNone(fsm_agent.detect_menu_diet_filter("does the cheeseburger have dairy?"))

    def test_full_menu_browse_request_detection(self):
        for text in (
            "Can I see the menu?",
            "Could I please view the full menu",
            "Show me the menu",
            "Open menu",
            "Let me browse the menu",
        ):
            with self.subTest(text=text):
                self.assertTrue(fsm_agent.is_menu_browse_request(text))
        self.assertFalse(fsm_agent.is_menu_browse_request("What drinks do you have?"))
        self.assertFalse(fsm_agent.is_menu_browse_request("Does the cheeseburger have dairy?"))

    def test_database_startup_migrates_existing_menu_schema(self):
        legacy_path = os.path.join(self.temp.name, "legacy.db")
        connection = sqlite3.connect(legacy_path)
        connection.execute(
            "CREATE TABLE menu_items(id INTEGER PRIMARY KEY,name TEXT,category TEXT,price REAL,"
            "stock_qty INTEGER,allergens TEXT)"
        )
        connection.execute(
            "INSERT INTO menu_items VALUES (1,'Legacy dish','Mains',100,3,'')"
        )
        connection.commit()
        connection.close()
        db.DB_PATH = legacy_path
        db.init_db()
        with db.conn() as connection:
            columns = {row["name"] for row in connection.execute("PRAGMA table_info(menu_items)")}
            tags = connection.execute("SELECT dietary_tags FROM menu_items WHERE id=1").fetchone()[0]
        self.assertIn("dietary_tags", columns)
        self.assertEqual(tags, "")

    def test_database_startup_makes_existing_table_number_optional(self):
        legacy_path = os.path.join(self.temp.name, "legacy_sessions.db")
        connection = sqlite3.connect(legacy_path)
        connection.execute(
            "CREATE TABLE menu_items (id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, "
            "category TEXT NOT NULL, price REAL NOT NULL, stock_qty INTEGER NOT NULL DEFAULT 0, "
            "allergens TEXT NOT NULL DEFAULT '')"
        )
        connection.execute(
            "CREATE TABLE table_sessions (session_id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "table_no INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'open')"
        )
        connection.execute(
            "CREATE TABLE order_line_items (line_id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "session_id INTEGER NOT NULL REFERENCES table_sessions(session_id), "
            "item_id INTEGER NOT NULL REFERENCES menu_items(id), quantity INTEGER NOT NULL, "
            "special_instructions TEXT NOT NULL DEFAULT '')"
        )
        connection.execute(
            "INSERT INTO menu_items VALUES (1, 'Legacy item', 'Coffee', 10, 2, '')"
        )
        connection.execute("INSERT INTO table_sessions(table_no) VALUES (7)")
        connection.execute("INSERT INTO order_line_items(session_id,item_id,quantity) VALUES (1,1,1)")
        connection.commit()
        connection.close()

        db.DB_PATH = legacy_path
        db.init_db()

        with db.conn() as connection:
            session = connection.execute(
                "SELECT table_no FROM table_sessions WHERE session_id=1"
            ).fetchone()
            line_count = connection.execute(
                "SELECT COUNT(*) FROM order_line_items WHERE session_id=1"
            ).fetchone()[0]
            new_session_id = db.create_session(None)
            new_session = connection.execute(
                "SELECT table_no FROM table_sessions WHERE session_id=?",
                (new_session_id,),
            ).fetchone()
            violations = connection.execute("PRAGMA foreign_key_check").fetchall()
            table_no = next(
                row for row in connection.execute("PRAGMA table_info(table_sessions)")
                if row["name"] == "table_no"
            )
        self.assertEqual(session["table_no"], 7)
        self.assertEqual(line_count, 1)
        self.assertIsNone(new_session["table_no"])
        self.assertEqual(table_no["notnull"], 0)
        self.assertEqual(violations, [])

    def test_out_of_stock_add_returns_available_same_category_options(self):
        result = self.agent._run_tool("add_item_to_order", {"item_name": "Blueberry Muffin", "qty": 19})
        self.assertFalse(result["ok"])
        self.assertIn("only 18", result["error"].lower())
        alternatives = {item["name"] for item in result["alternatives"]}
        self.assertTrue(alternatives)
        self.assertNotIn("Blueberry Muffin", alternatives)

    def test_direct_menu_add_keeps_multiple_items_on_virtual_receipt(self):
        import app as web_app

        with patch.object(web_app, "agent", self.agent):
            client = web_app.create_app().test_client()
            first = client.post("/api/cart/add", json={"item_name": "Café Latte"})
            second = client.post("/api/cart/add", json={"item_name": "Blueberry Muffin"})

        self.assertTrue(first.get_json()["ok"])
        second_data = second.get_json()
        self.assertTrue(second_data["ok"])
        self.assertEqual(
            {item["name"] for item in second_data["cart"]["items"]},
            {"Café Latte", "Blueberry Muffin"},
        )
        order = db.view_current_order(self.session_id)
        self.assertEqual(
            {item["name"] for item in order["items"]},
            {"Café Latte", "Blueberry Muffin"},
        )
        self.assertEqual(order["subtotal"], 250)

    def test_chat_quantity_edits_return_updated_virtual_receipt(self):
        import app as web_app

        db.add_item_to_order(self.session_id, "Espresso", 3)
        with (
            patch.object(web_app, "agent", self.agent),
            patch.object(self.agent, "connect", return_value="test-model"),
            patch.object(web_app.speech, "stop"),
        ):
            client = web_app.create_app().test_client()
            added = client.post("/api/chat", json={"text": "add one more espresso"})
            removed = client.post("/api/chat", json={"text": "take off two espressos"})

        added_data = added.get_json()
        self.assertTrue(added_data["ok"])
        self.assertEqual(added_data["cart"]["items"][0]["quantity"], 4)
        removed_data = removed.get_json()
        self.assertTrue(removed_data["ok"])
        self.assertEqual(removed_data["cart"]["items"][0]["quantity"], 2)

    def test_menu_and_allergen_answers_are_database_grounded(self):
        drinks = self.agent.handle_user("What drinks do you have?")
        self.assertIn("Matcha Latte", drinks)
        self.assertNotIn("Soft Drinks", drinks)
        allergen = self.agent.handle_user("Does the Chocolate Croissant contain dairy?")
        self.assertIn("dairy is listed", allergen.lower())
        self.assertNotIn("not listed", allergen.lower())

    def test_combo_side_and_drink_selection_affects_price_and_inventory(self):
        ids = self._add_combo_catalog()
        result = db.add_combo_to_order(
            self.session_id, "Avocado Toast Combo", side_name="Garden Salad", drink_name="Matcha Tea"
        )
        self.assertTrue(result["ok"], result)
        item = result["order"]["items"][0]
        self.assertEqual((item["side_name"], item["drink_name"]), ("Garden Salad", "Matcha Tea"))
        self.assertEqual(item["unit_price"], 405)
        with db.conn() as connection:
            reserved = db._reserved_components(connection)
        self.assertEqual(reserved[ids["main_id"]], 1)
        self.assertEqual(reserved[ids["garden_salad_id"]], 1)
        self.assertEqual(reserved[ids["matcha_tea_id"]], 1)
        self.assertNotIn(ids["drink_id"], reserved)
        receipt = db.confirm_order(self.session_id)["receipt"]
        self.assertEqual(receipt["items"][0]["line_total"], 405)
        with db.conn() as connection:
            stock = {row["name"]: row["stock_qty"] for row in
                     connection.execute("SELECT name,stock_qty FROM menu_items")}
        self.assertEqual(stock["Garden Salad"], 14)
        self.assertEqual(stock["Matcha Tea"], 19)
        self.assertEqual(stock["French Fries"], 30)
        self.assertEqual(stock["Cold Brew Coffee"], 40)

    def test_combo_choices_create_separate_lines_and_reject_wrong_categories(self):
        self._add_combo_catalog()
        first = db.add_combo_to_order(self.session_id, "Avocado Toast Combo",
                                      side_name="Garden Salad", drink_name="Matcha Tea")
        second = db.add_combo_to_order(self.session_id, "Avocado Toast Combo",
                                       side_name="French Fries", drink_name="Cold Brew Coffee")
        self.assertTrue(first["ok"])
        self.assertTrue(second["ok"])
        self.assertEqual(len(second["order"]["items"]), 2)
        invalid = db.add_combo_to_order(self.session_id, "Avocado Toast Combo",
                                        side_name="Matcha Tea", drink_name="Cold Brew Coffee")
        self.assertFalse(invalid["ok"])
        self.assertIn("not a sides option", invalid["error"])

    def test_combo_selection_allergens_include_selected_drink(self):
        self._add_combo_catalog()
        result = db.add_combo_to_order(self.session_id, "Avocado Toast Combo",
                                       side_name="Garden Salad", drink_name="Matcha Tea")
        self.assertTrue(result["ok"], result)
        line = result["order"]["items"][0]
        allergens = db.get_order_item_allergens(line["line_id"])
        self.assertIn("dairy", allergens["allergens"].split(","))
        self.assertIn("gluten", allergens["allergens"].split(","))

    def test_combo_options_report_the_configured_defaults(self):
        ids = self._add_combo_catalog()
        options = db.get_combo_options(ids["combo_id"])

        self.assertTrue(options["ok"])
        self.assertEqual(options["default_side_name"], "French Fries")
        self.assertEqual(options["default_drink_name"], "Cold Brew Coffee")

    def test_controller_routes_combo_add_tool(self):
        self._add_combo_catalog()
        result = self.agent._run_tool("add_combo_to_order", {
            "combo_name": "Avocado Toast Combo",
            "side_name": "Garden Salad",
            "drink_name": "Matcha Tea",
        })

        self.assertTrue(result["ok"], result)
        item = db.view_current_order(self.session_id)["items"][0]
        self.assertEqual(item["name"], "Avocado Toast Combo")
        self.assertEqual((item["side_name"], item["drink_name"]), ("Garden Salad", "Matcha Tea"))

    def test_controller_starts_guided_combo_upgrade_from_recommendation(self):
        ids = self._add_combo_catalog()
        added = db.add_item_to_order(self.session_id, "Avocado Toast", 1)
        line_id = added["order"]["items"][0]["line_id"]

        prompt = self.agent.begin_combo_upgrade(line_id, "Avocado Toast Combo", ids["combo_id"])
        self.assertIn("Which side and drink", prompt)
        reply = self.agent.handle_user("Garden Salad and Matcha Tea")

        self.assertIn("tab has been updated", reply)
        item = db.view_current_order(self.session_id)["items"][0]
        self.assertEqual(item["name"], "Avocado Toast Combo")
        self.assertEqual((item["side_name"], item["drink_name"]), ("Garden Salad", "Matcha Tea"))

    def test_combo_upgrade_keeps_customization_and_selected_meal_options(self):
        self._add_combo_catalog()
        added = db.add_item_to_order(self.session_id, "Avocado Toast", 1, "no onions")
        line_id = added["order"]["items"][0]["line_id"]
        result = db.upgrade_to_combo(
            self.session_id, line_id, "Avocado Toast Combo",
            side_name="Garden Salad", drink_name="Matcha Tea",
        )
        self.assertTrue(result["ok"], result)
        item = result["order"]["items"][0]
        self.assertEqual(item["instructions"], "no onions")
        self.assertEqual((item["side_name"], item["drink_name"]), ("Garden Salad", "Matcha Tea"))
        self.assertEqual(item["unit_price"], 405)

    def test_accepting_chat_combo_offer_prompts_for_and_applies_choices(self):
        self._add_combo_catalog()
        added = db.add_item_to_order(self.session_id, "Avocado Toast", 1, "no onions")
        line_id = added["order"]["items"][0]["line_id"]
        recommendation = next(
            item for item in db.get_combo_recommendations(self.session_id)["recommendations"]
            if item["line_id"] == line_id
        )
        self.agent.pending_combo_offer = {
            "line_id": line_id, "combo_name": recommendation["combo_name"],
            "combo_id": recommendation["combo_id"],
        }

        prompt = self.agent.handle_user("Yes, upgrade it")
        self.assertIn("Which side and drink", prompt)
        self.assertEqual(db.view_current_order(self.session_id)["items"][0]["name"], "Avocado Toast")

        drink_prompt = self.agent.handle_user("Garden Salad")
        self.assertIn("drink", drink_prompt.lower())
        unchanged = db.view_current_order(self.session_id)["items"][0]
        self.assertEqual(unchanged["name"], "Avocado Toast")
        self.assertIsNone(unchanged.get("side_name"))

        upgraded = self.agent.handle_user("Matcha Tea")
        self.assertIn("tab has been updated", upgraded)
        item = db.view_current_order(self.session_id)["items"][0]
        self.assertEqual(item["name"], "Avocado Toast Combo")
        self.assertEqual((item["side_name"], item["drink_name"]), ("Garden Salad", "Matcha Tea"))
        self.assertEqual(item["instructions"], "no onions")
        self.assertIsNone(self.agent.pending_combo_upgrade)

    def test_acceptance_with_both_meal_choices_upgrades_immediately(self):
        self._add_combo_catalog()
        added = db.add_item_to_order(self.session_id, "Avocado Toast", 1)
        line_id = added["order"]["items"][0]["line_id"]
        recommendation = next(
            item for item in db.get_combo_recommendations(self.session_id)["recommendations"]
            if item["line_id"] == line_id
        )
        self.agent.pending_combo_offer = {
            "line_id": line_id, "combo_name": recommendation["combo_name"],
            "combo_id": recommendation["combo_id"],
        }
        reply = self.agent.handle_user("Yes, Garden Salad and Matcha Tea")
        self.assertIn("tab has been updated", reply)
        item = db.view_current_order(self.session_id)["items"][0]
        self.assertEqual(item["name"], "Avocado Toast Combo")
        self.assertEqual((item["side_name"], item["drink_name"]), ("Garden Salad", "Matcha Tea"))

    def test_quantity_edit_and_ambiguous_customized_removal(self):
        db.add_item_to_order(self.session_id, "Café Latte", 1, "no sugar")
        db.add_item_to_order(self.session_id, "Café Latte", 1, "extra hot")
        lines = db.view_current_order(self.session_id)["items"]
        ambiguous = db.remove_item_from_order(self.session_id, "Café Latte", 1)
        self.assertTrue(ambiguous["clarification_required"])
        updated = db.set_line_quantity(self.session_id, lines[0]["line_id"], 2)
        self.assertTrue(updated["ok"])
        items = db.view_current_order(self.session_id)["items"]
        self.assertEqual(items[0]["quantity"], 2)
        self.assertEqual(items[1]["instructions"], "extra hot")

    def test_chat_add_and_remove_quantity_phrases_update_receipt(self):
        db.add_item_to_order(self.session_id, "Espresso", 3)

        added = self.agent.handle_user("add one more espresso")
        self.assertIn("You now have 4", added)
        self.assertEqual(db.view_current_order(self.session_id)["items"][0]["quantity"], 4)

        removed = self.agent.handle_user("take off two espressos")
        self.assertIn("You now have 2", removed)
        self.assertEqual(db.view_current_order(self.session_id)["items"][0]["quantity"], 2)

        added_multiple = self.agent.handle_user("Could you add 2 more espressos?")
        self.assertIn("You now have 4", added_multiple)
        self.assertEqual(db.view_current_order(self.session_id)["items"][0]["quantity"], 4)

        clarification = self.agent.handle_user("add a number of more espressos")
        self.assertIn("How many Espresso", clarification)
        self.assertEqual(db.view_current_order(self.session_id)["items"][0]["quantity"], 4)
        followup = self.agent.handle_user("two")
        self.assertIn("You now have 6", followup)
        self.assertEqual(db.view_current_order(self.session_id)["items"][0]["quantity"], 6)

    def test_chat_quantity_parser_respects_stock_and_customization_ambiguity(self):
        db.add_item_to_order(self.session_id, "Blueberry Muffin", 18)
        stock_reply = self.agent.handle_user("add one more blueberry muffin")
        self.assertIn("Only 0", stock_reply)
        self.assertEqual(db.view_current_order(self.session_id)["items"][0]["quantity"], 18)

        db.add_item_to_order(self.session_id, "Café Latte", 1, "no sugar")
        db.add_item_to_order(self.session_id, "Café Latte", 1, "extra hot")
        before = db.view_current_order(self.session_id)
        reply = self.agent.handle_user("remove one café latte")
        self.assertIn("Which Café Latte should I remove?", reply)
        self.assertEqual(db.view_current_order(self.session_id), before)

    def test_cancellation_requires_confirmation_and_releases_stock(self):
        self.agent._run_tool("add_item_to_order", {"item_name": "Blueberry Muffin", "qty": 1})
        reply = self.agent.handle_user("Cancel my whole order")
        self.assertIn("Reply yes", reply)
        waiting = fsm_agent.WaiterAgent()
        self.assertEqual(waiting.pending_confirmation, "cancel_order")
        self.assertEqual(len(db.view_current_order(self.session_id)["items"]), 1)
        cancelled = waiting.handle_user("yes")
        self.assertIn("order has been cancelled", cancelled)
        self.assertNotEqual(waiting.session_id, self.session_id)
        self.assertEqual(db.view_current_order(waiting.session_id)["items"], [])
        with db.conn() as connection:
            status = connection.execute("SELECT status FROM table_sessions WHERE session_id=?",
                                        (self.session_id,)).fetchone()[0]
        self.assertEqual(status, "cancelled")
        muffin = next(
            item for item in db.get_menu_by_category("Pastries")["items"]
            if item["name"] == "Blueberry Muffin"
        )
        self.assertEqual(muffin["available_qty"], 18)

    def test_non_yes_no_interrupt_does_not_cancel_order(self):
        self.agent._run_tool("add_item_to_order", {"item_name": "Café Latte", "qty": 1})
        self.agent.handle_user("cancel my order")
        response = self.agent.handle_user("What drinks do you have?")
        self.assertIn("Iced Peach Tea", response)
        self.assertNotIn("Soft Drinks", response)
        self.assertEqual(len(db.view_current_order(self.session_id)["items"]), 1)

    def test_db_mutating_functions_require_active_open_session(self):
        res1 = db.add_item_to_order(None, "Café Latte", 1)
        self.assertFalse(res1["ok"])
        self.assertIn("No active table session", res1["error"])

        res2 = db.add_combo_to_order(None, "Avocado Toast Combo", "French Fries", "Cold Brew Coffee", 1)
        self.assertFalse(res2["ok"])
        self.assertIn("No active table session", res2["error"])

        res3 = db.remove_item_from_order(None, "Café Latte")
        self.assertFalse(res3["ok"])
        self.assertIn("No active table session", res3["error"])

        res4 = db.confirm_order(None)
        self.assertFalse(res4["ok"])
        self.assertIn("No active table session", res4["error"])

    def test_db_confirm_twice_rejected(self):
        db.add_item_to_order(self.session_id, "Café Latte", 1)
        first = db.confirm_order(self.session_id)
        self.assertTrue(first["ok"])
        with db.conn() as c:
            stock_after_first = c.execute("SELECT stock_qty FROM menu_items WHERE name='Café Latte'").fetchone()[0]
        second = db.confirm_order(self.session_id)
        self.assertFalse(second["ok"])
        with db.conn() as c:
            stock_after_second = c.execute("SELECT stock_qty FROM menu_items WHERE name='Café Latte'").fetchone()[0]
        self.assertEqual(stock_after_first, stock_after_second)

    def test_order_session_starts_without_table_number(self):
        agent = fsm_agent.WaiterAgent()
        agent.reset()
        self.assertEqual(agent.state, fsm_agent.ORDERING)
        self.assertIsNone(agent.table_no)
        self.assertIsNotNone(agent.session_id)
        with db.conn() as connection:
            session = connection.execute(
                "SELECT table_no FROM table_sessions WHERE session_id=?",
                (agent.session_id,),
            ).fetchone()
        self.assertIsNone(session["table_no"])

        res = agent._run_tool("add_item_to_order", {"item_name": "Espresso", "qty": 1})
        self.assertTrue(res["ok"], res)

    def test_customer_session_reset_succeeds_after_cancellation_and_repeatedly(self):
        agent = fsm_agent.WaiterAgent()
        original_session_id = agent.session_id
        cancelled = db.cancel_order(original_session_id)
        self.assertTrue(cancelled["ok"], cancelled)

        agent.reset()
        first_reset_session_id = agent.session_id
        self.assertNotEqual(first_reset_session_id, original_session_id)
        self.assertEqual(agent.transcript[-1]["role"], "waiter")

        agent.reset()
        self.assertNotEqual(agent.session_id, first_reset_session_id)
        self.assertEqual(agent.state, fsm_agent.ORDERING)

    def test_catalog_query_needs_no_table_number(self):
        agent = fsm_agent.WaiterAgent()
        agent.reset()
        reply = agent.handle_user("What drinks do you have?")
        self.assertIn("Matcha Latte", reply)
        self.assertNotIn("table number", reply.lower())
        self.assertEqual(agent.state, fsm_agent.ORDERING)

    def test_table_number_is_not_requested_or_saved(self):
        agent = fsm_agent.WaiterAgent()
        agent.reset()
        reply = agent.handle_user("Table 7")
        self.assertIn("No table number is needed", reply)
        self.assertIsNone(agent.table_no)

    def test_order_can_be_confirmed_without_table_number(self):
        self.agent.reset()
        add_result = self.agent._run_tool(
            "add_item_to_order", {"item_name": "Espresso", "qty": 1}
        )
        self.assertTrue(add_result["ok"], add_result)

        self.agent.go_review()
        confirmation = self.agent.confirm()

        self.assertEqual(self.agent.state, fsm_agent.CONFIRMED)
        self.assertIsNone(self.agent.snapshot()["receipt"]["table_no"])
        self.assertIn("order has been confirmed", confirmation.lower())
        self.assertNotIn("Table", confirmation)

    def test_is_menu_browse_request_standalone_menu(self):
        for phrase in ("menu", "Menu", "MENU", "menu please", "menu!"):
            with self.subTest(phrase=phrase):
                self.assertTrue(fsm_agent.is_menu_browse_request(phrase))

    def test_adjust_line_during_review_transitions_and_notifies(self):
        self.agent._run_tool("add_item_to_order", {"item_name": "Café Latte", "qty": 1})
        self.agent.go_review()
        self.assertEqual(self.agent.state, fsm_agent.REVIEW)
        line_id = db.view_current_order(self.session_id)["items"][0]["line_id"]
        res = self.agent.adjust(line_id, 1)
        self.assertTrue(res["ok"])
        self.assertEqual(self.agent.state, fsm_agent.TAKING_ORDER)
        self.assertIn("Your order was adjusted", self.agent.transcript[-1]["text"])


if __name__ == "__main__":
    unittest.main()
