"""
llm_engine.py
================================================================================
AI-Powered OBE Syllabus Generator Microservice
Milestone 1 — Deliverable 2: Two-Pass Ollama Query Engine & Error Retry Logic

Architecture
------------
For EVERY course, the engine runs a TWO-PASS local LLM conversation with
Qwen 2.5 (served by Ollama):

    PASS 1 — DRAFT
        The model freely drafts 4-6 Course Outcomes distributed across the
        Knowledge / Skills / Attitude (K/S/A) domains, given the course
        metadata.

    PASS 2 — SELF-AUDIT & REFINE
        The Pass-1 draft is fed straight back to the model together with an
        explicit OBE compliance checklist (banned verbs, domain verb banks,
        PO range, K/S/A coverage, sequential numbering). The model must
        audit its own draft and return a corrected, final JSON object.

The Pass-2 output is then parsed and validated against the strict Pydantic
contracts in `obe_schemas.py`. If validation fails (bad JSON syntax OR a
Pydantic ValidationError), the concrete error message is injected back into
the conversation as a new user turn and the model is asked to correct it —
this is the automated ERROR RETRY LOOP, bounded by `max_retries`.

This module also performs BATCH PROCESSING for the four 3rd Year, 1st
Semester CS/IT subjects:
    1. Computer Graphics Programming
    2. Database Systems 1
    3. Data Mining and Analytics
    4. Software Engineering

Usage
-----
    # Real local Ollama run — auto-detects whichever model you already have
    # installed (prefers a "qwen" model if more than one is installed).
    python llm_engine.py

    # Or pin a specific model explicitly:
    python llm_engine.py --model qwen2.5:7b --retries 3

    # Offline / CI-safe demo run using the built-in MockProvider
    # (exercises the exact same validation + retry code path, no Ollama needed)
    python llm_engine.py --mock --output sample_validated_output.json
================================================================================
"""

from __future__ import annotations

import argparse
import json
import sys
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from pydantic import ValidationError

from obe_schemas import (
    ALLOWED_PO_RANGE,
    BANNED_VERBS,
    DOMAIN_LEVEL_DEFAULT,
    DOMAIN_LEVELS,
    DOMAIN_VERB_BANKS,
    BatchGenerationResult,
    CourseMetadata,
    CourseOutcomePayload,
    GenerationAudit,
    ValidatedCourseRecord,
)


# ==============================================================================
# 1. BATCH COURSE CATALOG — 3rd Year, 1st Semester CS/IT
# ==============================================================================

COURSE_CATALOG: List[CourseMetadata] = [
    CourseMetadata(
        course_code="CS321",
        course_title="Computer Graphics Programming",
        course_description=(
            "Covers the mathematical and programmatic foundations of 2D and 3D "
            "computer graphics, including transformation pipelines, rasterization, "
            "shader programming, lighting models, and real-time rendering using "
            "modern graphics APIs."
        ),
        target_pos=[1, 2, 3, 5],
    ),
    CourseMetadata(
        course_code="CS322",
        course_title="Database Systems 1",
        course_description=(
            "Introduces relational database design theory, normalization, "
            "SQL query authoring, transaction management, and the implementation "
            "of a normalized relational database for a real-world application."
        ),
        target_pos=[1, 2, 3, 4],
    ),
    CourseMetadata(
        course_code="CS323",
        course_title="Data Mining and Analytics",
        course_description=(
            "Explores data preprocessing, exploratory data analysis, classification, "
            "clustering, and association-rule mining techniques, applying analytical "
            "pipelines to real-world datasets to extract actionable insight."
        ),
        target_pos=[1, 2, 3, 6],
    ),
    CourseMetadata(
        course_code="CS324",
        course_title="Software Engineering",
        course_description=(
            "Covers the software development life cycle, requirements engineering, "
            "software design principles, agile project management, quality assurance, "
            "and team-based delivery of a working software system."
        ),
        target_pos=[1, 2, 3, 4, 7],
    ),
]


# ==============================================================================
# 2. ENGINE CONFIGURATION
# ==============================================================================

@dataclass
class EngineConfig:
    model_name: str = "qwen2.5:7b"
    pass1_temperature: float = 0.4   # drafting: a bit of creative variance
    pass2_temperature: float = 0.1   # self-audit: deterministic correction
    max_retries: int = 3
    outcomes_min: int = 4
    outcomes_max: int = 6


# ==============================================================================
# 3. LLM PROVIDER ABSTRACTION (real Ollama + offline Mock for testing)
# ==============================================================================

class LLMProvider(ABC):
    """Thin abstraction over 'send chat messages, get JSON-mode text back'.
    Lets the exact same two-pass + retry pipeline run against either the
    real local Ollama/Qwen2.5 runtime, or a scripted MockProvider for
    dependency-free testing of the schema/retry logic."""

    @abstractmethod
    def chat(self, messages: List[Dict[str, str]], temperature: float) -> str:
        ...


def _get_ollama_module():
    try:
        import ollama  # local import: keeps the module importable without the dep
    except ImportError as exc:
        raise RuntimeError(
            "The 'ollama' Python package is required. Install with "
            "`pip install ollama` and ensure `ollama serve` is running locally."
        ) from exc
    return ollama


def _extract_model_name(entry: Any) -> Optional[str]:
    """Handles both dict-style and object-style entries returned by
    different `ollama` python client versions."""
    if isinstance(entry, dict):
        return entry.get("model") or entry.get("name")
    return getattr(entry, "model", None) or getattr(entry, "name", None)


def auto_detect_model(prefer_substring: str = "qwen") -> str:
    """Auto-detects a locally installed Ollama model so the user never has
    to type a model name. Prefers a model whose name contains `prefer_substring`
    (default 'qwen'); otherwise falls back to the first installed model.
    Raises RuntimeError with a helpful message if no models are installed
    or the Ollama daemon isn't reachable."""
    ollama = _get_ollama_module()
    try:
        listing = ollama.list()
    except Exception as exc:
        raise RuntimeError(
            "Could not reach the local Ollama daemon. Make sure Ollama is "
            "installed and running (`ollama serve`), then try again."
        ) from exc

    raw_models = listing.get("models") if isinstance(listing, dict) else getattr(listing, "models", None)
    raw_models = raw_models or []
    names = [n for n in (_extract_model_name(m) for m in raw_models) if n]

    if not names:
        raise RuntimeError(
            "No local Ollama models found. Pull one first, e.g.:\n"
            "  ollama pull qwen2.5:7b"
        )

    for name in names:
        if prefer_substring.lower() in name.lower():
            return name

    return names[0]


class OllamaProvider(LLMProvider):
    """Queries a locally running Ollama daemon in strict JSON mode. This is
    the production provider for the microservice. If no model_name is given,
    it auto-detects whichever model the user already has installed."""

    def __init__(self, model_name: Optional[str] = None):
        self._ollama = _get_ollama_module()
        self.model_name = model_name or auto_detect_model()

    def chat(self, messages: List[Dict[str, str]], temperature: float) -> str:
        response = self._ollama.chat(
            model=self.model_name,
            messages=messages,
            format="json",
            options={"temperature": temperature},
        )
        return response["message"]["content"]


class MockProvider(LLMProvider):
    """Deterministic, offline stand-in for Ollama. Returns a pre-scripted
    queue of raw JSON-text responses, one per `chat()` call, in order.
    Used for local/CI verification of the schema-validation and error-retry
    logic without requiring a running Ollama daemon or GPU."""

    def __init__(self, scripted_responses: List[str]):
        self._queue = list(scripted_responses)
        self.calls_made = 0

    def chat(self, messages: List[Dict[str, str]], temperature: float) -> str:
        self.calls_made += 1
        if not self._queue:
            raise RuntimeError("MockProvider response queue exhausted.")
        return self._queue.pop(0)


# ==============================================================================
# 4. PROMPT ENGINEERING
# ==============================================================================

_SCHEMA_REFERENCE = """{
  "course_code": string,
  "course_title": string,
  "course_description": string,
  "target_pos": [int],
  "course_outcomes": [
    {
      "clo_number": 1,
      "domain": "Knowledge" | "Skills" | "Attitude",
      "bloom_level": string (must match the declared domain's level list below),
      "co_description": "Active domain-appropriate verb + measurable outcome statement.",
      "mapped_po": [int]
    }
  ]
}"""

SYSTEM_PROMPT_PASS1_DRAFT = f"""You are an expert IT/CS Curriculum Designer for the College of Computer Studies (CCS).
Draft Course Learning Outcomes (CLOs) for a 3rd Year, 1st Semester CS/IT course.

STRICT OBE / BLOOM'S TAXONOMY RULES:
1. NEVER use non-measurable verbs: {sorted(BANNED_VERBS)}.
2. Produce between 4 and 6 total Course Outcomes.
3. Each outcome MUST be tagged with exactly one domain: "Knowledge", "Skills", or "Attitude".
4. The full set of outcomes MUST cover ALL THREE domains at least once each
   (this is the K/S/A coverage rule — at minimum one Knowledge, one Skills,
   and one Attitude outcome).
5. Domain proficiency levels allowed:
   - Knowledge (Cognitive): {DOMAIN_LEVELS['Knowledge']}
   - Skills (Psychomotor):  {DOMAIN_LEVELS['Skills']}
   - Attitude (Affective):  {DOMAIN_LEVELS['Attitude']}
6. Each co_description MUST start with an active verb taken from that
   outcome's OWN domain verb bank:
   - Knowledge verbs: {DOMAIN_VERB_BANKS['Knowledge'][:12]} ...
   - Skills verbs:    {DOMAIN_VERB_BANKS['Skills'][:12]} ...
   - Attitude verbs:  {DOMAIN_VERB_BANKS['Attitude'][:12]} ...
7. clo_number values must be sequential integers starting at 1, no duplicates.
8. mapped_po values must be within range {ALLOWED_PO_RANGE}.

Output MUST be a single valid JSON object strictly matching this schema:
{_SCHEMA_REFERENCE}

Return ONLY pure JSON. No markdown fences, no commentary."""


SYSTEM_PROMPT_PASS2_AUDIT = f"""You are a strict OBE Quality Assurance Auditor for the College of Computer
Studies (CCS). You will be given a DRAFT Course Outcomes JSON object produced
by a curriculum designer. Audit it against this checklist and OUTPUT A
CORRECTED FINAL JSON OBJECT — fix every violation you find:

CHECKLIST:
[ ] No banned/non-measurable verbs anywhere: {sorted(BANNED_VERBS)}
[ ] Between 4 and 6 total course_outcomes.
[ ] Every outcome's "domain" is exactly one of "Knowledge", "Skills", "Attitude".
[ ] ALL THREE domains (Knowledge, Skills, Attitude) appear at least once across the set.
[ ] Each outcome's "bloom_level" matches its own domain's allowed level list:
    Knowledge: {DOMAIN_LEVELS['Knowledge']}
    Skills:    {DOMAIN_LEVELS['Skills']}
    Attitude:  {DOMAIN_LEVELS['Attitude']}
[ ] Each co_description begins with a verb from that outcome's OWN domain verb bank
    (Knowledge/Skills/Attitude banks as defined for a CS/IT curriculum).
[ ] clo_number values are sequential integers starting at 1 with no duplicates or gaps.
[ ] mapped_po values fall within {ALLOWED_PO_RANGE}.

Return ONLY the corrected, pure JSON object — same schema as the input, no
markdown fences, no commentary, no explanation of what you changed."""


def _build_pass1_user_prompt(meta: CourseMetadata) -> str:
    return f"""Draft Course Outcomes for the following course:
Course Code: {meta.course_code}
Course Title: {meta.course_title}
Course Description: {meta.course_description}
Year/Semester: {meta.year_level}, {meta.semester}
Target Program Outcomes (POs): {meta.target_pos}

Remember: 4-6 outcomes total, ALL THREE K/S/A domains represented, each
verb drawn strictly from its own domain's verb bank. Return pure JSON only."""


def _build_pass2_user_prompt(draft_json_text: str) -> str:
    return f"""Here is the DRAFT Course Outcomes JSON to audit and correct:

{draft_json_text}

Apply the full checklist and return the corrected final JSON object only."""


# ==============================================================================
# 5. JSON CLEANUP HELPERS
# ==============================================================================

def _strip_markdown_fences(raw: str) -> str:
    text = raw.strip()
    if text.startswith("```json"):
        text = text[len("```json"):]
    elif text.startswith("```"):
        text = text[len("```"):]
    if text.endswith("```"):
        text = text[: -len("```")]
    return text.strip()


def _parse_json_or_raise(raw: str) -> Dict[str, Any]:
    cleaned = _strip_markdown_fences(raw)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON syntax generated by model: {exc}") from exc


# ==============================================================================
# 6. AUTO-REPAIR LAYER — mechanically fixes the mistakes small/weak local
#    models make most often, BEFORE Pydantic validation runs. This does not
#    weaken the schema (Pydantic still rejects anything malformed or
#    incomplete) — it just prevents predictable, mechanical mismatches from
#    burning through retries on a model too small to track every rule at once.
# ==============================================================================

# Verbs the model commonly borrows from the WRONG domain, remapped to the
# closest equivalent verb in each of the three domains.
_VERB_CROSS_MAP: Dict[str, Dict[str, str]] = {
    "apply":      {"Skills": "implement", "Attitude": "practice"},
    "analyze":    {"Skills": "test",      "Attitude": "assess"},
    "evaluate":   {"Skills": "test",      "Attitude": "assess"},
    "assess":     {"Skills": "test",      "Knowledge": "evaluate"},
    "formulate":  {"Skills": "construct", "Attitude": "advocate"},
    "design":     {"Skills": "construct", "Attitude": "advocate"},
    "develop":    {"Skills": "build",     "Attitude": "cultivate"},
    "recognize":  {"Skills": "demonstrate", "Attitude": "value"},
    "describe":   {"Skills": "demonstrate", "Attitude": "observe"},
    "explain":    {"Skills": "demonstrate", "Attitude": "advocate"},
    "identify":   {"Skills": "demonstrate", "Attitude": "observe"},
    "solve":      {"Skills": "implement",   "Attitude": "practice"},
    "compare":    {"Skills": "test",        "Attitude": "assess"},
    "construct":  {"Knowledge": "design",   "Attitude": "cultivate"},
    "implement":  {"Knowledge": "apply",    "Attitude": "practice"},
    "demonstrate": {"Knowledge": "apply",   "Attitude": "exhibit"},
    "value":      {"Knowledge": "assess",   "Skills": "prioritize"},
    "advocate":   {"Knowledge": "justify",  "Skills": "champion"},
}


def _repair_bloom_level(domain: str, level: Any) -> str:
    valid_levels = DOMAIN_LEVELS.get(domain, [])
    if isinstance(level, str) and level in valid_levels:
        return level
    return DOMAIN_LEVEL_DEFAULT.get(domain, valid_levels[0] if valid_levels else "")


def _repair_description_verb(domain: str, description: Any) -> Any:
    if not isinstance(description, str) or not description.strip():
        return description
    words = description.strip().split()
    if not words:
        return description
    first_raw = words[0]
    first = first_raw.lower().rstrip(",.:;")
    rest = " ".join(words[1:])
    bank = DOMAIN_VERB_BANKS.get(domain, [])

    if first in bank:
        return description  # already domain-correct, leave untouched

    replacement: Optional[str] = None

    # 1) Known cross-domain confusion -> direct remap
    if first in _VERB_CROSS_MAP and domain in _VERB_CROSS_MAP[first]:
        replacement = _VERB_CROSS_MAP[first][domain]
    # 2) Banned/non-measurable verb -> map to a sensible domain-appropriate verb
    elif first in BANNED_VERBS:
        replacement = bank[0] if bank else first
    # 3) Anything else unrecognized -> fall back to the domain's primary verb
    elif bank:
        replacement = bank[0]

    if replacement is None:
        return description

    replacement = replacement.capitalize() if first_raw[0:1].isupper() else replacement
    return f"{replacement} {rest}".strip() if rest else replacement


def auto_repair_payload_dict(parsed: Dict[str, Any]) -> Dict[str, Any]:
    """Mutates a shallow copy of the parsed draft/audit JSON, repairing
    mechanical domain/level/verb mismatches before Pydantic sees it."""
    if not isinstance(parsed, dict):
        return parsed
    repaired = dict(parsed)
    outcomes = repaired.get("course_outcomes")
    if not isinstance(outcomes, list):
        return repaired

    fixed_outcomes = []
    for oc in outcomes:
        if not isinstance(oc, dict):
            fixed_outcomes.append(oc)
            continue
        oc = dict(oc)
        domain = oc.get("domain")
        if domain in DOMAIN_LEVELS:
            oc["bloom_level"] = _repair_bloom_level(domain, oc.get("bloom_level"))
            oc["co_description"] = _repair_description_verb(domain, oc.get("co_description"))
        fixed_outcomes.append(oc)

    repaired["course_outcomes"] = fixed_outcomes
    return repaired


def _diff_repair(before: Dict[str, Any], after: Dict[str, Any]) -> List[str]:
    """Human-readable list of exactly what auto_repair_payload_dict changed,
    field by field, for a given course's outcomes. Used only for --debug
    output so you can see the model's original words vs. the correction."""
    diffs: List[str] = []
    before_list = before.get("course_outcomes") if isinstance(before, dict) else None
    after_list = after.get("course_outcomes") if isinstance(after, dict) else None
    if not isinstance(before_list, list) or not isinstance(after_list, list):
        return diffs

    for b, a in zip(before_list, after_list):
        if not isinstance(b, dict) or not isinstance(a, dict):
            continue
        clo = a.get("clo_number", b.get("clo_number", "?"))
        if b.get("bloom_level") != a.get("bloom_level"):
            diffs.append(f"CLO {clo}: bloom_level '{b.get('bloom_level')}' -> '{a.get('bloom_level')}'")
        if b.get("co_description") != a.get("co_description"):
            diffs.append(f"CLO {clo}: co_description '{b.get('co_description')}' -> '{a.get('co_description')}'")
    return diffs

# ==============================================================================
# 6. TWO-PASS GENERATION + ERROR RETRY LOOP
# ==============================================================================

@dataclass
class GenerationOutcome:
    payload: Optional[CourseOutcomePayload]
    audit: GenerationAudit
    success: bool
    error: Optional[str] = None
    log: List[str] = field(default_factory=list)


def generate_course_outcomes(
    meta: CourseMetadata,
    provider: LLMProvider,
    cfg: EngineConfig,
    debug: bool = False,
) -> GenerationOutcome:
    """Runs the full two-pass pipeline (draft -> self-audit) for ONE course,
    then validates the result against `CourseOutcomePayload`. On a Pydantic
    or JSON failure, re-prompts the model (pass 2 style) with the concrete
    error message and retries, up to `cfg.max_retries` times.

    debug=True prints the RAW, UNEDITED text returned by the model at every
    pass, plus a before/after diff of anything the auto-repair layer
    touched — so you can directly verify the output is coming from the live
    model and see exactly what (if anything) got mechanically corrected."""

    log: List[str] = []
    retries_used = 0
    pass1_completed = False
    pass2_completed = False

    # ---- PASS 1: DRAFT -------------------------------------------------
    pass1_messages = [
        {"role": "system", "content": SYSTEM_PROMPT_PASS1_DRAFT},
        {"role": "user", "content": _build_pass1_user_prompt(meta)},
    ]
    try:
        draft_raw = provider.chat(pass1_messages, temperature=cfg.pass1_temperature)
        pass1_completed = True
        log.append(f"[PASS 1 / DRAFT] {meta.course_code}: received draft ({len(draft_raw)} chars).")
        if debug:
            print(f"\n----- RAW PASS 1 OUTPUT ({meta.course_code}) — verbatim from the model -----")
            print(draft_raw)
            print("----- END RAW PASS 1 OUTPUT -----\n")
    except Exception as exc:  # provider-level failure (e.g. Ollama unreachable)
        audit = GenerationAudit(model_used=cfg.model_name, pass1_completed=False, pass2_completed=False)
        return GenerationOutcome(payload=None, audit=audit, success=False, error=f"Pass 1 provider error: {exc}", log=log)

    # ---- PASS 2: SELF-AUDIT & REFINE -----------------------------------
    audit_messages = [
        {"role": "system", "content": SYSTEM_PROMPT_PASS2_AUDIT},
        {"role": "user", "content": _build_pass2_user_prompt(draft_raw)},
    ]

    attempt = 0
    last_error = ""
    final_raw = ""

    while attempt <= cfg.max_retries:
        try:
            final_raw = provider.chat(audit_messages, temperature=cfg.pass2_temperature)
            pass2_completed = True
            log.append(f"[PASS 2 / AUDIT attempt {attempt + 1}] {meta.course_code}: received audited JSON.")
            if debug:
                print(f"----- RAW PASS 2 OUTPUT ({meta.course_code}, attempt {attempt + 1}) — verbatim from the model -----")
                print(final_raw)
                print("----- END RAW PASS 2 OUTPUT -----\n")

            parsed = _parse_json_or_raise(final_raw)
            repaired = auto_repair_payload_dict(parsed)
            if debug:
                diffs = _diff_repair(parsed, repaired)
                if diffs:
                    print(f"----- AUTO-REPAIR CHANGES ({meta.course_code}) -----")
                    for d in diffs:
                        print(" ", d)
                    print("----- END AUTO-REPAIR CHANGES -----\n")
                else:
                    print(f"[AUTO-REPAIR] {meta.course_code}: nothing to fix, model output already domain-compliant.\n")

            payload = CourseOutcomePayload.model_validate(repaired)

            log.append(
                f"[VALIDATED] {meta.course_code}: schema OK, K/S/A = {payload.ksa_summary()}, "
                f"retries_used={retries_used}."
            )
            audit = GenerationAudit(
                model_used=cfg.model_name,
                pass1_completed=pass1_completed,
                pass2_completed=pass2_completed,
                retries_used=retries_used,
            )
            return GenerationOutcome(payload=payload, audit=audit, success=True, log=log)

        except (ValueError, ValidationError) as err:
            attempt += 1
            retries_used = attempt
            last_error = str(err)
            log.append(f"[VALIDATION FAILURE attempt {attempt}] {meta.course_code}: {last_error}")

            if attempt > cfg.max_retries:
                log.append(f"[ABORT] {meta.course_code}: exceeded max_retries={cfg.max_retries}.")
                break

            # Automated error-recovery: inject the concrete Pydantic/JSON
            # error back into the conversation and ask the model to fix it.
            audit_messages.append({"role": "assistant", "content": final_raw})
            audit_messages.append({
                "role": "user",
                "content": (
                    f"Your JSON failed schema validation with this error:\n{last_error}\n\n"
                    f"Correct ONLY what is necessary to satisfy the checklist and the error "
                    f"above, keep everything else intact, and return the corrected pure JSON "
                    f"object (no markdown fences, no commentary)."
                ),
            })

    audit = GenerationAudit(
        model_used=cfg.model_name,
        pass1_completed=pass1_completed,
        pass2_completed=pass2_completed,
        retries_used=retries_used,
    )
    return GenerationOutcome(payload=None, audit=audit, success=False, error=last_error, log=log)


# ==============================================================================
# 7. BATCH PROCESSING — all 4 CS/IT subjects
# ==============================================================================

def run_batch(
    provider: LLMProvider,
    cfg: EngineConfig,
    catalog: Optional[List[CourseMetadata]] = None,
    verbose: bool = True,
    debug: bool = False,
) -> BatchGenerationResult:
    catalog = catalog if catalog is not None else COURSE_CATALOG
    records: List[ValidatedCourseRecord] = []
    failures: List[Dict[str, Any]] = []

    for meta in catalog:
        if verbose:
            print(f"\n{'=' * 70}\nGenerating: [{meta.course_code}] {meta.course_title}\n{'=' * 70}")

        outcome = generate_course_outcomes(meta, provider, cfg, debug=debug)
        for line in outcome.log:
            if verbose:
                print(" ", line)

        if outcome.success and outcome.payload is not None:
            records.append(ValidatedCourseRecord(payload=outcome.payload, audit=outcome.audit))
        else:
            failures.append({
                "course_code": meta.course_code,
                "course_title": meta.course_title,
                "error": outcome.error,
                "retries_used": outcome.audit.retries_used,
            })
            if verbose:
                print(f"  [FAILED] {meta.course_code}: {outcome.error}")

    return BatchGenerationResult(
        total_courses_attempted=len(catalog),
        total_courses_validated=len(records),
        records=records,
        failures=failures,
    )


# ==============================================================================
# 8. OFFLINE MOCK SCRIPTING — proves the retry loop actually recovers
# ==============================================================================

def _build_mock_provider() -> MockProvider:
    """Builds a MockProvider whose scripted responses exercise the REAL
    validation + retry code path end-to-end without needing Ollama:
      - Course 1 (CGP): Pass-2 output first violates K/S/A coverage
        (no Attitude outcome) -> triggers a retry -> corrected version passes.
      - Courses 2-4: clean two-pass runs (Pass 1 draft, Pass 2 audit passes
        validation immediately).
    """

    def co(clo, domain, level, desc, po):
        return {"clo_number": clo, "domain": domain, "bloom_level": level, "co_description": desc, "mapped_po": po}

    # ---- Course 1: Computer Graphics Programming (demonstrates the retry) ---
    cgp_draft = {
        "course_code": "CS321", "course_title": "Computer Graphics Programming",
        "course_description": COURSE_CATALOG[0].course_description,
        "target_pos": [1, 2, 3, 5],
        "course_outcomes": [
            co(1, "Knowledge", "Analyze", "Analyze the mathematical foundations of 2D and 3D transformation matrices.", [1, 2]),
            co(2, "Skills", "Manipulation", "Implement shader programs using OpenGL to render textured 3D models.", [2, 3]),
            co(3, "Skills", "Precision", "Optimize rendering pipelines for real-time frame rate performance.", [3]),
            co(4, "Knowledge", "Evaluate", "Evaluate trade-offs between rasterization and ray-tracing rendering techniques.", [1, 5]),
        ],
    }
    # First audit pass INTENTIONALLY still has no "Attitude" outcome -> fails K/S/A coverage.
    cgp_audit_bad = dict(cgp_draft)
    # Second audit pass (after retry feedback) adds the missing Attitude outcome -> passes.
    cgp_audit_fixed = {
        **cgp_draft,
        "course_outcomes": cgp_draft["course_outcomes"] + [
            co(5, "Attitude", "Valuing", "Advocate for accessible and inclusive visual design practices in graphics applications.", [5]),
        ],
    }

    # ---- Course 2: Database Systems 1 (clean run) ---------------------------
    dbs_final = {
        "course_code": "CS322", "course_title": "Database Systems 1",
        "course_description": COURSE_CATALOG[1].course_description,
        "target_pos": [1, 2, 3, 4],
        "course_outcomes": [
            co(1, "Knowledge", "Analyze", "Analyze normalization requirements up to Third Normal Form for a relational schema.", [1, 2]),
            co(2, "Skills", "Manipulation", "Construct SQL queries that join, aggregate, and filter multi-table relational data.", [2, 3]),
            co(3, "Skills", "Precision", "Implement transaction control and indexing strategies for query performance.", [3, 4]),
            co(4, "Attitude", "Responding", "Comply with data integrity and referential-integrity best practices during schema design.", [4]),
        ],
    }

    # ---- Course 3: Data Mining and Analytics (clean run) ---------------------
    dm_final = {
        "course_code": "CS323", "course_title": "Data Mining and Analytics",
        "course_description": COURSE_CATALOG[2].course_description,
        "target_pos": [1, 2, 3, 6],
        "course_outcomes": [
            co(1, "Knowledge", "Understand-Cognitively", "Describe the data preprocessing pipeline of cleaning, transformation, and feature selection.", [1, 2]),
            co(2, "Skills", "Manipulation", "Implement classification and clustering algorithms on real-world datasets using Python.", [2, 3]),
            co(3, "Knowledge", "Evaluate", "Evaluate model performance using precision, recall, and cross-validation metrics.", [3, 6]),
            co(4, "Attitude", "Valuing", "Advocate for ethical and privacy-conscious handling of sensitive datasets.", [6]),
        ],
    }

    # ---- Course 4: Software Engineering (clean run) --------------------------
    se_final = {
        "course_code": "CS324", "course_title": "Software Engineering",
        "course_description": COURSE_CATALOG[3].course_description,
        "target_pos": [1, 2, 3, 4, 7],
        "course_outcomes": [
            co(1, "Knowledge", "Apply", "Apply requirements-engineering techniques to elicit and document functional specifications.", [1, 2]),
            co(2, "Skills", "Articulation", "Model a modular software architecture using established design patterns.", [2, 3]),
            co(3, "Skills", "Manipulation", "Construct a working software increment following an agile Scrum workflow.", [3, 4]),
            co(4, "Attitude", "Organizing", "Prioritize code quality and peer code-review practices within a development team.", [4, 7]),
        ],
    }

    responses = [
        json.dumps(cgp_draft),        # Pass 1 draft (Course 1)
        json.dumps(cgp_audit_bad),    # Pass 2 audit — still missing Attitude -> validation fails
        json.dumps(cgp_audit_fixed),  # Pass 2 retry — corrected -> validation passes

        json.dumps(dbs_final),        # Pass 1 draft (Course 2)
        json.dumps(dbs_final),        # Pass 2 audit — already compliant -> passes

        json.dumps(dm_final),         # Pass 1 draft (Course 3)
        json.dumps(dm_final),         # Pass 2 audit — already compliant -> passes

        json.dumps(se_final),         # Pass 1 draft (Course 4)
        json.dumps(se_final),         # Pass 2 audit — already compliant -> passes
    ]
    return MockProvider(responses)


# ==============================================================================
# 9. CLI ENTRYPOINT
# ==============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Milestone 1 — Two-Pass Ollama/Qwen2.5 OBE Course Outcomes Engine (batch)."
    )
    parser.add_argument(
        "--model", default=None,
        help="Ollama model name (e.g. qwen2.5:7b). If omitted, the engine "
             "auto-detects whichever model is already installed locally.",
    )
    parser.add_argument("--retries", type=int, default=3, help="Max validation-error retries per course")
    parser.add_argument("--output", default="sample_validated_output.json", help="Batch output JSON path")
    parser.add_argument(
        "--mock", action="store_true",
        help="Use the built-in offline MockProvider instead of a real Ollama daemon "
             "(exercises the identical validation + retry pipeline for demo/testing).",
    )
    parser.add_argument(
        "--debug", action="store_true",
        help="Print the RAW, verbatim text returned by the model at every pass, plus a "
             "before/after diff of anything the auto-repair layer touched. Use this to "
             "verify the output is genuinely coming from your live model.",
    )
    args = parser.parse_args()

    if args.mock:
        cfg = EngineConfig(model_name="mock-scripted", max_retries=args.retries)
        print("[*] Running in OFFLINE MOCK mode (no Ollama daemon required).")
        provider: LLMProvider = _build_mock_provider()
    else:
        print("[*] Connecting to local Ollama daemon...")
        provider = OllamaProvider(args.model)  # auto-detects installed model if args.model is None
        print(f"[+] Using locally installed model: '{provider.model_name}'")
        cfg = EngineConfig(model_name=provider.model_name, max_retries=args.retries)

    print("=" * 70)
    print("CCS OBE SYLLABUS GENERATOR — MILESTONE 1: BATCH COURSE OUTCOMES ENGINE")
    print(f"Batch: 3rd Year, 1st Semester CS/IT ({len(COURSE_CATALOG)} subjects)")
    print("=" * 70)

    result = run_batch(provider, cfg, debug=args.debug)

    print("\n" + "=" * 70)
    print(f"BATCH SUMMARY: {result.total_courses_validated}/{result.total_courses_attempted} courses validated.")
    if result.failures:
        print(f"Failures: {[f['course_code'] for f in result.failures]}")
    print("=" * 70)

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(result.model_dump_json(indent=2))
    print(f"\n[+] Batch output saved to: {args.output}")

    if result.total_courses_validated == 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
