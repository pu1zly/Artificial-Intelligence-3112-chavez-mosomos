# Outcome-Based Education (OBE) Academic System Development
**BSCS 3112 - Artificial Intelligence Lab | Lesson 3-4**  
*College of Computer Studies (CCS) - UPHSD*  
*Author: Prof. Rob Malitao Lab Activities 1.1 & 1.2 Implementation*

---

## Overview

This project provides an automated, production-grade microservice and prompt engineering pipeline for generating strict Outcome-Based Education (OBE) course syllabi using a local Large Language Model (**Qwen2.5 running on Ollama**) combined with **Python Pydantic models**, **Bloom's Taxonomy enforcement**, and **automated exception handling with retry logic**.

---

## Project Structure & Deliverables

| Deliverable File | Description |
| :--- | :--- |
| [`obe_schemas.py`](file:///C:/Users/Floyd/.gemini/antigravity/scratch/academic_system_development/obe_schemas.py) | **Deliverable 1**: Pydantic data models for Course Outcomes, LLOs (Knowledge, Skills, Attitude), Weekly Schedule, and Institutional Grading Breakdown. |
| [`lab1_1_generator.py`](file:///C:/Users/Floyd/.gemini/antigravity/scratch/academic_system_development/lab1_1_generator.py) | **Deliverable 2**: CLI executable script querying Qwen via Ollama JSON mode to generate and validate 4–5 Bloom-compliant Course Outcomes. |
| [`obe_json_generator.py`](file:///C:/Users/Floyd/.gemini/antigravity/scratch/academic_system_development/obe_json_generator.py) | CLI entrypoint alias as specified in Lab Activity 1.1 expected outcome. |
| [`lab1_2_pipeline.py`](file:///C:/Users/Floyd/.gemini/antigravity/scratch/academic_system_development/lab1_2_pipeline.py) | **Deliverable 3**: Multi-turn prompt pipeline generating the complete 14-week schedule with Week 7 Midterm, Week 14 Final, IT hands-on TLAs, and CO mapping. |
| [`tkinter_gui.py`](file:///C:/Users/Floyd/.gemini/antigravity/scratch/academic_system_development/tkinter_gui.py) | Desktop Tkinter interface for generating, previewing, loading, and saving Course Outcomes and the complete syllabus. |
| [`sample_output_syllabus.json`](file:///C:/Users/Floyd/.gemini/antigravity/scratch/academic_system_development/sample_output_syllabus.json) | **Deliverable 4**: Complete validated syllabus JSON for `CS201: Data Structures and Algorithms`. |
| [`test_pipeline.py`](file:///C:/Users/Floyd/.gemini/antigravity/scratch/academic_system_development/test_pipeline.py) | Automated unit and integration test suite validating schema enforcement and business rules. |

---

## Pedagogical & Business Rules Enforced

1. **Negative Constraints**:
   - Vague, non-measurable verbs (`understand`, `learn`, `know`, `be exposed to`, `study`) are strictly banned from Course Outcomes and LLOs.
2. **Bloom's Taxonomy Levels**:
   - Level 1-2 (Remember/Understand): `Identify`, `Define`, `Recall`, `Describe`
   - Level 3-4 (Apply/Analyze): `Apply`, `Implement`, `Configure`, `Calculate`, `Analyze`
   - Level 5-6 (Evaluate/Create): `Design`, `Develop`, `Synthesize`, `Integrate`, `Defend`
3. **Weekly Schedule Milestones**:
   - Exactly 14 weeks.
   - **Week 7**: Dedicated strictly to **Midterm Examination & Practical Lab Exam**.
   - **Week 14**: Dedicated strictly to **Final Examination & Capstone Project Lab Defense**.
4. **Teaching & Learning Activities (TLAs)**:
   - All activities emphasize hands-on IT/CS lab work (e.g., programming workshops, debugging, benchmarking).
5. **Coverage & Alignment**:
   - Every single generated Course Outcome is verified to be mapped at least once within the 14-week schedule.
6. **Institutional Grading Formula (Lesson 3 Slide 14)**:
   $$\text{Class Standing} = (\text{Quizzes} \times 30\%) + (\text{Research} \times 20\%) + (\text{Seatwork/Lab} \times 50\%)$$
   $$\text{Term Grade} = (\text{Class Standing} \times 70\%) + (\text{Major Exam} \times 30\%)$$

---

## How to Run

### Prerequisites
- Ollama running locally with `qwen2.5:1.5b`
- Python 3.10+ with `pydantic` and `ollama` installed

### 1. Run Lab 1.1 (Course Outcomes Generator)
```bash
python lab1_1_generator.py --title "Data Structures and Algorithms" --code "CS201" --output lab1_1_output.json
```
or via the CLI alias:
```bash
python obe_json_generator.py --title "Artificial Intelligence" --code "BSCS 3112"
```

### 2. Run Lab 1.2 (14-Week Chained Pipeline)
```bash
python lab1_2_pipeline.py --input-cos lab1_1_output.json --output sample_output_syllabus.json
```

### 3. Run the Tkinter GUI
```bash
python tkinter_gui.py
```

For one-click startup on Windows, double-click [`run_obe_gui.bat`](run_obe_gui.bat).

Use **Generate Course Outcomes** to create and save the Lab 1.1 JSON, then use
**Build 14-Week Syllabus** to generate the validated Lab 1.2 output. The GUI
keeps Ollama calls in a worker thread so the interface remains responsive.

### 4. Run Automated Tests
```bash
python -m unittest test_pipeline.py -v
```

---

## GUI Enhancements (Mosomos)

Building on Chavez's Lab 1.1/1.2 pipeline and original `tkinter_gui.py`, the
desktop interface was reworked with the following improvements:

- **Tabbed results** — Course Outcomes and the Weekly Schedule now render as
  readable tables (`ttk.Treeview`) instead of one raw JSON blob; a "Raw JSON"
  tab is still available for the exact saved output. Double-click a week row
  to see its full detail (LLOs, TLA, assessment tool, evidence).
- **Menu bar** with `File` (Open, Open Recent, Save As, Exit), `Run`
  (Generate / Build), and `Help` (About), plus keyboard shortcuts
  (`Ctrl+G`, `Ctrl+B`, `Ctrl+O`, `Ctrl+Q`).
- **Persisted settings & recent files** — course/model settings and the last
  5 opened Course Outcome files are saved to `obe_gui_settings.json` next to
  the script and restored on the next launch.
- **Progress bar** — an indeterminate `ttk.Progressbar` now shows while an
  Ollama job is running, in addition to the status bar text.
- **Inline validation** — invalid fields (empty title/code, malformed POs,
  bad retry count) are outlined in red immediately, instead of relying only
  on a popup after clicking Generate.
- **Model selector** — the Ollama model field is now a combo box with common
  presets (`qwen2.5:1.5b/3b/7b`, `llama3.1:8b`, `mistral`) while remaining
  freely editable for any local model.
- **Guided workflow** — "Build 14-Week Syllabus" is disabled with a hint
  until Course Outcomes have been generated or loaded, avoiding the old
  `FileNotFoundError` surprise.
- **Cross-platform "Reveal" button** — replaces the Windows-only
  "View in File Explorer" action; now opens Explorer on Windows, Finder on
  macOS, and the default file manager (`xdg-open`) on Linux.
- Refreshed color palette/spacing for a less default-Tk look.
