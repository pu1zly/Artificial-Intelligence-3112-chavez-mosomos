@echo off
setlocal
cd /d "%~dp0"
title Perpetual Bistro Virtual Waiter

rem Usage: run_waiter.bat          start (resumes the saved order)
rem        run_waiter.bat reset    wipe saved order and restore stock, then start
set FLAGS=
if /i "%~1"=="reset" set FLAGS=--reset-db

where python >nul 2>nul
if errorlevel 1 (
  echo [X] Python was not found. Install it from https://python.org and tick "Add to PATH".
  pause & exit /b 1
)

if not exist ".venv\Scripts\activate.bat" (
  echo Creating virtual environment...
  python -m venv .venv
)
call ".venv\Scripts\activate.bat"
echo Checking Python packages...
python -m pip install -q -r requirements.txt
if errorlevel 1 ( echo [X] Package install failed. & pause & exit /b 1 )

where ollama >nul 2>nul
if errorlevel 1 (
  echo [X] Ollama was not found. Install it from https://ollama.com then run this again.
  pause & exit /b 1
)

ollama list >nul 2>nul
if errorlevel 1 (
  echo Starting Ollama...
  start "Ollama" /min ollama serve
  timeout /t 6 /nobreak >nul
)

ollama list | findstr /i "qwen2.5" >nul
if errorlevel 1 (
  echo Downloading the qwen2.5 model, this only happens once...
  ollama pull qwen2.5
)

echo.
echo Opening http://localhost:5000  ^(close this window to stop the kiosk^)
start "" cmd /c "timeout /t 3 /nobreak >nul & start http://localhost:5000"
python virtual_waiter_prototype.py %FLAGS%
pause
