"""Unit tests verifying all specific PDF rubric requirements, FSM guardrails, and edge cases.
"""
import os
import tempfile
import unittest

import db_tools as db
import fsm_controller
from speech_engine import SpeechEngine


class PdfMilestoneRequirementsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        db.DB_PATH = os.path.join(self.temp.name, "restaurant.db")
        fsm_controller.LOG_PATH = os.path.join(self.temp.name, "conversation.json")
        db.init_db()
        self.agent = fsm_controller.WaiterAgent()
        self.agent.reset()

    def tearDown(self):
        self.temp.cleanup()

    def test_database_builds_and_contains_required_tables_and_views(self):
        with db.conn() as c:
            tables = [r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type IN ('table', 'view')")]
        self.assertIn("menu_items", tables)
        self.assertIn("table_sessions", tables)
        self.assertIn("order_line_items", tables)
        self.assertIn("cart_items", tables)

    def test_cannot_jump_from_greeting_directly_to_confirmed(self):
        self.assertEqual(self.agent.state, fsm_controller.GREETING)
        reply = self.agent.handle_user("Please confirm my order now")
        self.assertIn("Cannot jump from GREETING directly to CONFIRMED", reply)
        self.assertEqual(self.agent.state, fsm_controller.GREETING)
        self.assertIsNone(self.agent.session_id)

    def test_out_of_stock_crispy_slice_salmon_is_blocked(self):
        # Capture table number to enter ORDERING state
        self.agent.handle_user("Table 3")
        self.assertEqual(self.agent.state, fsm_controller.ORDERING)

        # Attempt to order Crispy Slice Salmon (stock is 0)
        result = db.add_item_to_order_tool(self.agent.session_id, "Crispy Slice Salmon", 1)
        self.assertFalse(result["ok"])
        self.assertIn("Crispy Slice Salmon is out of stock", result["error"])
        self.assertTrue(result.get("out_of_stock"))
        self.assertGreater(len(result.get("alternatives", [])), 0)

    def test_insufficient_stock_pan_seared_salmon_is_blocked_with_alternatives(self):
        self.agent.handle_user("Table 3")
        # Stock is 2 for Pan-Seared Salmon, attempt to order 5
        result = db.add_item_to_order_tool(self.agent.session_id, "Pan-Seared Salmon", 5)
        self.assertFalse(result["ok"])
        self.assertIn("Only 2 x Pan-Seared Salmon available", result["error"])
        self.assertTrue(result.get("out_of_stock"))
        self.assertGreater(len(result.get("alternatives", [])), 0)

    def test_cannot_modify_or_cancel_order_after_confirmed(self):
        self.agent.handle_user("Table 8")
        self.agent._run_tool("add_item_to_order_tool", {"item_name": "Cheeseburger", "qty": 1})
        self.agent.go_review()
        self.assertEqual(self.agent.state, fsm_controller.REVIEW)

        # Confirm the order
        confirm_reply = self.agent.handle_user("Confirm order")
        self.assertEqual(self.agent.state, fsm_controller.CONFIRMED)
        self.assertIn("OFFICIAL RECEIPT", confirm_reply)

        # Attempt edge case 1: Add item in CONFIRMED state
        add_attempt = db.add_item_to_order_tool(self.agent.session_id, "French Fries", 1)
        self.assertFalse(add_attempt["ok"])
        self.assertIn("already confirmed", add_attempt["error"])

        # Attempt edge case 2: Cancel order in CONFIRMED state
        cancel_attempt = db.cancel_order(self.agent.session_id)
        self.assertFalse(cancel_attempt["ok"])
        self.assertIn("already confirmed", cancel_attempt["error"])

        # Agent chat rejection in CONFIRMED state
        chat_reply = self.agent.handle_user("Please cancel my order")
        self.assertIn("Cannot cancel order: order is already confirmed", chat_reply)
        self.assertEqual(self.agent.state, fsm_controller.CONFIRMED)

    def test_off_topic_questions_are_rejected(self):
        self.agent.handle_user("Table 2")
        reply = self.agent.handle_user("What's the weather like today?")
        self.assertIn("Perpetual Bistro", reply)
        self.assertIn("food order and our menu", reply)

    def test_crud_wrapper_and_cart_totals(self):
        session_id = db.create_session(4)
        db.add_item_to_order_tool(session_id, "Cheeseburger", 2, "no onions")
        db.add_item_to_order_tool(session_id, "French Fries", 1)

        summary = db.get_cart_summary(session_id)
        self.assertEqual(len(summary["items"]), 2)
        # Cheeseburger: 2 * 180 = 360, Fries: 90 => Subtotal: 450
        self.assertEqual(summary["subtotal"], 450.0)
        # Service fee: 45.0 => Total: 495.0
        self.assertEqual(summary["service_fee"], 45.0)
        self.assertEqual(summary["total"], 495.0)

    def test_speech_engine_instantiation_and_tuning(self):
        engine = SpeechEngine(tts_rate=175, tts_volume=0.9)
        self.assertEqual(engine.tts_rate, 175)
        self.assertEqual(engine.tts_volume, 0.9)


if __name__ == "__main__":
    unittest.main()
