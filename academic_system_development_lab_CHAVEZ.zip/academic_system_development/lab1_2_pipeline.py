"""
lab1_2_pipeline.py
Lab Activity 1.2: System Prompt Engineering for Alignment & Grading Matrix.
Chained generation script producing the complete 14-week syllabus JSON structure.
Enforces Week 7 Midterms, Week 14 Finals, IT hands-on TLAs, 100% CO alignment,
and the Institutional Grading Breakdown.
"""

import argparse
import json
import os
import sys
from typing import Dict, Any, List, Optional
import ollama
from pydantic import ValidationError

from obe_schemas import (
    CourseOutcomePayload,
    CourseOutcome,
    WeeklySchedule,
    LessonLearningOutcome,
    InstitutionalGradingBreakdown,
    OBESyllabusPayload
)
from lab1_1_generator import generate_course_outcomes


SYSTEM_PROMPT_SCHEDULE_ENGINEER = """You are an expert IT/CS Academic Dean and Curriculum Designer for the College of Computer Studies at UPHSD.
You are generating a strictly aligned 14-week Outcome-Based Education (OBE) course schedule.

BUSINESS & PEDAGOGICAL RULES:
1. Academic Calendar: Exactly 14 weeks.
   - Weeks 1-6: PRELIM period
   - Week 7: MIDTERM period (MANDATORY: Must be Midterm Examination & Practical Lab Exam)
   - Weeks 8-13: FINAL period (advanced topics & project development)
   - Week 14: FINAL period (MANDATORY: Must be Final Examination & Capstone Project Defense)
2. Teaching & Learning Activities (TLAs) MUST all be IT hands-on labs (e.g., "Hands-on programming lab", "Algorithm benchmarking lab", "Interactive code review").
3. Alignment: Each week MUST explicitly reference aligned Course Outcomes ("aligned_co": [1, 2]).
4. Complete Coverage: Across the 14 weeks, EVERY single Course Outcome provided MUST be covered at least once.
5. Bloom's Taxonomy & Measurable Verbs:
   - NEVER use "understand", "learn", "know", "study", or "be exposed to".
   - Use active Bloom's verbs (e.g., Implement, Analyze, Design, Construct, Test, Optimize).
6. Lesson Learning Outcomes (LLOs): Each week must include K/S/A outcomes:
   - K (Knowledge): Theoretical foundation
   - S (Skills): Hands-on implementation/coding
   - A (Attitude): Precision, persistence, debugging mindset, or ethics
7. Output MUST be valid JSON only.
"""


def format_cos_summary(cos: List[CourseOutcome]) -> str:
    lines = []
    for co in cos:
        lines.append(f"CO {co.clo_number} [{co.bloom_level}]: {co.co_description} (Mapped POs: {co.mapped_po})")
    return "\n".join(lines)


def query_ollama_json(model_name: str, messages: List[Dict[str, str]], temperature: float = 0.2) -> Dict[str, Any]:
    """Helper to query Ollama in JSON mode and parse the response."""
    response = ollama.chat(
        model=model_name,
        messages=messages,
        format="json",
        options={"temperature": temperature}
    )
    raw = response["message"]["content"].strip()
    if raw.startswith("```json"):
        raw = raw[7:]
    if raw.startswith("```"):
        raw = raw[3:]
    if raw.endswith("```"):
        raw = raw[:-3]
    return json.loads(raw.strip())


def generate_weekly_schedule_chunk(
    start_week: int,
    end_week: int,
    period_name: str,
    course_metadata: CourseOutcomePayload,
    target_cos_to_cover: List[int],
    conversation_history: List[Dict[str, str]],
    model_name: str = "qwen2.5:1.5b",
    max_retries: int = 3
) -> List[WeeklySchedule]:
    """
    Generates a segment of the 14-week schedule using multi-turn prompting and Pydantic validation.
    """
    is_midterm_chunk = (start_week <= 7 <= end_week)
    is_final_chunk = (end_week == 14)

    milestone_rule = ""
    if is_midterm_chunk:
        milestone_rule = "\n- CRITICAL RULE: Week 7 MUST be 'Midterm Examination & Practical Lab Exam'."
    if is_final_chunk:
        milestone_rule = "\n- CRITICAL RULE: Week 14 MUST be 'Final Examination & Project Defense'."

    prompt = f"""Generate the course schedule for Weeks {start_week} through {end_week} ({period_name} period).
Course: [{course_metadata.course_code}] {course_metadata.course_title}
Course Outcomes to cover in this block: {target_cos_to_cover}

Requirements:
- Array of exactly {end_week - start_week + 1} week objects (week_number {start_week} to {end_week}).{milestone_rule}
- All TLAs must be IT hands-on laboratory activities (e.g., 'Hands-on programming lab', 'Algorithm analysis workshop').
- LLO rules:
  - 'K' (Knowledge): start with 'Explain', 'Describe', or 'Identify'. (NEVER use 'Understand' or 'Learn').
  - 'S' (Skills): start with 'Implement', 'Construct', 'Debug', or 'Optimize'.
  - 'A' (Attitude): start with 'Demonstrate', 'Display', or 'Maintain'.
- Each week must include:
  - "week_number": int ({start_week} to {end_week})
  - "period": "{period_name}"
  - "topic": str
  - "teaching_learning_activity": str
  - "assessment_tool": str
  - "evidence": str
  - "aligned_co": [list of integer CO numbers from {target_cos_to_cover}]
  - "llos": [
      {{"category": "K", "outcome_text": "Explain fundamental concept..."}},
      {{"category": "S", "outcome_text": "Implement data structure in lab..."}},
      {{"category": "A", "outcome_text": "Demonstrate persistence in debugging..."}}
    ]

Return strictly pure JSON with key "weeks":
{{
  "weeks": [ ... ]
}}
"""
    messages = list(conversation_history)
    messages.append({"role": "user", "content": prompt})

    attempt = 0
    last_err = ""

    while attempt <= max_retries:
        try:
            print(f"[*] Generating Weeks {start_week}-{end_week} (Attempt {attempt + 1}/{max_retries + 1})...")
            parsed = query_ollama_json(model_name, messages)
            
            weeks_raw = parsed.get("weeks") or parsed.get("weekly_schedule") or parsed
            if isinstance(weeks_raw, dict) and "weeks" in weeks_raw:
                weeks_raw = weeks_raw["weeks"]
            if not isinstance(weeks_raw, list):
                raise ValueError("Expected a JSON array under 'weeks' key.")

            # If model returned fewer or more weeks, slice or fill to exact length
            target_count = end_week - start_week + 1
            if len(weeks_raw) < target_count:
                raise ValueError(
                    f"Expected exactly {target_count} weeks for Weeks {start_week}-{end_week}, "
                    f"got {len(weeks_raw)}."
                )
            weeks_raw = weeks_raw[:target_count]

            # Validate and normalize each week model
            validated_weeks: List[WeeklySchedule] = []
            for idx, item in enumerate(weeks_raw):
                expected_wn = start_week + idx
                item["week_number"] = expected_wn
                item["period"] = period_name
                
                # Auto-enforce Midterm milestone at Week 7
                if expected_wn == 7:
                    item["topic"] = "Midterm Examination & Hands-on Practical Lab Exam"
                    item["teaching_learning_activity"] = "Midterm Hands-on Practical Exam in Computer Lab"
                    item["assessment_tool"] = "Midterm Examination & Practical Exam Rubric"
                    item["evidence"] = "Exam Paper, Tested Source Files, and Executable Program"
                
                # Auto-enforce Final milestone at Week 14
                if expected_wn == 14:
                    item["topic"] = "Final Examination & Capstone Project Lab Defense"
                    item["teaching_learning_activity"] = "Final Practical Examination & Project Presentation"
                    item["assessment_tool"] = "Final Examination & Capstone Evaluation Rubric"
                    item["evidence"] = "Final Project Codebase, Repository, and Technical Report"

                # Ensure aligned_co is present
                if "aligned_co" not in item and "aligned_cos" not in item:
                    item["aligned_co"] = target_cos_to_cover

                w = WeeklySchedule.model_validate(item)
                validated_weeks.append(w)

            print(f"[+] Weeks {start_week}-{end_week} validated successfully!")
            # Keep conversation history updated
            conversation_history.append({"role": "user", "content": prompt})
            conversation_history.append({"role": "assistant", "content": json.dumps(parsed)})
            return validated_weeks

        except Exception as e:
            attempt += 1
            last_err = str(e)
            print(f"[!] Validation error in Weeks {start_week}-{end_week}: {last_err}")
            if attempt > max_retries:
                raise RuntimeError(f"Failed generating Weeks {start_week}-{end_week} after {max_retries} retries: {last_err}")
            retry_msg = (
                f"Your output for Weeks {start_week}-{end_week} failed validation:\n{last_err}\n"
                f"Please fix and regenerate strictly valid JSON with exact {end_week - start_week + 1} week objects."
            )
            messages.append({"role": "user", "content": retry_msg})

    raise RuntimeError(f"Failed chunk generation: {last_err}")


def build_complete_syllabus(
    course_metadata: CourseOutcomePayload,
    model_name: str = "qwen2.5:1.5b",
    max_retries: int = 3
) -> OBESyllabusPayload:
    """
    Executes the multi-turn pipeline to generate a full 14-week OBE syllabus.
    """
    print("=" * 70)
    print(f"BUILDING 14-WEEK SYLLABUS PIPELINE: [{course_metadata.course_code}] {course_metadata.course_title}")
    print("=" * 70)
    print("Target Course Outcomes:")
    print(format_cos_summary(course_metadata.course_outcomes))
    print("-" * 70)

    all_co_ids = [co.clo_number for co in course_metadata.course_outcomes]
    half_co_count = max(1, len(all_co_ids) // 2)
    prelim_cos = all_co_ids[:half_co_count + 1]
    final_cos = all_co_ids[half_co_count:]

    # Multi-turn conversation state
    conversation_history = [
        {"role": "system", "content": SYSTEM_PROMPT_SCHEDULE_ENGINEER},
        {
            "role": "user",
            "content": (
                f"We are designing an OBE Syllabus for:\n"
                f"Course: {course_metadata.course_code} - {course_metadata.course_title}\n"
                f"Description: {course_metadata.course_description}\n\n"
                f"Here are the approved Course Outcomes:\n"
                f"{format_cos_summary(course_metadata.course_outcomes)}\n"
            )
        },
        {
            "role": "assistant",
            "content": "Understood. I have loaded the Course Outcomes and OBE constraints. Ready to generate the 14-week schedule."
        }
    ]

    # Turn 1: Weeks 1 - 7 (Prelim & Midterm)
    print("\n--- TURN 1: GENERATING WEEKS 1 TO 7 (PRELIM & MIDTERM) ---")
    weeks_1_to_7 = generate_weekly_schedule_chunk(
        start_week=1,
        end_week=7,
        period_name="MIDTERM",  # Weeks 1-6 Prelim/Midterm, Week 7 Midterm Exam
        course_metadata=course_metadata,
        target_cos_to_cover=prelim_cos,
        conversation_history=conversation_history,
        model_name=model_name,
        max_retries=max_retries
    )
    # Set periods for weeks 1-6 as PRELIM, week 7 as MIDTERM
    for w in weeks_1_to_7:
        if w.week_number < 7:
            w.period = "PRELIM"
        else:
            w.period = "MIDTERM"

    # Determine which COs were already aligned and which are still missing
    covered_cos = set()
    for w in weeks_1_to_7:
        covered_cos.update(w.aligned_co)

    remaining_cos = [cid for cid in all_co_ids if cid not in covered_cos]
    if not remaining_cos:
        remaining_cos = final_cos
    else:
        remaining_cos = sorted(list(set(remaining_cos + final_cos)))

    # Turn 2: Weeks 8 - 14 (Finals)
    print("\n--- TURN 2: GENERATING WEEKS 8 TO 14 (FINAL PERIOD) ---")
    weeks_8_to_14 = generate_weekly_schedule_chunk(
        start_week=8,
        end_week=14,
        period_name="FINAL",
        course_metadata=course_metadata,
        target_cos_to_cover=remaining_cos,
        conversation_history=conversation_history,
        model_name=model_name,
        max_retries=max_retries
    )

    combined_schedule = weeks_1_to_7 + weeks_8_to_14

    # Ensure full CO coverage across the 14 weeks
    final_covered = set()
    for w in combined_schedule:
        final_covered.update(w.aligned_co)

    missing = set(all_co_ids) - final_covered
    if missing:
        print(f"[!] Warning: Missing CO alignment for {missing}. Auto-aligning to week 13 capstone prep.")
        # Auto-align any missing CO to review/project week
        for m in missing:
            combined_schedule[12].aligned_co.append(m)

    # Instantiate the Institutional Grading Breakdown
    grading = InstitutionalGradingBreakdown()

    # Build and validate complete payload
    syllabus_payload = OBESyllabusPayload(
        course_code=course_metadata.course_code,
        course_title=course_metadata.course_title,
        course_description=course_metadata.course_description,
        target_pos=course_metadata.target_pos,
        course_outcomes=course_metadata.course_outcomes,
        grading_breakdown=grading,
        weekly_schedule=combined_schedule
    )

    print("\n[+] Full 14-week OBE Syllabus verified 100% compliant with Pydantic contracts!")
    return syllabus_payload


def main():
    parser = argparse.ArgumentParser(description="Chained OBE Syllabus Generation Pipeline (Lab 1.2)")
    parser.add_argument("--input-cos", default="lab1_1_output.json", help="Path to input Course Outcomes JSON")
    parser.add_argument("--output", default="sample_output_syllabus.json", help="Path to output complete syllabus JSON")
    parser.add_argument("--model", default="qwen2.5:1.5b", help="Ollama model name")
    parser.add_argument("--retries", type=int, default=3, help="Max retry attempts")
    parser.add_argument("--course-title", default="Data Structures and Algorithms", help="Course Title if generating COs on the fly")
    parser.add_argument("--course-code", default="CS201", help="Course Code if generating COs on the fly")

    args = parser.parse_args()

    # Step 1: Load or Generate Course Outcomes
    if os.path.exists(args.input_cos):
        print(f"[*] Loading existing Course Outcomes from: {args.input_cos}")
        with open(args.input_cos, "r", encoding="utf-8") as f:
            raw_cos = json.load(f)
        course_cos = CourseOutcomePayload.model_validate(raw_cos)
    else:
        print(f"[*] Input COs file '{args.input_cos}' not found. Triggering Lab 1.1 generation...")
        course_cos = generate_course_outcomes(
            course_title=args.course_title,
            course_code=args.course_code,
            model_name=args.model,
            max_retries=args.retries
        )
        with open(args.input_cos, "w", encoding="utf-8") as f:
            f.write(course_cos.model_dump_json(indent=2))

    # Step 2: Build Complete Syllabus with 14-Week Schedule and Grading Matrix
    complete_syllabus = build_complete_syllabus(
        course_metadata=course_cos,
        model_name=args.model,
        max_retries=args.retries
    )

    # Step 3: Save final validated syllabus deliverable
    json_result = complete_syllabus.model_dump_json(indent=2)
    with open(args.output, "w", encoding="utf-8") as f:
        f.write(json_result)

    print(f"\n[+] SUCCESS! Complete OBE syllabus saved to: {args.output}")
    print("=" * 70)


if __name__ == "__main__":
    main()
