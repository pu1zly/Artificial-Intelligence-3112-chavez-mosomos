@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title Perpetual Bistro - AI Virtual Waiter

echo ======================================================================
echo           PERPETUAL BISTRO - AI VIRTUAL WAITER LAUNCHER
echo ======================================================================

rem Usage:
rem   run.bat          - Launch Web Tablet Dashboard (Default)
rem   run.bat web      - Launch Web Tablet Dashboard
rem   run.bat gui      - Launch Desktop GUI (Tkinter)
rem   run.bat voice    - Launch Hands-Free Voice Assistant Loop
rem   run.bat cli      - Launch Interactive Terminal Console
rem   run.bat verify   - Run Milestone 1 Verification Suite
rem   run.bat reset    - Reset SQLite database with fresh catalog & stock

set MODE=%~1
set EXTRA_FLAGS=

if /i "%MODE%"=="reset" (
    set RESET_DB=1
    set SKIP_MODEL_CHECK=1
    goto CHECK_ENV
)

if /i "%MODE%"=="verify" (
    set EXTRA_FLAGS=--verify-m1
    set SKIP_MODEL_CHECK=1
    goto CHECK_ENV
)

if /i "%MODE%"=="gui" (
    set EXTRA_FLAGS=--gui
    goto CHECK_ENV
)

if /i "%MODE%"=="voice" (
    set EXTRA_FLAGS=--voice
    goto CHECK_ENV
)

if /i "%MODE%"=="cli" (
    set EXTRA_FLAGS=--cli
    goto CHECK_ENV
)

if /i "%MODE%"=="web" (
    set EXTRA_FLAGS=--web
    goto CHECK_ENV
)

rem Default is web interface
set EXTRA_FLAGS=

:CHECK_ENV
rem Check for virtualenv in parent or local folder if available
if exist "..\.venv\Scripts\activate.bat" (
    call "..\.venv\Scripts\activate.bat"
) else if exist ".venv\Scripts\activate.bat" (
    call ".venv\Scripts\activate.bat"
)

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python was not found on your system PATH.
    echo Please install Python 3.10+ and ensure "Add python.exe to PATH" is checked.
    pause
    exit /b 1
)

if "%RESET_DB%"=="1" (
    echo [i] Resetting database to fresh catalog and stock...
    python init_db.py --reset
    if errorlevel 1 (
        echo [!] Database reset failed.
        pause
        exit /b 1
    )
    pause
    exit /b 0
)

if not "%SKIP_MODEL_CHECK%"=="1" (
    echo [i] Checking Ollama and selecting the best installed Qwen model...
    echo [i] Checking local faster-whisper requirements...
    python ensure_models.py
    if errorlevel 1 (
        echo.
        echo [!] Local AI requirements are missing. Install or download them manually, then retry.
        pause
        exit /b 1
    )
)

echo [i] Starting Perpetual Bistro AI Virtual Waiter...
python app.py %EXTRA_FLAGS%
if errorlevel 1 (
    echo.
    echo [!] Program exited with an error.
    pause
)
