"""SQLite tool functions the LLM can call. All return JSON-serialisable dicts."""
import difflib, json, os, sqlite3

HERE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(HERE, "restaurant.db")
SERVICE_RATE = 0.10


def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c


def init_db(reset=False):
    if reset and os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    with conn() as c, open(os.path.join(HERE, "init_restaurant_db.sql")) as f:
        c.executescript(f.read())


def save_kiosk_state(data):
    with conn() as c:
        c.execute("INSERT INTO kiosk_state(id,data) VALUES (1,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data",
                  (json.dumps(data),))


def load_kiosk_state():
    with conn() as c:
        r = c.execute("SELECT data FROM kiosk_state WHERE id=1").fetchone()
    return json.loads(r[0]) if r else None


def session_exists(session_id):
    with conn() as c:
        return c.execute("SELECT 1 FROM table_sessions WHERE session_id=?", (session_id,)).fetchone() is not None


def create_session(table_no):
    with conn() as c:
        return c.execute("INSERT INTO table_sessions(table_no) VALUES (?)", (int(table_no),)).lastrowid


def _find_item(c, name):
    """Return (row, suggestions). Never invents items: unknown names return suggestions only."""
    rows = c.execute("SELECT * FROM menu_items").fetchall()
    n = (name or "").strip().lower()
    for r in rows:
        if r["name"].lower() == n:
            return r, []
    subs = [r for r in rows if n and (n in r["name"].lower() or r["name"].lower() in n)]
    if len(subs) == 1:
        return subs[0], []
    names = [r["name"] for r in rows]
    close = difflib.get_close_matches(name or "", names, n=1, cutoff=0.85)
    if close:
        return next(r for r in rows if r["name"] == close[0]), []
    sugg = [r["name"] for r in subs] or difflib.get_close_matches(name or "", names, n=3, cutoff=0.5)
    return None, sugg


def _in_cart(c, session_id, item_id):
    return c.execute("SELECT COALESCE(SUM(quantity),0) FROM order_line_items WHERE session_id=? AND item_id=?",
                     (session_id, item_id)).fetchone()[0]


# ---------------------------------------------------------------- LLM tools
def get_menu_by_category(category="all"):
    with conn() as c:
        cats = [r[0] for r in c.execute("SELECT DISTINCT category FROM menu_items ORDER BY id")]
        cat = next((x for x in cats if x.lower() == (category or "all").strip().lower()), None)
        if (category or "all").lower() != "all" and not cat:
            return {"ok": False, "error": f"Unknown category '{category}'.", "categories": cats}
        q = "SELECT id,name,category,price,stock_qty,allergens FROM menu_items" + (" WHERE category=?" if cat else "")
        items = [dict(r, available=r["stock_qty"] > 0) for r in c.execute(q, (cat,) if cat else ())]
        return {"ok": True, "categories": cats, "items": items}


def check_item_allergen(item_id, allergen):
    with conn() as c:
        r = c.execute("SELECT name,allergens FROM menu_items WHERE id=?", (int(item_id),)).fetchone()
        if not r:
            return {"ok": False, "error": f"No menu item with id {item_id}."}
        has = (allergen or "").strip().lower() in [a.strip() for a in r["allergens"].split(",") if a]
        return {"ok": True, "item": r["name"], "allergen": allergen, "contains": has,
                "all_allergens": r["allergens"] or "none listed"}


def add_item_to_order(session_id, item_name, qty=1, instructions=""):
    qty = int(qty)
    if qty < 1:
        return {"ok": False, "error": "Quantity must be at least 1."}
    with conn() as c:
        item, sugg = _find_item(c, item_name)
        if not item:
            return {"ok": False, "error": f"'{item_name}' is not on the menu.", "did_you_mean": sugg}
        left = item["stock_qty"] - _in_cart(c, session_id, item["id"])
        if left < qty:
            return {"ok": False, "error": f"Only {max(left,0)} x {item['name']} available." if left > 0
                    else f"{item['name']} is out of stock."}
        instr = (instructions or "").strip()
        line = c.execute("SELECT line_id FROM order_line_items WHERE session_id=? AND item_id=? "
                         "AND special_instructions=?", (session_id, item["id"], instr)).fetchone()
        if line:
            c.execute("UPDATE order_line_items SET quantity=quantity+? WHERE line_id=?", (qty, line[0]))
        else:
            c.execute("INSERT INTO order_line_items(session_id,item_id,quantity,special_instructions) "
                      "VALUES (?,?,?,?)", (session_id, item["id"], qty, instr))
    return {"ok": True, "message": f"Added {qty} x {item['name']}.", "order": view_current_order(session_id)}


def remove_item_from_order(session_id, item_name, qty=None):
    with conn() as c:
        item, sugg = _find_item(c, item_name)
        if not item:
            return {"ok": False, "error": f"'{item_name}' is not on the menu.", "did_you_mean": sugg}
        lines = c.execute("SELECT line_id,quantity FROM order_line_items WHERE session_id=? AND item_id=?",
                          (session_id, item["id"])).fetchall()
        if not lines:
            return {"ok": False, "error": f"{item['name']} is not in the current order."}
        todo = int(qty) if qty else sum(l["quantity"] for l in lines)
        for l in lines:
            if todo <= 0:
                break
            take = min(todo, l["quantity"])
            if take == l["quantity"]:
                c.execute("DELETE FROM order_line_items WHERE line_id=?", (l["line_id"],))
            else:
                c.execute("UPDATE order_line_items SET quantity=quantity-? WHERE line_id=?", (take, l["line_id"]))
            todo -= take
    return {"ok": True, "message": f"Removed {item['name']}.", "order": view_current_order(session_id)}


def view_current_order(session_id):
    with conn() as c:
        rows = c.execute("""SELECT l.line_id,l.item_id,m.name,l.quantity,l.special_instructions AS instructions,
                            m.price AS unit_price FROM order_line_items l JOIN menu_items m ON m.id=l.item_id
                            WHERE l.session_id=? ORDER BY l.line_id""", (session_id,)).fetchall()
    items = [dict(r, line_total=r["quantity"] * r["unit_price"]) for r in rows]
    sub = sum(i["line_total"] for i in items)
    fee = round(sub * SERVICE_RATE, 2)
    return {"items": items, "subtotal": sub, "service_fee": fee, "total": round(sub + fee, 2), "currency": "PHP"}


def adjust_line(line_id, delta):
    """UI +/- buttons (human-in-the-loop override)."""
    with conn() as c:
        l = c.execute("SELECT * FROM order_line_items WHERE line_id=?", (line_id,)).fetchone()
        if not l:
            return {"ok": False, "error": "Line not found."}
        new = l["quantity"] + int(delta)
        if new <= 0:
            c.execute("DELETE FROM order_line_items WHERE line_id=?", (line_id,))
        else:
            stock = c.execute("SELECT stock_qty FROM menu_items WHERE id=?", (l["item_id"],)).fetchone()[0]
            if delta > 0 and _in_cart(c, l["session_id"], l["item_id"]) + delta > stock:
                return {"ok": False, "error": "Not enough stock."}
            c.execute("UPDATE order_line_items SET quantity=? WHERE line_id=?", (new, line_id))
        return {"ok": True, "session_id": l["session_id"]}


def confirm_order(session_id):
    """Transactionally re-check stock, deduct it, close the session, return the receipt."""
    with conn() as c:
        tot = c.execute("SELECT item_id,SUM(quantity) q FROM order_line_items WHERE session_id=? GROUP BY item_id",
                        (session_id,)).fetchall()
        if not tot:
            return {"ok": False, "error": "The order is empty."}
        for t in tot:
            m = c.execute("SELECT name,stock_qty FROM menu_items WHERE id=?", (t["item_id"],)).fetchone()
            if m["stock_qty"] < t["q"]:
                return {"ok": False, "error": f"{m['name']} just ran low (only {m['stock_qty']} left)."}
        for t in tot:
            c.execute("UPDATE menu_items SET stock_qty=stock_qty-? WHERE id=?", (t["q"], t["item_id"]))
        c.execute("UPDATE table_sessions SET status='confirmed' WHERE session_id=?", (session_id,))
        table = c.execute("SELECT table_no FROM table_sessions WHERE session_id=?", (session_id,)).fetchone()[0]
    return {"ok": True, "receipt": {"session_id": session_id, "table_no": table, **view_current_order(session_id)}}
