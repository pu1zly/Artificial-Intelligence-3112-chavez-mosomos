@echo off
setlocal
cd /d "%~dp0"

where pythonw >nul 2>&1
if %errorlevel%==0 (
    start "OBE Academic System" pythonw tkinter_gui.py
) else (
    start "OBE Academic System" python tkinter_gui.py
)

endlocal
